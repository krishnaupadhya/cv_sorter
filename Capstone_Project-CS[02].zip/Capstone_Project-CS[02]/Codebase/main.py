#!/usr/bin/env python3
"""
CV Sorter — Production-Ready Resume Ranking System

Simplified architecture with:
- Only 2 LLM calls per run (job analysis + top-N reports)
- Parallel resume processing (ProcessPoolExecutor)
- Local embeddings + semantic similarity matching
- No caching (fresh analysis every run)

Usage:
    python main.py --resumes ./RESUME/ --jd job-description.txt --api-key <groq-api-key>
    python main.py --resumes ./RESUME/ --jd job-description.pdf --api-key <key> --top 10
    python main.py --resumes ./RESUME/ --jd job-description.docx --api-key <key>

Architecture:
    1. Job Analyzer Agent (LLM #1) → criteria with weights
    2. Parallel Resume Parser → structured data (NO LLM)
    3. Embedding Engine → semantic vectors (NO LLM)
    4. Semantic Matching → similarity scores (NO LLM)
    5. Ranking Engine → combined ranking (NO LLM)
    6. Report Generator (LLM #2) → top-N narratives only

Author: Senior AI Engineer
Date: March 14, 2026
"""

import argparse
import asyncio
import os
import sys
import time
from pathlib import Path
from datetime import datetime

from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table
from rich.prompt import Confirm

# Import agents and utilities
from job_analyzer_agent import JobAnalyzer
from resume_parser_agent import process_all_resumes, parse_single_resume, SKILL_KEYWORDS, set_active_skills
from embedding_engine_agent import EmbeddingEngine
from ranking_engine_agent import rank_candidates
from report_generator_agent import ReportGenerator

import numpy as np
from pathlib import Path as PathLib
from concurrent.futures import ProcessPoolExecutor, as_completed


console = Console()


def process_all_resumes_simple(folder: str) -> tuple[list[dict], dict]:
    """
    Process all resumes in parallel.
    
    Returns:
        Tuple of (resumes list, parse_stats dict)
    """
    # Find all resume files
    folder_path = PathLib(folder)
    if not folder_path.exists():
        raise FileNotFoundError(f"Folder not found: {folder}")
    
    files = [
        str(f) for f in folder_path.iterdir()
        if f.suffix.lower() in ['.pdf', '.docx', '.doc']
    ]
    
    if not files:
        raise ValueError(f"No resume files found in {folder}")
    
    resumes = []
    errors = []
    workers = min(os.cpu_count() or 4, len(files))
    
    with ProcessPoolExecutor(max_workers=workers) as executor:
        future_to_file = {
            executor.submit(parse_single_resume, filepath): filepath
            for filepath in files
        }
        
        for future in as_completed(future_to_file):
            filepath = future_to_file[future]
            try:
                result = future.result()
                resumes.append(result)
            except Exception as e:
                errors.append({"file": filepath, "error": str(e)})
                # Log validation errors but continue
                filename = os.path.basename(filepath)
                console.print(f"[yellow]⚠ Skipped {filename}: {e}[/yellow]")
    
    stats = {
        "parsed": len(resumes),
        "errors": len(errors)
    }
    
    return resumes, stats


def generate_embeddings(
    resumes: list[dict],
    embedding_engine: EmbeddingEngine
) -> np.ndarray:
    """
    Generate semantic embeddings for all resumes using sentence-transformers.
    
    This function converts resume skill text into dense vector representations
    for semantic similarity matching. Uses local sentence-transformers model
    (all-MiniLM-L6-v2) for fast, offline embedding generation.
    
    Process:
        1. Extract skill_text from each resume (concatenated skills)
        2. Batch encode all texts using sentence-transformers
        3. Return normalized embeddings (L2 norm) for cosine similarity
    
    Args:
        resumes: List of parsed resume dicts, each must have 'skill_text' key
        embedding_engine: Initialized EmbeddingEngine instance with loaded model
    
    Returns:
        np.ndarray: 2D array of embeddings, shape (num_resumes, 384)
                   Each row is a normalized 384-dimensional vector
                   Ready for FAISS indexing and similarity search
    
    Performance:
        - ~2ms per resume on CPU
        - Batch processing for efficiency
        - Example: 20 resumes in ~40ms total
        
    Example:
        >>> engine = EmbeddingEngine()
        >>> resumes = [{"skill_text": "python django postgresql"}]
        >>> embeddings = generate_embeddings(resumes, engine)
        >>> print(embeddings.shape)
        (1, 384)
        >>> print(np.linalg.norm(embeddings[0]))  # Check normalization
        1.0
    """
    texts = [resume["skill_text"] for resume in resumes]
    embeddings = embedding_engine.encode_batch(texts)
    return np.array(embeddings)


def parse_arguments():
    """
    Parse and validate command-line arguments for CV Sorter.
    
    This function defines all CLI arguments, validates their presence and format,
    and returns a parsed arguments object. Includes comprehensive help text with
    examples and prerequisite information.
    
    Required Arguments:
        --resumes: Path to directory containing resume files (PDF/DOCX)
        --jd: Path to job description file (TXT, PDF, or DOCX)
        --api-key: Groq API key for LLM inference
    
    Optional Arguments:
        --provider: LLM provider (default: "groq", currently only option)
        --top: Number of top candidates for detailed reports (default: 10)
        --output-dir: Results output directory (default: "output/results")
    
    Returns:
        argparse.Namespace: Parsed arguments object with validated values
        
    Raises:
        SystemExit: If required arguments missing or invalid values provided
        
    Example:
        >>> args = parse_arguments()
        >>> print(args.resumes)
        './RESUME/'
        >>> print(args.top)
        10
    """
    parser = argparse.ArgumentParser(
        description="CV Sorter — Production-Ready Resume Ranking System",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Rank resumes with Groq API (cloud, fast)
  python main.py --resumes ./RESUME/ --jd job-description.txt --api-key gsk_...
  
  # Job description from PDF file
  python main.py --resumes ./RESUME/ --jd "Senior Dev - Q1 2026.pdf" --api-key gsk_...
  
  # Job description from DOCX file
  python main.py --resumes ./RESUME/ --jd job_posting.docx --api-key gsk_...

  # Show only top 5 candidates
  python main.py --resumes ./RESUME/ --jd job-description.txt --api-key <key> --top 5

Get API key:
  Groq: https://console.groq.com (free tier: 840 tok/sec, Llama 3.1 8B)
        """
    )
    
    parser.add_argument(
        "--resumes",
        required=True,
        help="Path to directory containing resume files (PDF/DOCX)"
    )
    
    parser.add_argument(
        "--jd",
        required=True,
        help="Path to job description file (TXT, PDF, or DOCX)"
    )
    
    parser.add_argument(
        "--provider",
        choices=["groq"],
        default="groq",
        help="LLM provider: groq (cloud, fast)"
    )
    
    parser.add_argument(
        "--api-key",
        required=True,
        help="API key for Groq provider (get from https://console.groq.com)"
    )
    
    parser.add_argument(
        "--top",
        type=int,
        default=10,
        help="Number of top candidates to generate reports for (default: 10)"
    )
    
    parser.add_argument(
        "--output-dir",
        default="output/results",
        help="Directory to save results (default: output/results)"
    )
    
    return parser.parse_args()


def load_job_description(jd_path: str) -> str:
    """
    Load job description from file (TXT, PDF, or DOCX).
    
    Supports multiple formats:
    - TXT: Direct text reading
    - PDF: Document extraction with layout awareness
    - DOCX: Paragraph and table extraction
    
    Args:
        jd_path: Path to job description file
        
    Returns:
        Extracted text content
        
    Raises:
        FileNotFoundError: If file doesn't exist
        DocumentLoadError: If extraction fails
    """
    from document_loader_parser import DocumentLoader
    
    path = Path(jd_path)
    if not path.exists():
        raise FileNotFoundError(f"Job description file not found: {jd_path}")
    
    extension = path.suffix.lower()
    
    # Handle TXT files directly
    if extension == '.txt':
        return path.read_text(encoding='utf-8')
    
    # Handle PDF/DOCX with DocumentLoader
    elif extension in ['.pdf', '.docx', '.doc']:
        loader = DocumentLoader()
        text = loader.load(str(path))
        
        if not text or len(text.strip()) < 50:
            raise ValueError(
                f"Job description file appears to be empty or too short (< 50 chars): {jd_path}"
            )
        
        return text
    
    else:
        raise ValueError(
            f"Unsupported file format: {extension}. "
            f"Supported formats: .txt, .pdf, .docx"
        )


def display_results_table(ranked: list, top_n: int = None):
    """
    Display candidate rankings in a formatted console table.
    
    Creates a rich-formatted table showing candidate rankings with color-coded
    recommendations. Uses the Rich library for enhanced terminal output with
    colors and styling.
    
    Table Columns:
        - Rank: Numeric ranking (#1, #2, etc.)
        - Name: Candidate name (truncated to 48 chars if needed)
        - Score: Combined score (0-100) from algorithmic + semantic matching
        - Fit: Recommendation with color coding:
            * Green: Strong Fit (75-100)
            * Yellow: Moderate Fit (55-74)
            * Red: Weak Fit (0-54)
    
    Args:
        ranked: List of ranked candidate dicts, sorted by combined_score descending
        top_n: Optional limit on number of candidates to display
               If None, displays all candidates
    
    Returns:
        None (prints to console using Rich library)
        
    Example:
        >>> ranked = [
        ...     {\"name\": \"John Doe\", \"combined_score\": 87.5, \"recommendation\": \"Strong Fit\"},
        ...     {\"name\": \"Jane Smith\", \"combined_score\": 65.2, \"recommendation\": \"Moderate Fit\"}
        ... ]
        >>> display_results_table(ranked, top_n=10)
        # Displays formatted table in console
    """
    table = Table(title="Candidate Rankings (Semantic Similarity)", show_header=True, header_style="bold cyan")
    
    table.add_column("Rank", style="dim", width=8, justify="center")
    table.add_column("Name", style="bold", width=50)
    table.add_column("Score", justify="right", width=12)
    table.add_column("Fit", style="bold", width=18, justify="center")
    
    display_count = len(ranked) if top_n is None else min(top_n, len(ranked))
    
    for i, candidate in enumerate(ranked[:display_count], 1):
        # Color recommendation
        rec = candidate["recommendation"]
        if rec == "Strong Fit":
            rec_style = "green"
        elif rec == "Moderate Fit":
            rec_style = "yellow"
        else:
            rec_style = "red"
        
        table.add_row(
            f"#{i}",
            candidate["name"][:48],
            f"{candidate['combined_score']:.1f}",
            f"[{rec_style}]{rec}[/{rec_style}]"
        )
    
    console.print(table)
    console.print()


def save_results(ranked: list, criteria: list, skills: list, output_dir: str, refinement_desc: str = None) -> tuple[str, str, str]:
    """
    Save results to JSON and text files.
    
    GUARDRAIL #3: Create timestamped folder containing only 3 files:
    - criteria.json (extracted job criteria)
    - skills.json (combined skill keywords)
    - cv_sorting_results.txt (unified report with ranking table + skills & gaps)
    
    Args:
        ranked: List of ranked candidates
        criteria: List of job criteria
        skills: List of all skills
        output_dir: Output directory path
        refinement_desc: Optional description of refinement applied
        
    Returns:
        Tuple of (criteria_path, skills_path, unified_report_path)
    """
    import json
    
    # Create output directory
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)
    
    # GUARDRAIL #3: Create timestamped subfolder
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    folder_prefix = "refined" if refinement_desc else "ranking"
    ranking_folder = output_path / f"{folder_prefix}_{timestamp}"
    ranking_folder.mkdir(parents=True, exist_ok=True)
    
    # Save criteria JSON
    criteria_file = ranking_folder / "criteria.json"
    with open(criteria_file, 'w', encoding='utf-8') as f:
        # Clean criteria data for JSON serialization
        cleaned_criteria = [
            {k: v for k, v in criterion.items() if k not in ['embedding', 'raw_text']}
            for criterion in criteria
        ]
        json.dump(cleaned_criteria, f, indent=2, ensure_ascii=False)
    
    # Save skills JSON
    skills_file = ranking_folder / "skills.json"
    with open(skills_file, 'w', encoding='utf-8') as f:
        json.dump({
            "total_skills": len(skills),
            "skills": sorted(skills)  # Sort for easier review
        }, f, indent=2, ensure_ascii=False)
    
    # Save unified cv_sorting_results.txt with ranking table + skills & gaps
    unified_file = ranking_folder / "cv_sorting_results.txt"
    with open(unified_file, 'w', encoding='utf-8') as f:
        f.write("╔" + "═" * 78 + "╗\n")
        f.write("║" + " " * 20 + "CV SORTING RESULTS" + " " * 40 + "║\n")
        f.write("╚" + "═" * 78 + "╝\n\n")
        f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"Total Candidates: {len(ranked)}\n")
        if refinement_desc:
            f.write(f"Refinement Applied: {refinement_desc}\n")
        f.write("\n" + "=" * 80 + "\n\n")
        
        # SECTION 1: RANKING TABLE
        f.write("╔" + "═" * 78 + "╗\n")
        f.write("║" + " " * 25 + "RANKING TABLE" + " " * 40 + "║\n")
        f.write("╚" + "═" * 78 + "╝\n\n")
        
        # Table header
        f.write(f"{'Rank':<8} {'Name':<35} {'Score':<12} {'Recommendation':<20}\n")
        f.write("-" * 80 + "\n")
        
        # Table rows
        for i, candidate in enumerate(ranked, 1):
            name = candidate['name'][:32] + "..." if len(candidate['name']) > 35 else candidate['name']
            score = f"{candidate['combined_score']:.1f}/100"
            rec = candidate['recommendation']
            f.write(f"#{i:<7} {name:<35} {score:<12} {rec:<20}\n")
        
        f.write("\n" + "=" * 80 + "\n\n")
        
        # SECTION 2: CANDIDATE DETAILS WITH SKILLS AND GAPS
        f.write("╔" + "═" * 78 + "╗\n")
        f.write("║" + " " * 18 + "CANDIDATE SKILLS & GAPS" + " " * 36 + "║\n")
        f.write("╚" + "═" * 78 + "╝\n\n")
        
        for i, candidate in enumerate(ranked, 1):
            f.write(f"{'━' * 80}\n")
            f.write(f"RANK #{i}: {candidate['name'].upper()}\n")
            f.write(f"{'━' * 80}\n\n")
            
            f.write(f"📧 Email:          {candidate['email']}\n")
            f.write(f"💼 Experience:     {candidate['experience_years']} years\n")
            f.write(f"📊 Score:          {candidate['combined_score']:.1f}/100\n")
            f.write(f"✅ Recommendation: {candidate['recommendation']}\n\n")
            
            # Skills
            candidate_skills = candidate.get('skills', [])
            f.write(f"🔧 SKILLS ({len(candidate_skills)}):\n")
            if candidate_skills:
                # Format skills in rows of 5
                for j in range(0, len(candidate_skills), 5):
                    skill_row = candidate_skills[j:j+5]
                    f.write(f"   • {', '.join(skill_row)}\n")
            else:
                f.write("   • None listed\n")
            f.write("\n")
            
            # Matched criteria
            matched = candidate.get('matched_criteria', [])
            f.write(f"✅ MATCHED CRITERIA ({len(matched)}):\n")
            if matched:
                for criterion in matched:
                    f.write(f"   ✓ {criterion}\n")
            else:
                f.write("   • None\n")
            f.write("\n")
            
            # Missing criteria (gaps)
            missing = candidate.get('missing_criteria', [])
            f.write(f"❌ SKILL GAPS ({len(missing)}):\n")
            if missing:
                for gap in missing:
                    f.write(f"   ✗ {gap}\n")
            else:
                f.write("   • Complete match — no gaps!\n")
            f.write("\n")
            
            # Assessment if available
            if "report_text" in candidate and candidate["report_text"]:
                f.write(f"📝 ASSESSMENT:\n")
                # Wrap text at 75 chars
                import textwrap
                wrapped = textwrap.fill(candidate['report_text'], width=75, initial_indent="   ", subsequent_indent="   ")
                f.write(wrapped)
                f.write("\n")
            
            f.write("\n")
        
        f.write("=" * 80 + "\n")
        f.write("End of Report\n")
    
    return str(criteria_file), str(skills_file), str(unified_file)


def cleanup_old_results(output_dir: str):
    """
    Clean up old results from output directory to start fresh.
    
    This function automatically removes all previous ranking and refined result
    folders before starting a new run. Ensures clean output directory and prevents
    accumulation of old results that could cause confusion.
    
    Deletes all subdirectories starting with:
        - "ranking_YYYYMMDD_HHMMSS" (initial ranking results)
        - "refined_YYYYMMDD_HHMMSS" (interactive refinement results)
    
    Args:
        output_dir: Path to output directory (e.g., "output/results")
    
    Returns:
        None (prints status messages to console)
    
    Behavior:
        - Creates output directory if it doesn't exist
        - Silently returns if no old results found
        - Continues if individual folder deletion fails (prints warning)
        - Counts and reports number of folders cleaned
        
    Example:
        >>> cleanup_old_results("output/results")
        Found 3 previous result folder(s) in output/results
        ✓ Cleaned 3 old result folder(s)
    """
    import shutil
    
    output_path = Path(output_dir)
    
    if not output_path.exists():
        return
    
    # Count existing result folders
    existing_folders = [
        f for f in output_path.iterdir()
        if f.is_dir() and (f.name.startswith("ranking_") or f.name.startswith("refined_"))
    ]
    
    if not existing_folders:
        return
    
    console.print(f"\n[yellow]Found {len(existing_folders)} previous result folder(s) in {output_dir}[/yellow]")
    
    # Automatically clean without asking
    for folder in existing_folders:
        try:
            shutil.rmtree(folder)
        except Exception as e:
            console.print(f"[yellow]Warning: Could not delete {folder.name}: {e}[/yellow]")
    
    console.print(f"[green]✓ Cleaned {len(existing_folders)} old result folder(s)[/green]\n")

async def run_pipeline(args):
    """
    Main pipeline orchestrator.
    
    Makes exactly 2 LLM calls:
    1. Job description analysis (criteria extraction)
    2. Report generation for top-N candidates
    
    Everything else is local processing.
    """
    
    # Performance tracking
    timings = {}
    pipeline_start = time.time()
    
    # Clean output folder if requested
    cleanup_old_results(args.output_dir)
    
    # Validate API key is provided
    if not args.api_key:
        console.print(
            f"[red]Error: --api-key is required for Groq provider[/red]\n"
            f"Get an API key at: https://console.groq.com"
        )
        sys.exit(1)
    
    # Load job description
    step_start = time.time()
    console.print("\n[bold]Step 1: Loading Job Description[/bold]")
    jd_text = load_job_description(args.jd)
    timings["load_jd"] = time.time() - step_start
    console.print(f"[green]✓ Loaded {len(jd_text)} characters[/green] [dim]({timings['load_jd']:.2f}s)[/dim]\n")
    
    # ─── STEP 2: Job Analysis (LLM CALL #1) ───
    step_start = time.time()
    console.print("[bold]Step 2: Analyzing Job Requirements[/bold]")
    # Display model info based on provider
    model_info = "llama-3.3-70b-versatile" if args.provider == "groq" else "70B model"
    console.print(f"[cyan]Calling LLM ({args.provider}/{model_info}) to extract criteria and skills...[/cyan]")
    job_analyzer = JobAnalyzer(provider=args.provider, api_key=args.api_key)
    criteria, llm_skills = job_analyzer.analyze(jd_text)
    
    # Combine LLM-extracted skills with hardcoded skills
    combined_skills = list(set(SKILL_KEYWORDS + llm_skills))  # Remove duplicates
    
    timings["job_analysis"] = time.time() - step_start
    console.print(
        f"[green]✓ Extracted {len(criteria)} criteria + {len(llm_skills)} job-specific skills[/green] "
        f"[dim]({timings['job_analysis']:.2f}s)[/dim]"
    )
    console.print(f"[dim]Top criteria: {criteria[0]['name']} (weight: {criteria[0]['weight']})[/dim]")
    console.print(f"[dim]Total skills for matching: {len(combined_skills)} (base: {len(SKILL_KEYWORDS)}, JD-specific: {len(llm_skills)})[/dim]\n")
    
    # ─── STEP 3: Parse Resumes (Parallel, NO LLM) ───
    step_start = time.time()
    console.print("[bold]Step 3: Parsing Resumes (Parallel)[/bold]")
    
    # Set active skills for resume parsing (combines base + job-specific)
    set_active_skills(combined_skills)
    
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console
    ) as progress:
        task = progress.add_task("Processing resumes...", total=None)
        resumes, parse_stats = process_all_resumes_simple(args.resumes)
        progress.update(task, description=f"[green]✓ Parsed {len(resumes)} resumes")
    
    timings["resume_parsing"] = time.time() - step_start
    console.print(
        f"[dim]Parsed {parse_stats['parsed']} resumes, "
        f"{parse_stats['errors']} errors ({timings['resume_parsing']:.2f}s)[/dim]\n"
    )
    
    # GUARDRAIL #2: Ensure at least 1 valid resume exists
    if not resumes:
        console.print(
            "[red]Error: No valid resumes found. All files were rejected.[/red]\\n"
            "[yellow]Check that files are:[/yellow]\\n"
            "  \u2022 Under 2MB in size\\n"
            "  \u2022 Valid PDF or DOCX format\\n"
            "  \u2022 Not corrupted or password-protected"
        )
        sys.exit(1)
    
    # ─── STEP 4: Generate Embeddings (Batch, NO LLM) ───
    step_start = time.time()
    console.print("[bold]Step 4: Generating Embeddings[/bold]")
    embedding_engine = EmbeddingEngine()
    
    # Get JD embedding
    jd_embedding = embedding_engine.get_jd_embedding(criteria)
    
    # Generate resume embeddings
    resume_embeddings = generate_embeddings(resumes, embedding_engine)
    
    timings["embeddings"] = time.time() - step_start
    console.print(
        f"[green]✓ Generated {len(resume_embeddings)} embeddings[/green] "
        f"[dim]({timings['embeddings']:.2f}s)[/dim]\n"
    )
    
    # ─── STEP 5: FAISS Semantic Matching (NO LLM) ───
    step_start = time.time()
    console.print("[bold]Step 5: Computing Semantic Similarity[/bold]")
    index = embedding_engine.build_faiss_index(resume_embeddings)
    semantic_scores, _ = embedding_engine.search(
        index, jd_embedding, k=len(resumes)
    )
    timings["faiss_matching"] = time.time() - step_start
    console.print(f"[green]✓ Computed similarity scores[/green] [dim]({timings['faiss_matching']:.2f}s)[/dim]\n")
    
    # ─── STEP 6: Algorithmic Ranking (NO LLM) ───
    step_start = time.time()
    console.print("[bold]Step 6: Ranking Candidates[/bold]")
    ranked = rank_candidates(resumes, criteria, semantic_scores)
    timings["ranking"] = time.time() - step_start
    console.print(f"[green]✓ Ranked {len(ranked)} candidates[/green] [dim]({timings['ranking']:.2f}s)[/dim]\n")
    
    # ─── STEP 7: Generate Reports for Top-N (LLM CALL #2) ───
    step_start = time.time()
    top_n = min(args.top, len(ranked))
    console.print(f"[bold]Step 7: Generating Reports for Top {top_n}[/bold]")
    # Display model info based on provider
    model_info = "llama-3.1-8b-instant" if args.provider == "groq" else "8B model"
    console.print(f"[cyan]Calling LLM ({args.provider}/{model_info}) for narrative reports (async)...[/cyan]")
    
    report_generator = ReportGenerator(provider=args.provider, api_key=args.api_key)
    top_candidates = ranked[:top_n]
    
    with_reports = await report_generator.generate_all_reports(top_candidates)
    
    # Update ranked list with reports
    for i, candidate in enumerate(with_reports):
        ranked[i] = candidate
    
    timings["report_generation"] = time.time() - step_start
    console.print(f"[green]✓ Generated {len(with_reports)} reports[/green] [dim]({timings['report_generation']:.2f}s)[/dim]\n")
    
    # ─── STEP 8: Display Results ───
    console.print("[bold]Results:[/bold]\n")
    display_results_table(ranked, top_n=None)
    
    # ─── STEP 9: Save to Files ───
    step_start = time.time()
    console.print("[bold]Saving Results[/bold]")
    criteria_path, skills_path, unified_path = save_results(ranked, criteria, combined_skills, args.output_dir)
    timings["save_results"] = time.time() - step_start
    console.print(f"[green]✓ Criteria: {criteria_path}[/green]")
    console.print(f"[green]✓ Skills: {skills_path}[/green]")
    console.print(f"[green]✓ CV Sorting Results: {unified_path}[/green]\n")
    
    # ─── STEP 10: Interactive Refinement ───
    from interactive_refiner_agent import InteractiveRefiner
    
    # Directly enter interactive refinement mode
    refiner = InteractiveRefiner(
        provider=args.provider, 
        api_key=args.api_key,
        original_jd_text=jd_text,
        embedding_engine=embedding_engine
    )
    
    # Interactive loop
    while True:
        choice = refiner.show_menu()
        
        if choice == 'q':
            console.print("\n[green]✓ Exiting interactive mode...[/green]\n")
            break
        
        refinement_desc = None
        
        if choice == '1':
            # Add new job requirement
            console.print("\n[cyan]💡 Adding new requirement...[/cyan]")
            ranked, refinement_desc, criteria = await refiner.add_new_requirement(
                criteria, resumes, semantic_scores
            )
        
        elif choice == '2':
            # Adjust existing requirement weight
            ranked, refinement_desc, criteria = await refiner.adjust_existing_requirement(
                criteria, resumes, semantic_scores
            )
        
        elif choice == '3':
            # Filter by skills
            ranked, refinement_desc, criteria = refiner.filter_by_skills(
                resumes, criteria, semantic_scores
            )
        
        # Show preview of refined results
        if refinement_desc and refinement_desc != "No change":
            refiner.show_refined_results_preview(ranked, top_n=10)
            
            # Ask if user wants to save
            save_refined = Confirm.ask(
                "Save these refined results?",
                default=True
            )
            
            if save_refined:
                # Save refined results
                _, _, refined_path = save_results(
                    ranked, criteria, combined_skills, args.output_dir, refinement_desc
                )
                console.print(f"\n[green]✓ Saved refined results: {refined_path}[/green]")
            else:
                console.print("\n[yellow]Refined results not saved[/yellow]")
        
        # Ask if user wants to continue refining
        continue_refining = Confirm.ask(
            "\nContinue refining?",
            default=True
        )
        
        if not continue_refining:
            break
    
    # Summary
    strong = sum(1 for r in ranked if r["recommendation"] == "Strong Fit")
    moderate = sum(1 for r in ranked if r["recommendation"] == "Moderate Fit")
    weak = sum(1 for r in ranked if r["recommendation"] == "Weak Fit")
    
    total_time = time.time() - pipeline_start
    timings["total"] = total_time
    
    console.print(Panel.fit(
        f"[bold green]Pipeline Complete![/bold green]\n\n"
        f"Total Candidates: {len(ranked)}\n"
        f"Strong Fit: {strong} | Moderate Fit: {moderate} | Weak Fit: {weak}\n\n"
        f"[cyan]Performance:[/cyan]\n"
        f"  Total Time: {total_time:.2f}s\n"
        f"  Job Analysis: {timings.get('job_analysis', 0):.2f}s\n"
        f"  Resume Parsing: {timings.get('resume_parsing', 0):.2f}s\n"
        f"  Embeddings: {timings.get('embeddings', 0):.2f}s\n"
        f"  Ranking: {timings.get('ranking', 0):.2f}s\n"
        f"  Report Generation: {timings.get('report_generation', 0):.2f}s\n\n"
        f"[yellow]LLM Calls: 2[/yellow] (Job Analysis + {top_n} Reports)",
        border_style="green"
    ))


def main():
    """Main entry point."""
    console.print()
    console.print(Panel.fit(
        "[bold cyan]CV SORTER — Production Pipeline[/bold cyan]\n"
        "Optimized for minimal LLM usage, maximum speed",
        border_style="cyan"
    ))
    console.print()
    
    args = parse_arguments()
    
    try:
        asyncio.run(run_pipeline(args))
    except KeyboardInterrupt:
        console.print("\n[yellow]Interrupted by user[/yellow]")
        sys.exit(1)
    except Exception as e:
        console.print(f"\n[red]Error: {e}[/red]")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
