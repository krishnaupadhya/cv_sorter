"""
Matching module for CV Sorter.
Contains models, prompts, and scoring logic for LLM-based resume matching.
"""
