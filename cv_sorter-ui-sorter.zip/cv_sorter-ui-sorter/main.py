#!/usr/bin/env python3
"""
CV Sorter — Production-Ready Resume Ranking System

Simplified architecture with:
- Only 2 LLM calls per run (job analysis + top-N reports)
- Parallel resume processing (ProcessPoolExecutor)
- Local embeddings + semantic similarity matching
- No caching (fresh analysis every run)

Usage:
    python main.py --resumes ./RESUME/ --jd job-description.txt --api-key <groq-api-key>
    python main.py --resumes ./RESUME/ --jd job-description.txt --api-key <key> --top 10

Architecture:
    1. Job Analyzer Agent (LLM #1) → criteria with weights
    2. Parallel Resume Parser → structured data (NO LLM)
    3. Embedding Engine → semantic vectors (NO LLM)
    4. Semantic Matching → similarity scores (NO LLM)
    5. Ranking Engine → combined ranking (NO LLM)
    6. Report Generator (LLM #2) → top-N narratives only

Author: Senior AI Engineer
Date: March 14, 2026
"""

import argparse
import asyncio
import os
import sys
import time
from pathlib import Path
from datetime import datetime

from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

# Import agents and utilities
from agents.job_analyzer import JobAnalyzer
from agents.resume_parser import process_all_resumes, parse_single_resume, SKILL_KEYWORDS, set_active_skills
from agents.embedding_engine import EmbeddingEngine
from agents.ranking_engine import rank_candidates
from agents.report_generator import ReportGenerator

import numpy as np
from pathlib import Path as PathLib
from concurrent.futures import ProcessPoolExecutor, as_completed


console = Console()


def process_all_resumes_simple(folder: str) -> tuple[list[dict], dict]:
    """
    Process all resumes in parallel.
    
    Returns:
        Tuple of (resumes list, parse_stats dict)
    """
    # Find all resume files
    folder_path = PathLib(folder)
    if not folder_path.exists():
        raise FileNotFoundError(f"Folder not found: {folder}")
    
    files = [
        str(f) for f in folder_path.iterdir()
        if f.suffix.lower() in ['.pdf', '.docx', '.doc']
    ]
    
    if not files:
        raise ValueError(f"No resume files found in {folder}")
    
    resumes = []
    errors = []
    workers = min(os.cpu_count() or 4, len(files))
    
    with ProcessPoolExecutor(max_workers=workers) as executor:
        future_to_file = {
            executor.submit(parse_single_resume, filepath): filepath
            for filepath in files
        }
        
        for future in as_completed(future_to_file):
            filepath = future_to_file[future]
            try:
                result = future.result()
                resumes.append(result)
            except Exception as e:
                errors.append({"file": filepath, "error": str(e)})
                # Log validation errors but continue
                filename = os.path.basename(filepath)
                console.print(f"[yellow]⚠ Skipped {filename}: {e}[/yellow]")
    
    stats = {
        "parsed": len(resumes),
        "errors": len(errors)
    }
    
    return resumes, stats


def generate_embeddings(
    resumes: list[dict],
    embedding_engine: EmbeddingEngine
) -> np.ndarray:
    """
    Generate embeddings for all resumes.
    
    Returns:
        Numpy array of embeddings
    """
    texts = [resume["skill_text"] for resume in resumes]
    embeddings = embedding_engine.encode_batch(texts)
    return np.array(embeddings)


def parse_arguments():
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(
        description="CV Sorter — Production-Ready Resume Ranking System",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Rank resumes with Groq API (command-line mode)
  python main.py --resumes ./RESUME/ --jd job-description.txt --api-key gsk_...

  # Use Ollama (local, private, no API key needed)
  python main.py --resumes ./RESUME/ --jd job-description.txt --provider ollama

  # Show only top 5 candidates
  python main.py --resumes ./RESUME/ --jd job-description.txt --api-key <key> --top 5
  
  # Launch web interface (UI mode)
  python main.py --api-key <key> --mode ui
  python main.py --api-key <key> --mode ui --port 8080

Get API key:
  Groq: https://console.groq.com (free tier: 840 tok/sec, Llama 3.1 8B)
  
Prerequisites for Ollama:
  brew install ollama
  ollama pull llama3.1
  ollama serve  # Must be running
        """
    )
    
    parser.add_argument(
        "--resumes",
        required=False,
        help="Path to directory containing resume files (PDF/DOCX). Required for CLI mode."
    )
    
    parser.add_argument(
        "--jd",
        required=False,
        help="Path to job description file (TXT). Required for CLI mode."
    )
    
    parser.add_argument(
        "--provider",
        choices=["groq", "ollama", "google"],
        default="groq",
        help="LLM provider: groq (cloud, fast), ollama (local, private), google (cloud)"
    )
    
    parser.add_argument(
        "--api-key",
        required=False,
        help="API key for cloud providers (groq, google). Not needed for ollama."
    )
    
    parser.add_argument(
        "--top",
        type=int,
        default=10,
        help="Number of top candidates to generate reports for (default: 10)"
    )
    
    parser.add_argument(
        "--output-dir",
        default="output/results",
        help="Directory to save results (default: output/results)"
    )
    
    
    parser.add_argument(
        "--mode",
        choices=["cli", "ui"],
        default="cli",
        help="Run mode: cli (command-line, default) or ui (web interface)"
    )
    
    parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="Host for web UI (default: 127.0.0.1)"
    )
    
    parser.add_argument(
        "--port",
        type=int,
        default=5000,
        help="Port for web UI (default: 5000)"
    )
    
    return parser.parse_args()


def load_job_description(jd_path: str) -> str:
    """Load job description from file."""
    path = Path(jd_path)
    if not path.exists():
        raise FileNotFoundError(f"Job description file not found: {jd_path}")
    
    return path.read_text(encoding='utf-8')


def display_results_table(ranked: list, top_n: int = None):
    """Display ranking results in a table."""
    table = Table(title="Candidate Rankings (Semantic Similarity)", show_header=True, header_style="bold cyan")
    
    table.add_column("Rank", style="dim", width=8, justify="center")
    table.add_column("Name", style="bold", width=50)
    table.add_column("Score", justify="right", width=12)
    table.add_column("Fit", style="bold", width=18, justify="center")
    
    display_count = len(ranked) if top_n is None else min(top_n, len(ranked))
    
    for i, candidate in enumerate(ranked[:display_count], 1):
        # Color recommendation
        rec = candidate["recommendation"]
        if rec == "Strong Fit":
            rec_style = "green"
        elif rec == "Moderate Fit":
            rec_style = "yellow"
        else:
            rec_style = "red"
        
        table.add_row(
            f"#{i}",
            candidate["name"][:48],
            f"{candidate['combined_score']:.1f}",
            f"[{rec_style}]{rec}[/{rec_style}]"
        )
    
    console.print(table)
    console.print()


def save_results(ranked: list, criteria: list, skills: list, output_dir: str) -> tuple[str, str, str, str]:
    """
    Save results to JSON and text files.
    
    GUARDRAIL #3: Create timestamped folder containing:
    - criteria.json (extracted job criteria)
    - skills.json (combined skill keywords)
    - ranking.json (full ranking data)
    - ranking.txt (human-readable report)
    """
    import json
    
    # Create output directory
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)
    
    # GUARDRAIL #3: Create timestamped subfolder
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    ranking_folder = output_path / f"ranking_{timestamp}"
    ranking_folder.mkdir(parents=True, exist_ok=True)
    
    # Save criteria JSON
    criteria_file = ranking_folder / "criteria.json"
    with open(criteria_file, 'w', encoding='utf-8') as f:
        # Clean criteria data for JSON serialization
        cleaned_criteria = [
            {k: v for k, v in criterion.items() if k not in ['embedding', 'raw_text']}
            for criterion in criteria
        ]
        json.dump(cleaned_criteria, f, indent=2, ensure_ascii=False)
    
    # Save skills JSON
    skills_file = ranking_folder / "skills.json"
    with open(skills_file, 'w', encoding='utf-8') as f:
        json.dump({
            "total_skills": len(skills),
            "skills": sorted(skills)  # Sort for easier review
        }, f, indent=2, ensure_ascii=False)
    
    # Save ranking JSON
    json_file = ranking_folder / "ranking.json"
    with open(json_file, 'w', encoding='utf-8') as f:
        # Clean ranked data for JSON serialization
        cleaned_ranked = [
            {k: v for k, v in candidate.items() if k not in ['embedding', 'raw_text', 'skill_text', 'file_hash']}
            for candidate in ranked
        ]
        json.dump(cleaned_ranked, f, indent=2, ensure_ascii=False)
    
    # Save text summary
    txt_file = ranking_folder / "ranking.txt"
    with open(txt_file, 'w', encoding='utf-8') as f:
        f.write(f"CV Sorting Results\n")
        f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"Total Candidates: {len(ranked)}\n")
        f.write("=" * 80 + "\n\n")
        
        for i, candidate in enumerate(ranked, 1):
            f.write(f"Rank #{i}: {candidate['name']}\n")
            f.write(f"Score: {candidate['combined_score']:.1f}/100 (Semantic Similarity)\n")
            f.write(f"Recommendation: {candidate['recommendation']}\n")
            f.write(f"Email: {candidate['email']}\n")
            f.write(f"Experience: {candidate['experience_years']} years\n")
            f.write(f"Skills: {', '.join(candidate.get('skills', []))}\n")
            
            if "report_text" in candidate and candidate["report_text"]:
                f.write(f"\nAssessment:\n{candidate['report_text']}\n")
            
            f.write("\n" + "=" * 80 + "\n\n")
    
    return str(criteria_file), str(skills_file), str(json_file), str(txt_file)


async def run_pipeline(args):
    """
    Main pipeline orchestrator.
    
    Makes exactly 2 LLM calls:
    1. Job description analysis (criteria extraction)
    2. Report generation for top-N candidates
    
    Everything else is local processing.
    """
    
    # Validate required arguments for CLI mode
    if not args.resumes:
        console.print("[red]Error: --resumes is required in CLI mode[/red]")
        sys.exit(1)
    
    if not args.jd:
        console.print("[red]Error: --jd is required in CLI mode[/red]")
        sys.exit(1)
    
    # Performance tracking
    timings = {}
    pipeline_start = time.time()
    
    # Validate API key requirement based on provider
    if args.provider in ["groq", "google"] and not args.api_key:
        console.print(
            f"[red]Error: --api-key is required for provider '{args.provider}'[/red]\n"
            f"Get an API key at: https://console.groq.com (groq) or https://aistudio.google.com (google)"
        )
        sys.exit(1)
    
    # Load job description
    step_start = time.time()
    console.print("\n[bold]Step 1: Loading Job Description[/bold]")
    jd_text = load_job_description(args.jd)
    timings["load_jd"] = time.time() - step_start
    console.print(f"[green]✓ Loaded {len(jd_text)} characters[/green] [dim]({timings['load_jd']:.2f}s)[/dim]\n")
    
    # ─── STEP 2: Job Analysis (LLM CALL #1) ───
    step_start = time.time()
    console.print("[bold]Step 2: Analyzing Job Requirements[/bold]")
    console.print(f"[cyan]Calling LLM ({args.provider}) to extract criteria and skills...[/cyan]")
    job_analyzer = JobAnalyzer(provider=args.provider, api_key=args.api_key)
    criteria, llm_skills = job_analyzer.analyze(jd_text)
    
    # Combine LLM-extracted skills with hardcoded skills
    combined_skills = list(set(SKILL_KEYWORDS + llm_skills))  # Remove duplicates
    
    timings["job_analysis"] = time.time() - step_start
    console.print(
        f"[green]✓ Extracted {len(criteria)} criteria + {len(llm_skills)} job-specific skills[/green] "
        f"[dim]({timings['job_analysis']:.2f}s)[/dim]"
    )
    console.print(f"[dim]Top criteria: {criteria[0]['name']} (weight: {criteria[0]['weight']})[/dim]")
    console.print(f"[dim]Total skills for matching: {len(combined_skills)} (base: {len(SKILL_KEYWORDS)}, JD-specific: {len(llm_skills)})[/dim]\n")
    
    # ─── STEP 3: Parse Resumes (Parallel, NO LLM) ───
    step_start = time.time()
    console.print("[bold]Step 3: Parsing Resumes (Parallel)[/bold]")
    
    # Set active skills for resume parsing (combines base + job-specific)
    set_active_skills(combined_skills)
    
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console
    ) as progress:
        task = progress.add_task("Processing resumes...", total=None)
        resumes, parse_stats = process_all_resumes_simple(args.resumes)
        progress.update(task, description=f"[green]✓ Parsed {len(resumes)} resumes")
    
    timings["resume_parsing"] = time.time() - step_start
    console.print(
        f"[dim]Parsed {parse_stats['parsed']} resumes, "
        f"{parse_stats['errors']} errors ({timings['resume_parsing']:.2f}s)[/dim]\n"
    )
    
    # GUARDRAIL #2: Ensure at least 1 valid resume exists
    if not resumes:
        console.print(
            "[red]Error: No valid resumes found. All files were rejected.[/red]\\n"
            "[yellow]Check that files are:[/yellow]\\n"
            "  \u2022 Under 2MB in size\\n"
            "  \u2022 Valid PDF or DOCX format\\n"
            "  \u2022 Not corrupted or password-protected"
        )
        sys.exit(1)
    
    # ─── STEP 4: Generate Embeddings (Batch, NO LLM) ───
    step_start = time.time()
    console.print("[bold]Step 4: Generating Embeddings[/bold]")
    embedding_engine = EmbeddingEngine()
    
    # Get JD embedding
    jd_embedding = embedding_engine.get_jd_embedding(criteria)
    
    # Generate resume embeddings
    resume_embeddings = generate_embeddings(resumes, embedding_engine)
    
    timings["embeddings"] = time.time() - step_start
    console.print(
        f"[green]✓ Generated {len(resume_embeddings)} embeddings[/green] "
        f"[dim]({timings['embeddings']:.2f}s)[/dim]\n"
    )
    
    # ─── STEP 5: FAISS Semantic Matching (NO LLM) ───
    step_start = time.time()
    console.print("[bold]Step 5: Computing Semantic Similarity[/bold]")
    index = embedding_engine.build_faiss_index(resume_embeddings)
    semantic_scores, _ = embedding_engine.search(
        index, jd_embedding, k=len(resumes)
    )
    timings["faiss_matching"] = time.time() - step_start
    console.print(f"[green]✓ Computed similarity scores[/green] [dim]({timings['faiss_matching']:.2f}s)[/dim]\n")
    
    # ─── STEP 6: Algorithmic Ranking (NO LLM) ───
    step_start = time.time()
    console.print("[bold]Step 6: Ranking Candidates[/bold]")
    ranked = rank_candidates(resumes, criteria, semantic_scores)
    timings["ranking"] = time.time() - step_start
    console.print(f"[green]✓ Ranked {len(ranked)} candidates[/green] [dim]({timings['ranking']:.2f}s)[/dim]\n")
    
    # ─── STEP 7: Generate Reports for Top-N (LLM CALL #2) ───
    step_start = time.time()
    top_n = min(args.top, len(ranked))
    console.print(f"[bold]Step 7: Generating Reports for Top {top_n}[/bold]")
    console.print(f"[cyan]Calling LLM ({args.provider}) for narrative reports (async)...[/cyan]")
    
    report_generator = ReportGenerator(provider=args.provider, api_key=args.api_key)
    top_candidates = ranked[:top_n]
    
    with_reports = await report_generator.generate_all_reports(top_candidates)
    
    # Update ranked list with reports
    for i, candidate in enumerate(with_reports):
        ranked[i] = candidate
    
    timings["report_generation"] = time.time() - step_start
    console.print(f"[green]✓ Generated {len(with_reports)} reports[/green] [dim]({timings['report_generation']:.2f}s)[/dim]\n")
    
    # ─── STEP 8: Display Results ───
    console.print("[bold]Results:[/bold]\n")
    display_results_table(ranked, top_n=None)
    
    # ─── STEP 9: Save to Files ───
    step_start = time.time()
    console.print("[bold]Saving Results[/bold]")
    criteria_path, skills_path, json_path, txt_path = save_results(ranked, criteria, combined_skills, args.output_dir)
    timings["save_results"] = time.time() - step_start
    console.print(f"[green]✓ Criteria: {criteria_path}[/green]")
    console.print(f"[green]✓ Skills: {skills_path}[/green]")
    console.print(f"[green]✓ JSON: {json_path}[/green]")
    console.print(f"[green]✓ Text: {txt_path}[/green]\n")
    
    # Summary
    strong = sum(1 for r in ranked if r["recommendation"] == "Strong Fit")
    moderate = sum(1 for r in ranked if r["recommendation"] == "Moderate Fit")
    weak = sum(1 for r in ranked if r["recommendation"] == "Weak Fit")
    
    total_time = time.time() - pipeline_start
    timings["total"] = total_time
    
    console.print(Panel.fit(
        f"[bold green]Pipeline Complete![/bold green]\n\n"
        f"Total Candidates: {len(ranked)}\n"
        f"Strong Fit: {strong} | Moderate Fit: {moderate} | Weak Fit: {weak}\n\n"
        f"[cyan]Performance:[/cyan]\n"
        f"  Total Time: {total_time:.2f}s\n"
        f"  Job Analysis: {timings.get('job_analysis', 0):.2f}s\n"
        f"  Resume Parsing: {timings.get('resume_parsing', 0):.2f}s\n"
        f"  Embeddings: {timings.get('embeddings', 0):.2f}s\n"
        f"  Ranking: {timings.get('ranking', 0):.2f}s\n"
        f"  Report Generation: {timings.get('report_generation', 0):.2f}s\n\n"
        f"[yellow]LLM Calls: 2[/yellow] (Job Analysis + {top_n} Reports)",
        border_style="green"
    ))


def main():
    """Main entry point."""
    console.print()
    console.print(Panel.fit(
        "[bold cyan]CV SORTER — Production Pipeline[/bold cyan]\n"
        "Optimized for minimal LLM usage, maximum speed",
        border_style="cyan"
    ))
    console.print()
    
    args = parse_arguments()
    
    # Check if running in UI mode
    if args.mode == "ui":
        # Launch web interface
        try:
            from pathlib import Path
            frontend_path = Path(__file__).parent / "frontend"
            
            if not frontend_path.exists():
                console.print("[red]Error: frontend directory not found[/red]")
                console.print("[yellow]Make sure the frontend folder exists in the project root[/yellow]")
                sys.exit(1)
            
            # Import and run Flask app
            sys.path.insert(0, str(frontend_path))
            from app import run_server
            
            # Validate API key for UI mode
            if not args.api_key:
                console.print("[red]Error: --api-key is required for UI mode[/red]")
                console.print("[yellow]Get a free API key at https://console.groq.com[/yellow]")
                sys.exit(1)
            
            run_server(host=args.host, port=args.port, api_key=args.api_key, provider=args.provider)
            
        except ImportError as e:
            console.print(f"[red]Error: Failed to import Flask app[/red]")
            console.print(f"[yellow]Make sure Flask is installed: pip install flask flask-cors[/yellow]")
            console.print(f"[dim]Details: {e}[/dim]")
            sys.exit(1)
        except Exception as e:
            console.print(f"\n[red]Error: {e}[/red]")
            import traceback
            traceback.print_exc()
            sys.exit(1)
        return
    
    # Run CLI mode (existing logic)
    try:
        asyncio.run(run_pipeline(args))
    except KeyboardInterrupt:
        console.print("\n[yellow]Interrupted by user[/yellow]")
        sys.exit(1)
    except Exception as e:
        console.print(f"\n[red]Error: {e}[/red]")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
