"""
Configuration module for CV Sorter LLM providers.

This module provides a unified interface for initializing different LLM providers
(Groq API, Ollama local, Google AI Studio) with runtime API key management.

Security Note:
- API keys are NEVER hardcoded or stored in .env files
- Keys are passed at runtime via CLI arguments or environment variables
- This prevents accidental credential leakage in version control
"""

from typing import Literal


# Type alias for supported providers
ProviderType = Literal["groq", "ollama", "google"]


def get_llm(provider: ProviderType = "groq", api_key: str = None, temperature: float = 0.1):
    """
    Initialize and return an LLM instance based on the specified provider.
    
    This function provides a unified interface for different LLM providers,
    handling the differences in initialization and authentication.
    
    Args:
        provider: One of "groq", "ollama", or "google"
        api_key: API key for cloud providers (groq, google). Not needed for ollama.
        temperature: Controls randomness (0.0-1.0). Lower = more deterministic.
                    Default 0.1 for consistent scoring.
    
    Returns:
        An initialized LangChain chat model instance
    
    Raises:
        ValueError: If provider is not supported or API key is missing for cloud providers
        ImportError: If required provider package is not installed
    
    Example:
        >>> # Using Groq (fast cloud inference)
        >>> llm = get_llm(provider="groq", api_key="gsk_...")
        
        >>> # Using Ollama (local, private)
        >>> llm = get_llm(provider="ollama")  # No API key needed
    """
    
    if provider == "groq":
        if not api_key:
            raise ValueError(
                "API key is required for Groq provider. "
                "Get one at: https://console.groq.com"
            )
        
        try:
            from langchain_groq import ChatGroq
        except ImportError:
            raise ImportError(
                "langchain-groq is not installed. "
                "Install it with: pip install langchain-groq"
            )
        
        # Llama 3.1 8B Instant - fastest free inference (840 tok/sec)
        # 128K context window allows multiple resumes + JD in one prompt
        return ChatGroq(
            model="llama-3.1-8b-instant",
            api_key=api_key,
            temperature=temperature,
            max_retries=3  # Auto-retry on API errors
        )
    
    elif provider == "ollama":
        # Ollama runs locally - no API key needed
        # Requires: brew install ollama && ollama pull llama3.1
        try:
            from langchain_ollama import ChatOllama
        except ImportError:
            raise ImportError(
                "langchain-ollama is not installed. "
                "Install it with: pip install langchain-ollama"
            )
        
        return ChatOllama(
            model="llama3.1",
            temperature=temperature,
            base_url="http://localhost:11434"  # Default Ollama REST API
        )
    
    elif provider == "google":
        if not api_key:
            raise ValueError(
                "API key is required for Google AI Studio. "
                "Get one at: https://aistudio.google.com"
            )
        
        try:
            from langchain_google_genai import ChatGoogleGenerativeAI
        except ImportError:
            raise ImportError(
                "langchain-google-genai is not installed. "
                "Install it with: pip install langchain-google-genai"
            )
        
        return ChatGoogleGenerativeAI(
            model="gemini-2.0-flash-exp",
            google_api_key=api_key,
            temperature=temperature
        )
    
    else:
        raise ValueError(
            f"Unknown provider: {provider}. "
            f"Supported providers: groq, ollama, google"
        )


def validate_provider(provider: str) -> bool:
    """
    Check if a provider name is valid.
    
    Args:
        provider: Provider name to validate
    
    Returns:
        True if provider is supported, False otherwise
    """
    return provider in ["groq", "ollama", "google"]
