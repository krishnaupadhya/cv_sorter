"""
Resume parser module for extracting text from PDF and DOCX files.

This module provides robust document parsing with:
- Auto-detection of file format (PDF vs DOCX)
- OCR support for scanned PDFs using pytesseract
- Table structure preservation (important for resume layouts)
- Text cleaning and normalization
- Regex-based extraction for critical fields (email, phone, name)
- Memory-efficient page-by-page processing for large PDFs

Supported formats:
- PDF (via pdfplumber) - preserves layout and tables
- Scanned PDFs (via OCR with pytesseract)
- DOCX (via python-docx) - extracts paragraphs and tables

Not supported:
- Password-protected files
"""

import os
import re
from pathlib import Path
from typing import Optional, Dict, List

import pdfplumber
from docx import Document
try:
    from PIL import Image
    import pytesseract
    OCR_AVAILABLE = True
except ImportError:
    OCR_AVAILABLE = False

from parsers.document_loader import DocumentLoader, DocumentLoadError


class ResumeParseError(Exception):
    """Custom exception for resume parsing errors."""
    pass


def parse_resume(file_path: str) -> str:
    """
    Extract text content from a resume file (PDF or DOCX).
    
    Uses DocumentLoader (pymupdf4llm + enhanced DOCX) as primary backend,
    falling back to legacy pdfplumber/python-docx extraction on failure.
    
    Args:
        file_path: Absolute or relative path to resume file
    
    Returns:
        Extracted text as a single string
    
    Raises:
        ResumeParseError: If file cannot be parsed
        FileNotFoundError: If file does not exist
    """
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"Resume file not found: {file_path}")
    
    file_size_mb = path.stat().st_size / (1024 * 1024)
    if file_size_mb > 10:
        print(f"Warning: Large file ({file_size_mb:.1f}MB): {path.name}")
    
    extension = path.suffix.lower()
    if extension not in ('.pdf', '.docx', '.doc'):
        raise ResumeParseError(
            f"Unsupported file format: {extension}. "
            f"Supported formats: .pdf, .docx"
        )
    
    # Primary: DocumentLoader (pymupdf4llm for PDF, enhanced python-docx for DOCX)
    try:
        loader = DocumentLoader()
        text = loader.load(file_path)
        if text and text.strip():
            return text
    except DocumentLoadError:
        pass
    except Exception:
        pass
    
    # Fallback: legacy extraction
    try:
        if extension == '.pdf':
            return _parse_pdf(file_path)
        else:
            return _parse_docx(file_path)
    except Exception as e:
        raise ResumeParseError(
            f"Failed to parse {path.name}: {str(e)}"
        ) from e


def _parse_pdf(file_path: str) -> str:
    """
    Extract text from PDF using pdfplumber with OCR fallback.
    
    pdfplumber is chosen over PyPDF2 or PyMuPDF because:
    1. Preserves table structure (common in resumes)
    2. Better handling of multi-column layouts
    3. Extracts text with proper spacing
    
    If no text is found (scanned PDF), attempts OCR extraction.
    Processes page-by-page for memory efficiency on large files.
    
    Args:
        file_path: Path to PDF file
    
    Returns:
        Extracted and cleaned text with preserved structure
    
    Raises:
        ResumeParseError: If PDF is corrupted, encrypted, or cannot be read
    """
    extracted_text = []
    ocr_used = False
    
    try:
        with pdfplumber.open(file_path) as pdf:
            # Check if PDF has pages
            if len(pdf.pages) == 0:
                raise ResumeParseError("PDF has no pages")
            
            # Extract text page by page (memory efficient)
            for page_num, page in enumerate(pdf.pages, start=1):
                page_text = page.extract_text()
                
                # Check if page is likely a scanned image (no extractable text)
                if not page_text or len(page_text.strip()) < 10:
                    # Try OCR as fallback
                    try:
                        page_text = extract_text_with_ocr(file_path, page)
                        ocr_used = True
                        if page_num == 1:
                            print(f"  ℹ Using OCR for scanned PDF")
                    except ResumeParseError as e:
                        if page_num == 1:  # First page is critical
                            raise
                        else:
                            # Just warn for subsequent pages
                            print(f"Warning: Page {page_num} has no text and OCR failed")
                            continue
                
                if page_text and page_text.strip():
                    extracted_text.append(page_text)
                
                # Extract tables if present (common in resumes for skills/experience)
                if not ocr_used:  # Tables don't work well with OCR
                    tables = page.extract_tables()
                    if tables:
                        for table in tables:
                            # Convert table to text format
                            table_text = _format_table(table)
                            if table_text:
                                extracted_text.append(table_text)
    
    except pdfplumber.pdfminer.pdfparser.PDFSyntaxError:
        raise ResumeParseError("PDF file is corrupted or invalid")
    except pdfplumber.pdfminer.pdfpage.PDFTextExtractionNotAllowed:
        raise ResumeParseError("PDF is password-protected or encrypted")
    
    # Join all pages with double newline separator
    full_text = "\n\n".join(extracted_text)
    
    # Clean and normalize text
    full_text = clean_text(full_text)
    
    if not full_text.strip():
        raise ResumeParseError("No text could be extracted from PDF")
    
    return full_text


def _parse_docx(file_path: str) -> str:
    """
    Extract text from DOCX file using python-docx.
    
    Extracts both paragraphs and tables, preserving document structure.
    
    Args:
        file_path: Path to DOCX file
    
    Returns:
        Extracted and cleaned text
    
    Raises:
        ResumeParseError: If DOCX is corrupted or invalid
    """
    extracted_text = []
    
    try:
        doc = Document(file_path)
        
        # Extract paragraphs
        for paragraph in doc.paragraphs:
            text = paragraph.text.strip()
            if text:  # Skip empty paragraphs
                extracted_text.append(text)
        
        # Extract tables
        for table in doc.tables:
            table_text = _format_docx_table(table)
            if table_text:
                extracted_text.append(table_text)
    
    except Exception as e:
        raise ResumeParseError(f"Failed to parse DOCX: {str(e)}")
    
    # Join with single newline (DOCX paragraphs are already separated)
    full_text = "\n".join(extracted_text)
    
    # Clean and normalize text
    full_text = clean_text(full_text)
    
    if not full_text.strip():
        raise ResumeParseError("No text could be extracted from DOCX")
    
    return full_text


def _format_table(table: list) -> str:
    """
    Format a pdfplumber table into readable text.
    
    Args:
        table: List of lists representing table rows
    
    Returns:
        Formatted table text
    """
    if not table:
        return ""
    
    # Filter out None values and empty strings
    formatted_rows = []
    for row in table:
        filtered_row = [str(cell).strip() for cell in row if cell]
        if filtered_row:  # Only add non-empty rows
            formatted_rows.append(" | ".join(filtered_row))
    
    return "\n".join(formatted_rows) if formatted_rows else ""


def _format_docx_table(table) -> str:
    """
    Format a python-docx table into readable text.
    
    Args:
        table: python-docx Table object
    
    Returns:
        Formatted table text
    """
    formatted_rows = []
    
    for row in table.rows:
        cells = [cell.text.strip() for cell in row.cells if cell.text.strip()]
        if cells:
            formatted_rows.append(" | ".join(cells))
    
    return "\n".join(formatted_rows) if formatted_rows else ""


def get_filename_without_extension(file_path: str) -> str:
    """
    Extract filename without extension (useful for candidate names).
    
    Args:
        file_path: Path to file
    
    Returns:
        Filename without extension
    
    Example:
        >>> get_filename_without_extension("resumes/john_doe_resume.pdf")
        "john_doe_resume"
    """
    return Path(file_path).stem


def extract_structured_info(text: str) -> Dict[str, any]:
    """
    Extract structured information from resume text using regex patterns.
    
    This provides a fallback mechanism when LLM extraction fails or as
    validation for LLM outputs. Uses proven regex patterns for:
    - Email addresses
    - Phone numbers (various formats)
    - Names (from top of document)
    - URLs/LinkedIn profiles
    
    Args:
        text: Raw resume text
    
    Returns:
        Dictionary with extracted fields (email, phone, potential_name, etc.)
    """
    info = {
        "email": None,
        "phone": None,
        "potential_name": None,
        "linkedin": None,
        "github": None
    }
    
    # Email regex (comprehensive pattern)
    email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
    email_matches = re.findall(email_pattern, text)
    if email_matches:
        info["email"] = email_matches[0]  # Take first email found
    
    # Phone number regex (handles various formats)
    # Matches: +1-234-567-8900, (123) 456-7890, 123.456.7890, 1234567890
    phone_patterns = [
        r'\+?\d{1,3}[-.\s]?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}',  # International
        r'\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}',  # US/Canada
        r'\d{10}',  # Simple 10 digits
    ]
    for pattern in phone_patterns:
        phone_matches = re.findall(pattern, text)
        if phone_matches:
            info["phone"] = phone_matches[0]
            break
    
    # Extract potential name from first few lines
    # Heuristic: Name is usually in first 3 non-empty lines, all caps or title case
    lines = [line.strip() for line in text.split('\n') if line.strip()]
    for line in lines[:5]:  # Check first 5 lines
        # Skip lines with common header keywords
        if any(kw in line.lower() for kw in ['resume', 'cv', 'curriculum', 'vitae', 'email', 'phone']):
            continue
        # Name is usually 2-4 words, not too long
        words = line.split()
        if 2 <= len(words) <= 4 and len(line) < 50:
            # Check if it looks like a name (title case or all caps)
            if line.istitle() or line.isupper():
                info["potential_name"] = line
                break
    
    # LinkedIn profile
    linkedin_pattern = r'linkedin\.com/in/[A-Za-z0-9_-]+'
    linkedin_matches = re.findall(linkedin_pattern, text, re.IGNORECASE)
    if linkedin_matches:
        info["linkedin"] = linkedin_matches[0]
    
    # GitHub profile
    github_pattern = r'github\.com/[A-Za-z0-9_-]+'
    github_matches = re.findall(github_pattern, text, re.IGNORECASE)
    if github_matches:
        info["github"] = github_matches[0]
    
    return info


def clean_text(text: str) -> str:
    """
    Clean and normalize extracted text.
    
    Operations:
    - Remove excessive whitespace
    - Normalize line breaks
    - Remove page numbers and headers/footers
    - Fix common OCR errors
    
    Args:
        text: Raw extracted text
    
    Returns:
        Cleaned text
    """
    if not text:
        return ""
    
    # Remove excessive whitespace
    text = re.sub(r' +', ' ', text)
    
    # Normalize line breaks (max 2 consecutive)
    text = re.sub(r'\n{3,}', '\n\n', text)
    
    # Remove common page footers/headers
    text = re.sub(r'Page \d+ of \d+', '', text, flags=re.IGNORECASE)
    text = re.sub(r'^\d+$', '', text, flags=re.MULTILINE)  # Standalone page numbers
    
    # Fix common OCR errors
    replacements = {
        r'\bl\b': 'I',  # lowercase L to uppercase I in isolation
        r'\bO\b': '0',  # uppercase O to zero in isolation (phone numbers)
    }
    for pattern, replacement in replacements.items():
        text = re.sub(pattern, replacement, text)
    
    return text.strip()


def extract_text_with_ocr(pdf_path: str, page) -> str:
    """
    Extract text from a PDF page using OCR (for scanned documents).
    
    Args:
        pdf_path: Path to PDF file  
        page: pdfplumber page object
    
    Returns:
        OCR-extracted text
    
    Raises:
        ResumeParseError: If OCR is not available or fails
    """
    if not OCR_AVAILABLE:
        raise ResumeParseError(
            "PDF appears to be scanned but OCR is not available. "
            "Install with: pip install pytesseract pillow && brew install tesseract"
        )
    
    try:
        # Convert PDF page to image
        image = page.to_image(resolution=300)  # High res for better OCR
        pil_image = image.original
        
        # Run OCR
        text = pytesseract.image_to_string(pil_image)
        
        return text
    except Exception as e:
        raise ResumeParseError(f"OCR extraction failed: {str(e)}")
