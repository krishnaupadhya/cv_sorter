"""
Parsers module for CV Sorter.
Handles extraction of text from PDF/DOCX resumes and job descriptions.
"""
