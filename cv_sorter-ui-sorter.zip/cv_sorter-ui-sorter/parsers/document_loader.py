"""
Multi-backend document loader for robust resume parsing.

Extraction pipeline with fallback chain:
1. pymupdf4llm (PDF→Markdown with layout awareness, tables, headers)
2. pdfplumber (traditional text + table extraction)
3. python-docx (DOCX paragraph + table extraction)
4. OCR fallback via pymupdf's built-in OCR support

pymupdf4llm advantages over pdfplumber:
- Layout-aware extraction preserving multi-column structure
- Automatic header detection via font size analysis
- Table extraction as Markdown tables
- Handles complex resume layouts (sidebars, columns, infographics)
- Built-in OCR support for scanned PDFs
"""

import os
import re
from pathlib import Path
from typing import Optional

# Try importing pymupdf4llm (primary PDF backend)
try:
    import pymupdf4llm
    import pymupdf
    PYMUPDF4LLM_AVAILABLE = True
except ImportError:
    PYMUPDF4LLM_AVAILABLE = False

# Existing backends
import pdfplumber
from docx import Document

try:
    from PIL import Image
    import pytesseract
    OCR_AVAILABLE = True
except ImportError:
    OCR_AVAILABLE = False


class DocumentLoadError(Exception):
    """Raised when document loading fails across all backends."""
    pass


class DocumentLoader:
    """
    Multi-backend document loader with automatic format detection and fallback.
    
    Supports PDF and DOCX formats with intelligent backend selection:
    - PDFs: pymupdf4llm → pdfplumber → OCR
    - DOCX: Enhanced python-docx extraction
    """
    
    def load(self, file_path: str) -> str:
        """
        Load and extract text from a document file.
        
        Args:
            file_path: Path to PDF or DOCX file
            
        Returns:
            Extracted text (Markdown-formatted for PDFs when pymupdf4llm is available)
            
        Raises:
            FileNotFoundError: If file doesn't exist
            DocumentLoadError: If extraction fails with all backends
        """
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        
        extension = path.suffix.lower()
        
        if extension == '.pdf':
            return self._load_pdf(file_path)
        elif extension in ('.docx', '.doc'):
            return self._load_docx(file_path)
        else:
            raise DocumentLoadError(f"Unsupported format: {extension}")
    
    def _load_pdf(self, file_path: str) -> str:
        """
        Extract text from PDF with fallback chain:
        1. pymupdf4llm (layout-aware Markdown)
        2. pdfplumber (traditional extraction)
        """
        errors = []
        
        # Backend 1: pymupdf4llm (best for LLM pipelines)
        if PYMUPDF4LLM_AVAILABLE:
            try:
                text = self._extract_with_pymupdf4llm(file_path)
                if text and len(text.strip()) > 50:
                    return text
            except Exception as e:
                errors.append(f"pymupdf4llm: {e}")
        
        # Backend 2: pdfplumber (reliable fallback)
        try:
            text = self._extract_with_pdfplumber(file_path)
            if text and len(text.strip()) > 50:
                return text
        except Exception as e:
            errors.append(f"pdfplumber: {e}")
        
        # Backend 3: pymupdf4llm with OCR forced
        if PYMUPDF4LLM_AVAILABLE:
            try:
                text = self._extract_with_pymupdf4llm(file_path, force_ocr=True)
                if text and len(text.strip()) > 50:
                    return text
            except Exception as e:
                errors.append(f"pymupdf4llm OCR: {e}")
        
        raise DocumentLoadError(
            f"All PDF extraction backends failed for {Path(file_path).name}: "
            + "; ".join(errors)
        )
    
    def _extract_with_pymupdf4llm(
        self, file_path: str, force_ocr: bool = False
    ) -> str:
        """
        Extract PDF text using pymupdf4llm for layout-aware Markdown output.
        
        Key features:
        - Multi-column layout detection and proper reading order
        - Table extraction as Markdown tables
        - Header detection via font size analysis
        - Optional OCR for scanned documents
        
        Args:
            file_path: Path to PDF
            force_ocr: If True, apply OCR to all pages
            
        Returns:
            Markdown-formatted text preserving document structure
        """
        kwargs = {
            "header": False,   # Skip repetitive page headers
            "footer": False,   # Skip repetitive page footers
            "force_text": True, # Extract text even under images
        }
        
        if force_ocr:
            kwargs["force_ocr"] = True
        
        md_text = pymupdf4llm.to_markdown(file_path, **kwargs)
        
        # Clean up pymupdf4llm output
        md_text = self._clean_markdown(md_text)
        
        return md_text
    
    def _extract_with_pdfplumber(self, file_path: str) -> str:
        """
        Extract PDF text using pdfplumber (reliable fallback).
        Preserves table structure.
        """
        extracted = []
        
        with pdfplumber.open(file_path) as pdf:
            if not pdf.pages:
                raise DocumentLoadError("PDF has no pages")
            
            for page in pdf.pages:
                page_text = page.extract_text()
                if page_text and page_text.strip():
                    extracted.append(page_text)
                
                # Extract tables
                tables = page.extract_tables()
                if tables:
                    for table in tables:
                        table_text = self._format_table(table)
                        if table_text:
                            extracted.append(table_text)
        
        return self._clean_text("\n\n".join(extracted))
    
    def _load_docx(self, file_path: str) -> str:
        """
        Extract text from DOCX with enhanced structure preservation.
        
        Improvements over basic python-docx extraction:
        - Preserves heading hierarchy (H1, H2, etc.)
        - Extracts hyperlinks
        - Better table formatting
        - Handles header/footer content
        """
        doc = Document(file_path)
        sections = []
        
        # Extract paragraphs with style awareness
        for paragraph in doc.paragraphs:
            text = paragraph.text.strip()
            if not text:
                continue
            
            style_name = paragraph.style.name.lower() if paragraph.style else ""
            
            # Convert Word heading styles to Markdown
            if 'heading 1' in style_name:
                sections.append(f"# {text}")
            elif 'heading 2' in style_name:
                sections.append(f"## {text}")
            elif 'heading 3' in style_name:
                sections.append(f"### {text}")
            elif 'title' in style_name:
                sections.append(f"# {text}")
            elif 'subtitle' in style_name:
                sections.append(f"## {text}")
            else:
                # Check for bold runs (often used as section headers in resumes)
                runs = paragraph.runs
                if runs and all(r.bold for r in runs if r.text.strip()):
                    # All text is bold - likely a section header
                    if len(text) < 60:  # Short bold text = header
                        sections.append(f"**{text}**")
                    else:
                        sections.append(text)
                else:
                    sections.append(text)
        
        # Extract tables with Markdown formatting
        for table in doc.tables:
            table_text = self._format_docx_table(table)
            if table_text:
                sections.append(table_text)
        
        full_text = "\n".join(sections)
        return self._clean_text(full_text)
    
    def _format_table(self, table: list) -> str:
        """Format pdfplumber table as readable text."""
        if not table:
            return ""
        rows = []
        for row in table:
            cells = [str(c).strip() for c in row if c]
            if cells:
                rows.append(" | ".join(cells))
        return "\n".join(rows)
    
    def _format_docx_table(self, table) -> str:
        """Format python-docx table as Markdown table."""
        rows = []
        for i, row in enumerate(table.rows):
            cells = [cell.text.strip() for cell in row.cells]
            if any(cells):
                rows.append("| " + " | ".join(cells) + " |")
                # Add header separator after first row
                if i == 0:
                    rows.append("| " + " | ".join(["---"] * len(cells)) + " |")
        return "\n".join(rows)
    
    def _clean_markdown(self, text: str) -> str:
        """Clean pymupdf4llm Markdown output for LLM consumption."""
        if not text:
            return ""
        
        # Remove image references (not useful for text extraction)
        text = re.sub(r'!\[.*?\]\(.*?\)', '', text)
        
        # Remove excessive blank lines
        text = re.sub(r'\n{3,}', '\n\n', text)
        
        # Remove page separators
        text = re.sub(r'---\s*end of page=\d+\s*---', '', text)
        
        # Remove standalone page numbers
        text = re.sub(r'^\d+$', '', text, flags=re.MULTILINE)
        
        return text.strip()
    
    def _clean_text(self, text: str) -> str:
        """Clean and normalize extracted text."""
        if not text:
            return ""
        
        # Normalize whitespace
        text = re.sub(r' +', ' ', text)
        text = re.sub(r'\n{3,}', '\n\n', text)
        
        # Remove page footers
        text = re.sub(r'Page \d+ of \d+', '', text, flags=re.IGNORECASE)
        text = re.sub(r'^\d+$', '', text, flags=re.MULTILINE)
        
        return text.strip()
    
    def get_extraction_quality(self, text: str) -> dict:
        """
        Assess the quality of extracted text for debugging.
        
        Returns:
            Dict with quality metrics: char_count, word_count, has_email,
            has_sections, estimated_quality (low/medium/high)
        """
        if not text:
            return {"char_count": 0, "word_count": 0, "estimated_quality": "none"}
        
        char_count = len(text)
        word_count = len(text.split())
        has_email = bool(re.search(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', text))
        has_phone = bool(re.search(r'[\+]?\d[\d\s\-\(\)]{7,}', text))
        
        # Check for resume section keywords
        section_keywords = ['experience', 'education', 'skills', 'summary', 'objective', 'projects']
        sections_found = sum(1 for kw in section_keywords if kw in text.lower())
        
        if word_count > 100 and has_email and sections_found >= 2:
            quality = "high"
        elif word_count > 50 and (has_email or sections_found >= 1):
            quality = "medium"
        else:
            quality = "low"
        
        return {
            "char_count": char_count,
            "word_count": word_count,
            "has_email": has_email,
            "has_phone": has_phone,
            "sections_found": sections_found,
            "estimated_quality": quality
        }
