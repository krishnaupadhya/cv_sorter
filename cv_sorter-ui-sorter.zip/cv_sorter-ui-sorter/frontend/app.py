#!/usr/bin/env python3
"""
Flask Web Server for CV Sorter UI

Provides a clean web interface for the CV sorting pipeline with real-time progress updates.

Endpoints:
    - GET /               : Serve the main UI
    - POST /api/job       : Submit job description
    - POST /api/resumes   : Upload resume files
    - POST /api/process   : Trigger processing pipeline
    - GET /api/progress   : Server-Sent Events for progress updates
    - GET /api/results    : Get final results
"""

import os
import sys
import json
import asyncio
import hashlib
import time
from pathlib import Path
from datetime import datetime
from threading import Thread
from queue import Queue
from werkzeug.utils import secure_filename

from flask import Flask, render_template, request, jsonify, Response, stream_with_context
from flask_cors import CORS

# Add parent directory to path to import project modules
sys.path.insert(0, str(Path(__file__).parent.parent))

from agents.job_analyzer import JobAnalyzer
from agents.resume_parser import parse_single_resume
from agents.embedding_engine import EmbeddingEngine
from agents.ranking_engine import rank_candidates
from agents.report_generator import ReportGenerator
from main import process_all_resumes_simple, generate_embeddings

# Initialize Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = os.urandom(24).hex()
app.config['MAX_CONTENT_LENGTH'] = 2 * 1024 * 1024  # 2MB max file size
app.config['UPLOAD_FOLDER'] = Path(__file__).parent / 'static' / 'uploads'
app.config['ALLOWED_EXTENSIONS'] = {'pdf', 'docx', 'doc'}

CORS(app)

# Ensure upload folder exists
app.config['UPLOAD_FOLDER'].mkdir(parents=True, exist_ok=True)

# Global state for current processing session
session_state = {
    'job_description': None,
    'job_title': None,
    'criteria': None,
    'resume_files': [],
    'results': None,
    'api_key': None,
    'provider': 'groq',
    'processing': False,
    'progress_queue': Queue(),
    # Refinement fields
    'original_results': None,        # Backup of initial results
    'current_criteria': None,        # Current criteria (modifiable)
    'resumes_cache': None,          # Parsed resumes for re-ranking
    'embeddings_cache': None,       # Resume embeddings for re-ranking
    'refinement_history': []         # Track all refinements
}


def allowed_file(filename):
    """Check if file extension is allowed."""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']


def emit_progress(step, message, progress=None, data=None):
    """Emit progress update to SSE stream."""
    event = {
        'step': step,
        'message': message,
        'timestamp': datetime.now().isoformat(),
    }
    if progress is not None:
        event['progress'] = progress
    if data is not None:
        event['data'] = data
    
    session_state['progress_queue'].put(event)


# ─────────────────────────────────────────────────────────────────────────────
# ROUTES
# ─────────────────────────────────────────────────────────────────────────────

@app.route('/')
def index():
    """Serve the main UI page."""
    return render_template('index.html')


@app.route('/api/job', methods=['POST'])
def submit_job():
    """
    Step 1: Submit job description.
    
    Request JSON:
        {
            "title": "Senior Python Developer",
            "description": "We are looking for...",
            "api_key": "gsk_...",
            "provider": "groq"  # optional, default: groq
        }
    
    Response:
        {
            "success": true,
            "message": "Job description saved"
        }
    """
    try:
        data = request.get_json()
        
        if not data or not data.get('title') or not data.get('description'):
            return jsonify({
                'success': False,
                'error': 'Job title and description are required'
            }), 400
        
        # Check if API key was provided at startup
        if not session_state.get('api_key'):
            return jsonify({
                'success': False,
                'error': 'API key not configured. Please restart with --api-key argument.'
            }), 400
        
        # Save to session state (criteria will be analyzed during processing)
        session_state['job_title'] = data['title'].strip()
        session_state['job_description'] = data['description'].strip()
        session_state['criteria'] = None  # Will be analyzed during processing
        session_state['results'] = None  # Reset results
        
        return jsonify({
            'success': True,
            'message': 'Job description saved successfully'
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/resumes', methods=['POST'])
def upload_resumes():
    """
    Step 2: Upload resume files.
    
    Accepts multiple files via multipart/form-data.
    Each file must be PDF or DOCX, max 2MB.
    
    Response:
        {
            "success": true,
            "message": "5 resumes uploaded successfully",
            "files": ["resume1.pdf", "resume2.pdf", ...]
        }
    """
    try:
        # Check if files are in request
        if 'files' not in request.files:
            return jsonify({
                'success': False,
                'error': 'No files provided'
            }), 400
        
        files = request.files.getlist('files')
        
        if not files or len(files) == 0:
            return jsonify({
                'success': False,
                'error': 'No files selected'
            }), 400
        
        # Clear previous uploads
        for old_file in app.config['UPLOAD_FOLDER'].glob('*'):
            if old_file.is_file():
                old_file.unlink()
        
        session_state['resume_files'] = []
        uploaded_files = []
        errors = []
        
        for file in files:
            if file.filename == '':
                continue
            
            if not allowed_file(file.filename):
                errors.append(f"{file.filename}: Invalid file type (only PDF/DOCX allowed)")
                continue
            
            # Secure filename and save
            filename = secure_filename(file.filename)
            filepath = app.config['UPLOAD_FOLDER'] / filename
            
            try:
                file.save(str(filepath))
                
                # Check file size
                file_size = filepath.stat().st_size
                if file_size > 2 * 1024 * 1024:
                    filepath.unlink()
                    errors.append(f"{filename}: File too large (max 2MB)")
                    continue
                
                session_state['resume_files'].append(str(filepath))
                uploaded_files.append(filename)
                
            except Exception as e:
                errors.append(f"{filename}: {str(e)}")
        
        if not uploaded_files:
            return jsonify({
                'success': False,
                'error': 'No valid files uploaded',
                'errors': errors
            }), 400
        
        response = {
            'success': True,
            'message': f"{len(uploaded_files)} resume(s) uploaded successfully",
            'files': uploaded_files
        }
        
        if errors:
            response['warnings'] = errors
        
        return jsonify(response)
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/process', methods=['POST'])
def process_pipeline():
    """
    Step 3: Trigger the processing pipeline.
    
    This runs the entire backend pipeline asynchronously and streams
    progress via the /api/progress endpoint.
    
    Response:
        {
            "success": true,
            "message": "Processing started"
        }
    """
    try:
        # Validate session state
        if not session_state['job_description']:
            return jsonify({
                'success': False,
                'error': 'Job description not provided'
            }), 400
        
        if not session_state['resume_files']:
            return jsonify({
                'success': False,
                'error': 'No resumes uploaded'
            }), 400
        
        if session_state['processing']:
            return jsonify({
                'success': False,
                'error': 'Processing already in progress'
            }), 400
        
        # Clear progress queue
        while not session_state['progress_queue'].empty():
            session_state['progress_queue'].get()
        
        # Start processing in background thread
        session_state['processing'] = True
        session_state['results'] = None
        
        thread = Thread(target=run_processing_pipeline)
        thread.daemon = True
        thread.start()
        
        return jsonify({
            'success': True,
            'message': 'Processing started'
        })
    
    except Exception as e:
        session_state['processing'] = False
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/progress')
def progress_stream():
    """
    Server-Sent Events endpoint for real-time progress updates.
    
    Streams JSON events as they occur during processing.
    
    Event format:
        data: {"step": "parsing", "message": "Processing resume 1/5", "progress": 20}
    """
    def generate():
        while True:
            if not session_state['progress_queue'].empty():
                event = session_state['progress_queue'].get()
                yield f"data: {json.dumps(event)}\n\n"
            
            # Check if processing is complete
            if not session_state['processing'] and session_state['progress_queue'].empty():
                # Send completion event
                if session_state['results']:
                    yield f"data: {json.dumps({'step': 'complete', 'message': 'Processing complete'})}\n\n"
                break
            
            time.sleep(0.1)
    
    return Response(
        stream_with_context(generate()),
        mimetype='text/event-stream',
        headers={
            'Cache-Control': 'no-cache',
            'X-Accel-Buffering': 'no'
        }
    )


@app.route('/api/results', methods=['GET'])
def get_results():
    """
    Get final processing results.
    
    Response:
        {
            "success": true,
            "results": {
                "total": 10,
                "strong_fit": 3,
                "moderate_fit": 4,
                "weak_fit": 3,
                "candidates": [...]
            }
        }
    """
    try:
        if not session_state['results']:
            return jsonify({
                'success': False,
                'error': 'No results available'
            }), 404
        
        return jsonify({
            'success': True,
            'results': session_state['results']
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


# ─────────────────────────────────────────────────────────────────────────────
# REFINEMENT ENDPOINTS
# ─────────────────────────────────────────────────────────────────────────────

@app.route('/api/refinement/menu', methods=['GET'])
def get_refinement_menu():
    """
    Get refinement options and current criteria.
    
    Response:
        {
            "success": true,
            "criteria": [...],
            "history": [...],
            "stats": {"total": 10, "strong_fit": 3, ...}
        }
    """
    try:
        if not session_state['results']:
            return jsonify({
                'success': False,
                'error': 'No results available for refinement'
            }), 404
        
        # Get criteria from current_criteria or fall back to results.criteria or session criteria
        criteria = session_state.get('current_criteria')
        if criteria is None:
            criteria = session_state['results'].get('criteria', session_state.get('criteria', []))
        
        return jsonify({
            'success': True,
            'criteria': criteria,
            'history': session_state.get('refinement_history', []),
            'stats': {
                'total': session_state['results']['total'],
                'strong_fit': session_state['results']['strong_fit'],
                'moderate_fit': session_state['results']['moderate_fit'],
                'weak_fit': session_state['results']['weak_fit']
            }
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/refinement/add-criterion', methods=['POST'])
def add_criterion():
    """
    Add a new criterion and re-rank.
    
    Request JSON:
        {
            "name": "AWS Certification",
            "explanation": "Must have AWS Solutions Architect certification",
            "weight": 0.15
        }
    
    Response:
        {
            "success": true,
            "results": {...},
            "message": "Criterion added and results re-ranked"
        }
    """
    try:
        data = request.get_json()
        
        if not data or not data.get('name') or not data.get('weight'):
            return jsonify({
                'success': False,
                'error': 'Criterion name and weight are required'
            }), 400
        
        # Validate weight
        try:
            weight = float(data['weight'])
            if not (0.0 <= weight <= 1.0):
                raise ValueError()
        except (ValueError, TypeError):
            return jsonify({
                'success': False,
                'error': 'Weight must be a number between 0 and 1'
            }), 400
        
        # Initialize current_criteria if not exists
        if session_state['current_criteria'] is None:
            session_state['current_criteria'] = session_state['criteria'].copy()
        
        # Add new criterion
        new_criterion = {
            'name': data['name'].strip(),
            'explanation': data.get('explanation', '').strip(),
            'weight': weight
        }
        session_state['current_criteria'].append(new_criterion)
        
        # Re-rank with new criteria
        results = rerank_candidates(session_state['current_criteria'])
        session_state['results'] = results
        
        # Track in history
        session_state['refinement_history'].append({
            'action': 'add_criterion',
            'criterion': data['name'],
            'weight': weight,
            'timestamp': datetime.now().isoformat()
        })
        
        return jsonify({
            'success': True,
            'results': results,
            'message': f'Added criterion "{data["name"]}" and re-ranked'
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/refinement/adjust-weight', methods=['POST'])
def adjust_weight():
    """
    Adjust weight of existing criterion and re-rank.
    
    Request JSON:
        {
            "criterion_name": "Python Experience",
            "new_weight": 0.25
        }
    
    Response:
        {
            "success": true,
            "results": {...},
            "message": "Weight adjusted and results re-ranked"
        }
    """
    try:
        data = request.get_json()
        
        if not data or not data.get('criterion_name') or data.get('new_weight') is None:
            return jsonify({
                'success': False,
                'error': 'Criterion name and new weight are required'
            }), 400
        
        # Validate weight
        try:
            new_weight = float(data['new_weight'])
            if not (0.0 <= new_weight <= 1.0):
                raise ValueError()
        except (ValueError, TypeError):
            return jsonify({
                'success': False,
                'error': 'Weight must be a number between 0 and 1'
            }), 400
        
        # Initialize current_criteria if not exists
        if session_state['current_criteria'] is None:
            session_state['current_criteria'] = session_state['criteria'].copy()
        
        # Find and update criterion
        criterion_found = False
        old_weight = 0
        for criterion in session_state['current_criteria']:
            if criterion['name'].lower() == data['criterion_name'].lower():
                old_weight = criterion['weight']
                criterion['weight'] = new_weight
                criterion_found = True
                break
        
        if not criterion_found:
            return jsonify({
                'success': False,
                'error': f'Criterion "{data["criterion_name"]}" not found'
            }), 404
        
        # Re-rank with adjusted weights
        results = rerank_candidates(session_state['current_criteria'])
        session_state['results'] = results
        
        # Track in history
        session_state['refinement_history'].append({
            'action': 'adjust_weight',
            'criterion': data['criterion_name'],
            'old_weight': old_weight,
            'new_weight': new_weight,
            'timestamp': datetime.now().isoformat()
        })
        
        return jsonify({
            'success': True,
            'results': results,
            'message': f'Adjusted weight for "{data["criterion_name"]}" and re-ranked'
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/refinement/filter-skills', methods=['POST'])
def filter_by_skills():
    """
    Filter candidates by specific skills and re-rank.
    
    Request JSON:
        {
            "required_skills": ["python", "aws", "docker"]
        }
    
    Response:
        {
            "success": true,
            "results": {...},
            "message": "Filtered by skills and re-ranked"
        }
    """
    try:
        data = request.get_json()
        
        if not data or not data.get('required_skills'):
            return jsonify({
                'success': False,
                'error': 'Required skills list is required'
            }), 400
        
        required_skills = [s.strip().lower() for s in data['required_skills']]
        
        if not required_skills:
            return jsonify({
                'success': False,
                'error': 'At least one skill is required'
            }), 400
        
        # Filter candidates
        if not session_state['resumes_cache']:
            return jsonify({
                'success': False,
                'error': 'Resume cache not available'
            }), 500
        
        # Use current_criteria or fall back to original
        criteria = session_state.get('current_criteria', session_state['criteria'])
        
        # Re-rank with skill filtering
        results = rerank_candidates(criteria, required_skills=required_skills)
        session_state['results'] = results
        
        # Track in history
        session_state['refinement_history'].append({
            'action': 'filter_skills',
            'skills': required_skills,
            'filtered_count': results['total'],
            'timestamp': datetime.now().isoformat()
        })
        
        return jsonify({
            'success': True,
            'results': results,
            'message': f'Filtered by {len(required_skills)} skill(s) and re-ranked'
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/refinement/save', methods=['POST'])
def save_refinement():
    """
    Save current refinement as the new baseline.
    
    Response:
        {
            "success": true,
            "message": "Refinement saved"
        }
    """
    try:
        if not session_state['results']:
            return jsonify({
                'success': False,
                'error': 'No results to save'
            }), 404
        
        # Update original results with current state
        session_state['original_results'] = session_state['results'].copy()
        session_state['criteria'] = session_state.get('current_criteria', session_state['criteria'])
        
        return jsonify({
            'success': True,
            'message': 'Refinement saved successfully'
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/refinement/reset', methods=['POST'])
def reset_refinement():
    """
    Reset to original results before refinement.
    
    Response:
        {
            "success": true,
            "results": {...},
            "message": "Reset to original results"
        }
    """
    try:
        if not session_state['original_results']:
            return jsonify({
                'success': False,
                'error': 'No original results to restore'
            }), 404
        
        # Restore original results
        session_state['results'] = session_state['original_results'].copy()
        session_state['current_criteria'] = None
        session_state['refinement_history'] = []
        
        return jsonify({
            'success': True,
            'results': session_state['results'],
            'message': 'Reset to original results'
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


# ─────────────────────────────────────────────────────────────────────────────
# REFINEMENT HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def rerank_candidates(criteria, required_skills=None):
    """
    Re-rank candidates with updated criteria or skill filter.
    
    Args:
        criteria: List of criteria dicts with name, weight, explanation
        required_skills: Optional list of required skill keywords (lowercase)
    
    Returns:
        Results dict matching the format of session_state['results']
    """
    from agents.scoring_engine import compute_weighted_score
    
    # Get cached resumes
    resumes = session_state['resumes_cache']
    if not resumes:
        raise ValueError("No cached resumes available")
    
    # Filter by skills if required
    if required_skills:
        filtered_resumes = []
        for resume in resumes:
            resume_skills = resume.get('skills') or []
            resume_skills = [s.lower() for s in resume_skills if s]
            # Check if resume has all required skills
            if all(any(req in rs for rs in resume_skills) for req in required_skills):
                filtered_resumes.append(resume)
        resumes = filtered_resumes
    
    # Re-compute semantic scores (use cached embeddings)
    semantic_scores = {}
    if session_state['embeddings_cache']:
        # Use cached scores or recompute if needed
        for i, resume in enumerate(resumes):
            semantic_scores[resume['name']] = session_state['embeddings_cache'].get(
                resume['name'],
                0.0
            )
    else:
        # Fallback to zeros if no cache
        semantic_scores = {r['name']: 0.0 for r in resumes}
    
    # Re-rank with new criteria
    ranked = []
    for resume in resumes:
        # Compute algorithmic score
        algo_result = compute_weighted_score(resume, criteria)
        
        # Get semantic score (already in 0-100 scale from cache)
        semantic_score = semantic_scores[resume['name']]
        
        # Blend scores: 70% algo + 30% semantic
        combined_score = round(
            0.70 * algo_result["algo_score"] + 0.30 * semantic_score,
            1
        )
        
        # Classify candidate
        recommendation = classify_candidate(combined_score)
        
        # Convert all numeric values to native Python types for JSON serialization
        ranked_resume = {
            'name': resume['name'],
            'email': resume['email'],
            'combined_score': float(combined_score),
            'semantic_score': float(round(semantic_score, 1)),
            'recommendation': recommendation,
            'experience_years': int(resume['experience_years']) if resume.get('experience_years') else 0,
            'skills': resume.get('skills') or [],
            'report_text': resume.get('report_text', '')
        }
        ranked.append(ranked_resume)
    
    # Sort by combined_score descending
    ranked.sort(key=lambda x: x['combined_score'], reverse=True)
    
    # Compute stats
    strong = sum(1 for r in ranked if r['recommendation'] == 'Strong Fit')
    moderate = sum(1 for r in ranked if r['recommendation'] == 'Moderate Fit')
    weak = sum(1 for r in ranked if r['recommendation'] == 'Weak Fit')
    
    return {
        'total': int(len(ranked)),
        'strong_fit': int(strong),
        'moderate_fit': int(moderate),
        'weak_fit': int(weak),
        'candidates': ranked,
        'criteria': [
            {
                'name': c['name'],
                'explanation': c.get('explanation', ''),
                'weight': float(c['weight'])
            }
            for c in criteria
        ]
    }


def classify_candidate(score):
    """Classify candidate based on combined score."""
    if score >= 75:
        return 'Strong Fit'
    elif score >= 50:
        return 'Moderate Fit'
    else:
        return 'Weak Fit'


# ─────────────────────────────────────────────────────────────────────────────
# PROCESSING PIPELINE
# ─────────────────────────────────────────────────────────────────────────────

def run_processing_pipeline():
    """
    Execute the full CV sorting pipeline with progress updates.
    
    This runs in a background thread and emits progress events.
    """
    try:
        asyncio.run(process_pipeline_async())
    except Exception as e:
        emit_progress('error', f'Processing failed: {str(e)}', progress=0, data={'error': str(e)})
        session_state['processing'] = False


async def process_pipeline_async():
    """Async pipeline execution."""
    try:
        # Step 1: Analyze Job Description
        emit_progress('job', 'Analyzing job description...', progress=5)
        jd_text = f"Job Title: {session_state['job_title']}\n\n{session_state['job_description']}"
        
        # Always make fresh LLM call (no caching)
        analyzer = JobAnalyzer(
            provider=session_state['provider'],
            api_key=session_state['api_key']
        )
        criteria, skill_keywords, cert_keywords = analyzer.analyze(jd_text)
        session_state['criteria'] = criteria
        
        emit_progress('job', f'Job analyzed: {len(criteria)} criteria identified', progress=10)
        
        # Step 2: Parse Resumes
        emit_progress('parsing', 'Parsing resumes...', progress=15)
        
        # Create temporary directory with uploaded files
        temp_dir = app.config['UPLOAD_FOLDER']
        
        resumes, parse_stats = process_all_resumes_simple(str(temp_dir))
        
        if not resumes:
            emit_progress('error', 'No valid resumes found', progress=0, data={'error': 'All resumes were rejected'})
            return
        
        emit_progress('parsing', f'Parsed {len(resumes)} resumes', progress=30, data={
            'parsed': parse_stats['parsed'],
            'errors': parse_stats['errors']
        })
        
        # Step 3: Generate Embeddings
        emit_progress('embeddings', 'Generating embeddings...', progress=40)
        
        embedding_engine = EmbeddingEngine()
        jd_embedding = embedding_engine.get_jd_embedding(criteria)
        resume_embeddings = generate_embeddings(resumes, embedding_engine)
        
        emit_progress('embeddings', f'Generated {len(resume_embeddings)} embeddings', progress=55)
        
        # Step 4: Compute Similarity
        emit_progress('similarity', 'Computing semantic similarity...', progress=65)
        
        index = embedding_engine.build_faiss_index(resume_embeddings)
        semantic_scores, _ = embedding_engine.search(index, jd_embedding, k=len(resumes))
        
        emit_progress('similarity', 'Similarity scores computed', progress=75)
        
        # Step 5: Rank Candidates
        emit_progress('ranking', 'Ranking candidates...', progress=80)
        
        ranked = rank_candidates(resumes, criteria, semantic_scores)
        
        emit_progress('ranking', f'Ranked {len(ranked)} candidates', progress=85)
        
        # Step 6: Generate Reports for Top 9
        emit_progress('reports', 'Generating detailed reports...', progress=87)
        
        top_n = min(9, len(ranked))
        report_generator = ReportGenerator(
            provider=session_state['provider'],
            api_key=session_state['api_key']
        )
        
        top_candidates = ranked[:top_n]
        with_reports = await report_generator.generate_all_reports(top_candidates)
        
        # Update ranked list with reports
        for i, candidate in enumerate(with_reports):
            ranked[i] = candidate
        
        emit_progress('reports', f'Generated {len(with_reports)} reports', progress=95)
        
        # Prepare results
        strong = sum(1 for r in ranked if r['recommendation'] == 'Strong Fit')
        moderate = sum(1 for r in ranked if r['recommendation'] == 'Moderate Fit')
        weak = sum(1 for r in ranked if r['recommendation'] == 'Weak Fit')
        
        # Clean data for JSON serialization
        cleaned_ranked = []
        for candidate in ranked:
            cleaned = {
                'name': candidate['name'],
                'email': candidate['email'],
                'combined_score': float(round(candidate['combined_score'], 1)),
                'semantic_score': float(round(candidate['semantic_score'], 1)),
                'recommendation': candidate['recommendation'],
                'experience_years': int(candidate['experience_years']) if candidate.get('experience_years') else 0,
                'skills': candidate.get('skills', []),
                'report_text': candidate.get('report_text', '')
            }
            cleaned_ranked.append(cleaned)
        
        results = {
            'total': int(len(ranked)),
            'strong_fit': int(strong),
            'moderate_fit': int(moderate),
            'weak_fit': int(weak),
            'candidates': cleaned_ranked,
            'criteria': [
                {
                    'name': c['name'],
                    'explanation': c.get('explanation', ''),
                    'weight': float(c['weight'])
                }
                for c in criteria
            ]
        }
        
        # Cache data for refinement (convert semantic_scores to native Python floats)
        session_state['resumes_cache'] = resumes
        session_state['embeddings_cache'] = {
            r['name']: float(score) * 100 for r, score in zip(resumes, semantic_scores)
        }
        session_state['original_results'] = results.copy()
        session_state['current_criteria'] = None  # Will be set on first refinement
        session_state['refinement_history'] = []
        
        # Set current results
        session_state['results'] = results
        
        emit_progress('complete', 'Processing complete!', progress=100, data={
            'total': len(ranked),
            'strong_fit': strong,
            'moderate_fit': moderate,
            'weak_fit': weak
        })
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        emit_progress('error', f'Error: {str(e)}', progress=0, data={'error': str(e)})
    
    finally:
        session_state['processing'] = False


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────

def run_server(host='127.0.0.1', port=5000, api_key=None, provider='groq'):
    """Start the Flask development server."""
    # Store API key and provider in session state
    if api_key:
        session_state['api_key'] = api_key
        session_state['provider'] = provider
    
    print(f"\n{'='*80}")
    print(f"CV SORTER — Web Interface")
    print(f"{'='*80}\n")
    print(f"🚀 Server starting at: http://{host}:{port}")
    print(f"\nOpen your browser and navigate to the URL above.\n")
    print(f"Press Ctrl+C to stop the server.\n")
    print(f"{'='*80}\n")
    
    app.run(host=host, port=port, debug=False, threaded=True)


if __name__ == '__main__':
    run_server()
