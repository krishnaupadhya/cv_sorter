// CV Sorter - Frontend Application Logic

// ============================================================================
// STATE MANAGEMENT
// ============================================================================

const state = {
    currentStep: 1,
    jobData: null,
    resumeFiles: [],
    results: null,
    processing: false
};

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

function showElement(elementId) {
    document.getElementById(elementId).classList.remove('hidden');
}

function hideElement(elementId) {
    document.getElementById(elementId).classList.add('hidden');
}

function showError(containerId, message) {
    const errorEl = document.getElementById(containerId);
    const errorText = document.getElementById(`${containerId.replace('-error', '')}-error-text`);
    errorText.textContent = message;
    showElement(containerId);
    
    // Hide after 5 seconds
    setTimeout(() => hideElement(containerId), 5000);
}

function showSuccess(containerId, message) {
    const successEl = document.getElementById(containerId);
    const successText = document.getElementById(`${containerId.replace('-success', '')}-success-text`);
    successText.textContent = message;
    showElement(containerId);
    
    // Hide after 3 seconds
    setTimeout(() => hideElement(containerId), 3000);
}

function setLoading(buttonId, loading) {
    const button = document.getElementById(buttonId);
    if (loading) {
        button.disabled = true;
        button.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Processing...';
    } else {
        button.disabled = false;
        // Reset to original content (will be handled by specific functions)
    }
}

// ============================================================================
// STEP NAVIGATION
// ============================================================================

function goToStep(step) {
    // Hide all steps
    for (let i = 1; i <= 4; i++) {
        hideElement(`step-${i}-content`);
        
        // Update step indicators
        const indicator = document.getElementById(`step-indicator-${i}`);
        indicator.classList.remove('active', 'completed');
        
        if (i < step) {
            indicator.classList.add('completed');
        } else if (i === step) {
            indicator.classList.add('active');
        }
        
        // Update step lines
        if (i < 4) {
            const line = document.getElementById(`step-line-${i}`);
            if (i < step) {
                line.style.borderColor = '#10b981';
            } else {
                line.style.borderColor = '#d1d5db';
            }
        }
    }
    
    // Show current step
    showElement(`step-${step}-content`);
    state.currentStep = step;
    
    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ============================================================================
// STEP 1: JOB DESCRIPTION
// ============================================================================

document.getElementById('job-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    // Hide previous messages
    hideElement('job-error');
    hideElement('job-success');
    
    const title = document.getElementById('job-title').value.trim();
    const description = document.getElementById('job-description').value.trim();
    
    // Validation
    if (!title) {
        showError('job-error', 'Job title is required');
        return;
    }
    
    if (!description || description.length < 50) {
        showError('job-error', 'Job description must be at least 50 characters');
        return;
    }
    
    setLoading('job-submit-btn', true);
    
    try {
        const response = await fetch('/api/job', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                title: title,
                description: description
            })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || 'Failed to analyze job description');
        }
        
        // Save to state
        state.jobData = { title, description };
        
        showSuccess('job-success', `Job analyzed successfully! ${data.criteria_count} criteria identified.`);
        
        // Move to next step after a brief delay
        setTimeout(() => {
            goToStep(2);
        }, 1000);
        
    } catch (error) {
        showError('job-error', error.message);
    } finally {
        // Reset button
        const button = document.getElementById('job-submit-btn');
        button.disabled = false;
        button.innerHTML = 'Analyze Job Description <i class="fas fa-arrow-right ml-2"></i>';
    }
});

// ============================================================================
// STEP 2: UPLOAD RESUMES
// ============================================================================

const dropZone = document.getElementById('drop-zone');
const fileInput = document.getElementById('resume-files');
const fileListItems = document.getElementById('file-list-items');
const resumeSubmitBtn = document.getElementById('resume-submit-btn');

// Drag and drop handlers
dropZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropZone.classList.add('drag-over');
});

dropZone.addEventListener('dragleave', () => {
    dropZone.classList.remove('drag-over');
});

dropZone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropZone.classList.remove('drag-over');
    
    const files = Array.from(e.dataTransfer.files);
    handleFiles(files);
});

// File input change handler
fileInput.addEventListener('change', (e) => {
    const files = Array.from(e.target.files);
    handleFiles(files);
});

function handleFiles(files) {
    // Filter valid files
    const validFiles = files.filter(file => {
        const ext = file.name.split('.').pop().toLowerCase();
        return ['pdf', 'docx', 'doc'].includes(ext) && file.size <= 2 * 1024 * 1024;
    });
    
    if (validFiles.length === 0) {
        showError('resume-error', 'No valid files selected. Please upload PDF or DOCX files (max 2MB each).');
        return;
    }
    
    state.resumeFiles = validFiles;
    displayFileList();
    resumeSubmitBtn.disabled = false;
}

function displayFileList() {
    fileListItems.innerHTML = '';
    
    if (state.resumeFiles.length === 0) {
        hideElement('file-list');
        return;
    }
    
    showElement('file-list');
    
    state.resumeFiles.forEach((file, index) => {
        const ext = file.name.split('.').pop().toLowerCase();
        const fileItem = document.createElement('div');
        fileItem.className = 'file-item';
        fileItem.innerHTML = `
            <div class="file-name">
                <div class="file-icon ${ext}">
                    <i class="fas fa-file-${ext === 'pdf' ? 'pdf' : 'word'}"></i>
                </div>
                <div class="flex-1">
                    <div class="font-semibold text-gray-800 text-sm">${file.name}</div>
                    <div class="text-xs text-gray-500">${formatFileSize(file.size)}</div>
                </div>
            </div>
            <div class="file-remove" onclick="removeFile(${index})">
                <i class="fas fa-times"></i>
            </div>
        `;
        fileListItems.appendChild(fileItem);
    });
}

function removeFile(index) {
    state.resumeFiles.splice(index, 1);
    displayFileList();
    
    if (state.resumeFiles.length === 0) {
        resumeSubmitBtn.disabled = true;
        fileInput.value = '';
    }
}

function formatFileSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}

// Resume form submission
document.getElementById('resume-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    hideElement('resume-error');
    hideElement('resume-success');
    
    if (state.resumeFiles.length === 0) {
        showError('resume-error', 'Please select at least one resume file');
        return;
    }
    
    setLoading('resume-submit-btn', true);
    
    try {
        const formData = new FormData();
        state.resumeFiles.forEach(file => {
            formData.append('files', file);
        });
        
        const response = await fetch('/api/resumes', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || 'Failed to upload resumes');
        }
        
        showSuccess('resume-success', data.message);
        
        // Start processing immediately
        setTimeout(() => {
            goToStep(3);
            startProcessing();
        }, 1000);
        
    } catch (error) {
        showError('resume-error', error.message);
    } finally {
        const button = document.getElementById('resume-submit-btn');
        button.disabled = false;
        button.innerHTML = 'Upload & Continue <i class="fas fa-arrow-right ml-2"></i>';
    }
});

// Back button
document.getElementById('back-to-step-1').addEventListener('click', () => {
    goToStep(1);
});

// ============================================================================
// STEP 3: PROCESSING
// ============================================================================

async function startProcessing() {
    state.processing = true;
    hideElement('process-error');
    
    try {
        // Start processing
        const response = await fetch('/api/process', {
            method: 'POST'
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || 'Failed to start processing');
        }
        
        // Listen to progress updates via SSE
        listenToProgress();
        
    } catch (error) {
        showError('process-error', error.message);
        state.processing = false;
    }
}

function listenToProgress() {
    const eventSource = new EventSource('/api/progress');
    const progressBar = document.getElementById('progress-bar');
    const progressLabel = document.getElementById('progress-label');
    const progressPercentage = document.getElementById('progress-percentage');
    const progressSteps = document.getElementById('progress-steps');
    
    const stepMap = {};
    
    eventSource.onmessage = (event) => {
        const data = JSON.parse(event.data);
        
        // Update progress bar
        if (data.progress !== undefined) {
            progressBar.style.width = data.progress + '%';
            progressPercentage.textContent = data.progress + '%';
        }
        
        progressLabel.textContent = data.message;
        
        // Update step display
        const stepKey = data.step;
        
        if (!stepMap[stepKey]) {
            // Create new step item
            const stepItem = document.createElement('div');
            stepItem.id = `progress-step-${stepKey}`;
            stepItem.className = 'progress-step active';
            stepItem.innerHTML = `
                <div class="progress-step-icon">
                    <i class="fas fa-spinner fa-spin"></i>
                </div>
                <div class="flex-1">
                    <div class="font-semibold text-gray-800">${data.message}</div>
                    <div class="text-xs text-gray-500 mt-1">${new Date(data.timestamp).toLocaleTimeString()}</div>
                </div>
            `;
            progressSteps.appendChild(stepItem);
            stepMap[stepKey] = stepItem;
        } else {
            // Update existing step
            const stepItem = stepMap[stepKey];
            stepItem.querySelector('.font-semibold').textContent = data.message;
        }
        
        // Mark as completed if needed
        if (data.step === 'complete') {
            Object.values(stepMap).forEach(item => {
                item.classList.remove('active');
                item.classList.add('completed');
                item.querySelector('.progress-step-icon i').className = 'fas fa-check';
            });
            
            eventSource.close();
            state.processing = false;
            
            // Load and display results
            setTimeout(() => {
                loadResults();
            }, 1000);
        }
        
        // Handle errors
        if (data.step === 'error') {
            const stepItem = stepMap[Object.keys(stepMap)[Object.keys(stepMap).length - 1]];
            if (stepItem) {
                stepItem.classList.remove('active');
                stepItem.classList.add('error');
                stepItem.querySelector('.progress-step-icon i').className = 'fas fa-times';
            }
            
            showError('process-error', data.message);
            eventSource.close();
            state.processing = false;
        }
    };
    
    eventSource.onerror = () => {
        eventSource.close();
        if (state.processing) {
            showError('process-error', 'Connection lost. Please try again.');
            state.processing = false;
        }
    };
}

// Cancel processing
document.getElementById('cancel-processing').addEventListener('click', () => {
    if (confirm('Are you sure you want to cancel processing?')) {
        location.reload();
    }
});

// ============================================================================
// STEP 4: RESULTS
// ============================================================================

async function loadResults() {
    try {
        const response = await fetch('/api/results');
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || 'Failed to load results');
        }
        
        state.results = data.results;
        displayResults();
        goToStep(4);
        
    } catch (error) {
        showError('process-error', error.message);
    }
}

function displayResults() {
    const results = state.results;
    
    // Display summary cards
    const summaryCards = document.getElementById('summary-cards');
    summaryCards.innerHTML = `
        <div class="bg-white border border-gray-200 rounded-lg p-6 text-center">
            <div class="text-3xl font-bold text-gray-800">${results.total}</div>
            <div class="text-sm text-gray-600 mt-1">Total Candidates</div>
        </div>
        <div class="bg-green-50 border border-green-200 rounded-lg p-6 text-center">
            <div class="text-3xl font-bold text-green-700">${results.strong_fit}</div>
            <div class="text-sm text-green-600 mt-1">Strong Fit</div>
        </div>
        <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-6 text-center">
            <div class="text-3xl font-bold text-yellow-700">${results.moderate_fit}</div>
            <div class="text-sm text-yellow-600 mt-1">Moderate Fit</div>
        </div>
        <div class="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
            <div class="text-3xl font-bold text-red-700">${results.weak_fit}</div>
            <div class="text-sm text-red-600 mt-1">Weak Fit</div>
        </div>
    `;
    
    // Display candidate list
    const candidateList = document.getElementById('candidate-list');
    candidateList.innerHTML = '';
    
    results.candidates.forEach((candidate, index) => {
        const rank = index + 1;
        const fitClass = candidate.recommendation.toLowerCase().replace(' ', '-');
        const rankClass = rank <= 3 ? `rank-${rank}` : 'other';
        
        const candidateCard = document.createElement('div');
        candidateCard.className = `candidate-card ${fitClass}`;
        candidateCard.innerHTML = `
            <div class="flex items-start gap-4">
                <div class="candidate-rank ${rankClass}">
                    ${rank <= 3 ? '<i class="fas fa-trophy"></i>' : rank}
                </div>
                <div class="flex-1">
                    <div class="flex items-start justify-between mb-3">
                        <div>
                            <h3 class="text-xl font-bold text-gray-800">${candidate.name}</h3>
                            <p class="text-sm text-gray-600">
                                <i class="fas fa-envelope mr-1"></i> ${candidate.email}
                            </p>
                        </div>
                        <div class="text-right">
                            <div class="text-2xl font-bold text-gray-800">${candidate.combined_score}</div>
                            <div class="text-xs text-gray-500">Score</div>
                        </div>
                    </div>
                    
                    <div class="flex items-center gap-3 mb-3">
                        <span class="badge badge-${fitClass.split('-')[0]}">
                            ${candidate.recommendation}
                        </span>
                        <span class="text-sm text-gray-600">
                            <i class="fas fa-briefcase mr-1"></i>
                            ${candidate.experience_years} years
                        </span>
                    </div>
                    
                    ${candidate.skills && candidate.skills.length > 0 ? `
                        <div class="mb-3">
                            <div class="text-xs text-gray-500 mb-2">Skills:</div>
                            <div class="flex flex-wrap gap-1">
                                ${candidate.skills.slice(0, 10).map(skill => 
                                    `<span class="skill-tag">${skill}</span>`
                                ).join('')}
                                ${candidate.skills.length > 10 ? 
                                    `<span class="skill-tag">+${candidate.skills.length - 10} more</span>` : ''}
                            </div>
                        </div>
                    ` : ''}
                    
                    ${candidate.report_text ? `
                        <details class="mt-3">
                            <summary class="cursor-pointer text-sm font-semibold text-blue-600 hover:text-blue-700">
                                <i class="fas fa-file-alt mr-1"></i>
                                View Detailed Assessment
                            </summary>
                            <div class="mt-3 p-4 bg-gray-50 rounded-lg text-sm text-gray-700 leading-relaxed whitespace-pre-wrap">
${candidate.report_text}
                            </div>
                        </details>
                    ` : ''}
                </div>
            </div>
        `;
        candidateList.appendChild(candidateCard);
    });
}

// Start over
document.getElementById('start-over').addEventListener('click', () => {
    if (confirm('Are you sure you want to start over? All current data will be lost.')) {
        location.reload();
    }
});

// Export results
document.getElementById('export-results').addEventListener('click', () => {
    const dataStr = JSON.stringify(state.results, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `cv-sorter-results-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
});

// ============================================================================
// REFINEMENT FUNCTIONALITY
// ============================================================================

// Refinement state
const refinementState = {
    currentCriteria: null,
    refinementHistory: []
};

// Open refinement modal
document.getElementById('refine-results-btn').addEventListener('click', async () => {
    try {
        showLoading();
        
        const response = await fetch('/api/refinement/menu');
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || 'Failed to load refinement menu');
        }
        
        refinementState.currentCriteria = data.criteria;
        refinementState.refinementHistory = data.history;
        
        // Populate weight adjustment dropdown
        const select = document.getElementById('adjust-criterion-select');
        select.innerHTML = '<option value="">-- Choose a criterion --</option>';
        
        // Check if criteria exists and is an array
        if (data.criteria && Array.isArray(data.criteria)) {
            data.criteria.forEach(criterion => {
                const option = document.createElement('option');
                option.value = criterion.name;
                option.textContent = `${criterion.name} (current: ${criterion.weight})`;
                option.dataset.currentWeight = criterion.weight;
                select.appendChild(option);
            });
        } else {
            console.error('Criteria is not an array:', data.criteria);
        }
        
        // Show refinement history
        updateRefinementHistory(data.history);
        
        hideLoading();
        showElement('refinement-modal');
        
    } catch (error) {
        hideLoading();
        alert('Error loading refinement menu: ' + error.message);
    }
});

// Close refinement modal
document.getElementById('close-modal-btn').addEventListener('click', () => {
    hideElement('refinement-modal');
    hideAllForms();
});

// Refinement option click handlers
document.querySelectorAll('.refinement-option').forEach(option => {
    option.addEventListener('click', () => {
        const optionType = option.dataset.option;
        hideAllForms();
        showElement(`${optionType}-form`);
    });
});

// Hide all refinement forms
function hideAllForms() {
    hideElement('add-criterion-form');
    hideElement('adjust-weight-form');
    hideElement('filter-skills-form');
}

// Make hideAllForms available globally
window.hideAllForms = hideAllForms;

// Add new criterion form submission
document.getElementById('add-criterion-form-element').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const name = document.getElementById('new-criterion-name').value.trim();
    const explanation = document.getElementById('new-criterion-explanation').value.trim();
    const weight = parseFloat(document.getElementById('new-criterion-weight').value);
    
    try {
        showLoading();
        
        const response = await fetch('/api/refinement/add-criterion', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, explanation, weight })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || 'Failed to add criterion');
        }
        
        // Update results
        state.results = data.results;
        displayResults();
        
        // Update history
        refinementState.refinementHistory.push({
            action: 'add_criterion',
            criterion: name,
            weight: weight,
            timestamp: new Date().toISOString()
        });
        updateRefinementHistory(refinementState.refinementHistory);
        
        // Reset form
        document.getElementById('add-criterion-form-element').reset();
        hideAllForms();
        hideLoading();
        
        alert(data.message);
        
    } catch (error) {
        hideLoading();
        alert('Error adding criterion: ' + error.message);
    }
});

// Adjust weight form submission
document.getElementById('adjust-weight-form-element').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const criterionName = document.getElementById('adjust-criterion-select').value;
    const newWeight = parseFloat(document.getElementById('adjust-new-weight').value);
    
    if (!criterionName) {
        alert('Please select a criterion');
        return;
    }
    
    try {
        showLoading();
        
        const response = await fetch('/api/refinement/adjust-weight', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                criterion_name: criterionName,
                new_weight: newWeight 
            })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || 'Failed to adjust weight');
        }
        
        // Update results
        state.results = data.results;
        displayResults();
        
        // Update history
        refinementState.refinementHistory.push({
            action: 'adjust_weight',
            criterion: criterionName,
            new_weight: newWeight,
            timestamp: new Date().toISOString()
        });
        updateRefinementHistory(refinementState.refinementHistory);
        
        // Reset form
        document.getElementById('adjust-weight-form-element').reset();
        hideAllForms();
        hideLoading();
        
        alert(data.message);
        
    } catch (error) {
        hideLoading();
        alert('Error adjusting weight: ' + error.message);
    }
});

// Filter by skills form submission
document.getElementById('filter-skills-form-element').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const skillsInput = document.getElementById('required-skills-input').value.trim();
    const requiredSkills = skillsInput.split(',').map(s => s.trim()).filter(s => s);
    
    if (requiredSkills.length === 0) {
        alert('Please enter at least one skill');
        return;
    }
    
    try {
        showLoading();
        
        const response = await fetch('/api/refinement/filter-skills', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ required_skills: requiredSkills })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || 'Failed to filter by skills');
        }
        
        // Update results
        state.results = data.results;
        displayResults();
        
        // Update history
        refinementState.refinementHistory.push({
            action: 'filter_skills',
            skills: requiredSkills,
            filtered_count: data.results.total,
            timestamp: new Date().toISOString()
        });
        updateRefinementHistory(refinementState.refinementHistory);
        
        // Reset form
        document.getElementById('filter-skills-form-element').reset();
        hideAllForms();
        hideLoading();
        
        alert(data.message);
        
    } catch (error) {
        hideLoading();
        alert('Error filtering by skills: ' + error.message);
    }
});

// Save refinement
document.getElementById('save-refinement-btn').addEventListener('click', async () => {
    if (!confirm('Save current refinement as new baseline? This will replace the original results.')) {
        return;
    }
    
    try {
        showLoading();
        
        const response = await fetch('/api/refinement/save', {
            method: 'POST'
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || 'Failed to save refinement');
        }
        
        hideLoading();
        hideElement('refinement-modal');
        alert(data.message);
        
    } catch (error) {
        hideLoading();
        alert('Error saving refinement: ' + error.message);
    }
});

// Reset refinement
document.getElementById('reset-refinement-btn').addEventListener('click', async () => {
    if (!confirm('Reset to original results? This will undo all refinements.')) {
        return;
    }
    
    try {
        showLoading();
        
        const response = await fetch('/api/refinement/reset', {
            method: 'POST'
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || 'Failed to reset refinement');
        }
        
        // Update results
        state.results = data.results;
        displayResults();
        
        // Clear history
        refinementState.refinementHistory = [];
        updateRefinementHistory([]);
        
        hideLoading();
        hideElement('refinement-modal');
        alert(data.message);
        
    } catch (error) {
        hideLoading();
        alert('Error resetting refinement: ' + error.message);
    }
});

// Update refinement history display
function updateRefinementHistory(history) {
    const historySection = document.getElementById('refinement-history-section');
    const historyList = document.getElementById('refinement-history-list');
    
    if (!history || history.length === 0) {
        hideElement('refinement-history-section');
        return;
    }
    
    showElement('refinement-history-section');
    historyList.innerHTML = '';
    
    history.forEach((item, index) => {
        const historyItem = document.createElement('div');
        historyItem.className = 'bg-gray-50 border border-gray-200 rounded-lg p-3 flex items-start space-x-3';
        
        let iconClass = 'fa-plus-circle';
        let iconColor = 'text-blue-600';
        let description = '';
        
        if (item.action === 'add_criterion') {
            iconClass = 'fa-plus-circle';
            iconColor = 'text-blue-600';
            description = `Added criterion "${item.criterion}" with weight ${item.weight}`;
        } else if (item.action === 'adjust_weight') {
            iconClass = 'fa-balance-scale';
            iconColor = 'text-yellow-600';
            description = `Adjusted "${item.criterion}" weight to ${item.new_weight}`;
        } else if (item.action === 'filter_skills') {
            iconClass = 'fa-filter';
            iconColor = 'text-green-600';
            description = `Filtered by skills: ${item.skills.join(', ')} (${item.filtered_count} candidates)`;
        }
        
        historyItem.innerHTML = `
            <i class="fas ${iconClass} ${iconColor} text-lg mt-1"></i>
            <div class="flex-1">
                <div class="text-sm text-gray-800">${description}</div>
                <div class="text-xs text-gray-500 mt-1">${new Date(item.timestamp).toLocaleString()}</div>
            </div>
        `;
        
        historyList.appendChild(historyItem);
    });
}

// Show/hide loading overlay
function showLoading() {
    showElement('loading-overlay');
}

function hideLoading() {
    hideElement('loading-overlay');
}

// ============================================================================
// INITIALIZATION
// ============================================================================

// Start at step 1
goToStep(1);

// Make removeFile available globally
window.removeFile = removeFile;
