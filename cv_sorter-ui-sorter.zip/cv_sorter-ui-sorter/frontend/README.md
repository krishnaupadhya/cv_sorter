# CV Sorter - Web Interface

A clean, professional web interface for the CV Sorter application.

## Features

- **Step-by-Step Workflow**: Intuitive 4-step process for sorting resumes
- **Real-Time Progress**: Live updates during processing with Server-Sent Events
- **Drag & Drop Upload**: Easy file upload with drag-and-drop support
- **Responsive Design**: Works on desktop and mobile devices
- **Professional UI**: Built with TailwindCSS for a modern look

## Tech Stack

- **Backend**: Flask (Python web framework)
- **Frontend**: HTML5, CSS3, Vanilla JavaScript
- **Styling**: TailwindCSS (via CDN)
- **Icons**: Font Awesome
- **Real-time Updates**: Server-Sent Events (SSE)

## Installation

The frontend dependencies are automatically installed with the main project:

```bash
pip install -r requirements.txt
```

This installs:
- Flask (web framework)
- Flask-CORS (cross-origin resource sharing)

## Usage

### Launch the Web Interface

From the project root directory:

```bash
python3 main.py --api-key <YOUR_GROQ_API_KEY> --mode ui
```

The server will start on `http://127.0.0.1:5000` by default.

### Custom Host/Port

```bash
python3 main.py --api-key <YOUR_GROQ_API_KEY> --mode ui --port 8080
```

### CLI Mode (Original)

The original command-line mode still works:

```bash
python3 main.py --resumes ./RESUME/ --jd job-description.txt --api-key <KEY>
```

## How It Works

### Step 1: Create Job Description
- Provide a job title
- Paste or type the job description
- The system analyzes and extracts key criteria
- (API key is already configured via command-line argument)

### Step 2: Upload Resumes
- Drag & drop PDF or DOCX files (max 2MB each)
- Or click to browse and select files
- Review the list of uploaded files

### Step 3: Processing
- Real-time progress updates show each processing stage:
  - Parsing resumes
  - Generating embeddings
  - Computing semantic similarity
  - Ranking candidates
  - Generating detailed reports

### Step 4: View Results
- Summary cards show distribution of fit levels
- Ranked list of candidates with scores
- Detailed assessments for top 9 candidates
- Export results as JSON

## Architecture

### Backend API Endpoints

- `GET /` - Serve main UI page
- `POST /api/job` - Submit job description
- `POST /api/resumes` - Upload resume files
- `POST /api/process` - Trigger processing pipeline
- `GET /api/progress` - Server-Sent Events for progress updates
- `GET /api/results` - Retrieve final results

### File Structure

```
frontend/
├── app.py                 # Flask server & API endpoints
├── static/
│   ├── css/
│   │   └── styles.css     # Custom CSS styles
│   ├── js/
│   │   └── app.js         # Frontend JavaScript
│   └── uploads/           # Temporary file storage
└── templates/
    └── index.html         # Main UI template
```

### Data Flow

1. **Job Analysis**: User submits job description → API analyzes and caches criteria
2. **Resume Upload**: User uploads files → Saved to temporary storage
3. **Processing**: Backend runs pipeline asynchronously, emitting progress events
4. **Results**: Frontend displays ranked candidates with detailed reports

## Features

### Caching
- Job criteria are cached per job description
- Resume parsing is cached per file
- Embeddings are cached to avoid recomputation

### File Validation
- File type: PDF, DOCX only
- File size: Max 2MB per file
- Automatic validation and error reporting

### Progress Tracking
- Real-time progress bar (0-100%)
- Step-by-step status updates
- Error handling with user-friendly messages

### Results Export
- Download results as JSON
- Includes all candidate data and rankings
- Timestamped filename

## Browser Compatibility

- Chrome/Edge: ✅ Full support
- Firefox: ✅ Full support
- Safari: ✅ Full support
- Mobile browsers: ✅ Responsive design

## Development

### Running in Debug Mode

Edit `frontend/app.py` and change:

```python
app.run(host=host, port=port, debug=True, threaded=True)
```

### Customization

- **Colors**: Modify Tailwind classes in `templates/index.html`
- **Styles**: Edit `static/css/styles.css` for custom styling
- **Behavior**: Update `static/js/app.js` for frontend logic
- **API**: Modify `app.py` for backend changes

## Troubleshooting

### Port Already in Use

```bash
python3 main.py --api-key <KEY> --mode ui --port 8080
```

### API Key Issues

Make sure your Groq API key is valid:
- Get a free key at https://console.groq.com
- Paste the full key (starts with `gsk_`)

### Files Not Uploading

- Check file size (must be under 2MB)
- Verify file format (PDF or DOCX only)
- Ensure browser supports File API

### Processing Stuck

- Check browser console for JavaScript errors
- Verify backend server is still running
- Refresh the page and try again

## Security Notes

- API keys are never stored in the browser
- Files are temporarily stored and can be cleared
- No data is sent to external services (except Groq API for LLM calls)
- CORS is enabled for development (configure for production)

## Performance

- Processes 10-20 resumes in ~30-60 seconds
- Parallel resume parsing for speed
- Batch embedding generation
- Only 2 LLM calls total (job analysis + reports)

## Future Enhancements

- [ ] User authentication
- [ ] Save and load previous sessions
- [ ] Comparison mode (compare multiple job descriptions)
- [ ] Advanced filtering and sorting
- [ ] PDF export of results
- [ ] Candidate contact management

## License

Same as the main CV Sorter project.
