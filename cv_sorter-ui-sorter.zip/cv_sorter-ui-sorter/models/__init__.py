"""Models package — Data schemas and prompts."""
