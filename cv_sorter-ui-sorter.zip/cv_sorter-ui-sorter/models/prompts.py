"""
LLM prompt templates for production CV sorting system.

Contains prompts for:
1. Job Description Analysis (LLM Call #1) - extract criteria with weights
2. Candidate Report Generation (LLM Call #2) - narrative reports for top-N

All other processing is algorithmic (no LLM calls).
"""

# ============================================================================
# PROMPT #1 — Job Description Analysis (Enhanced with Skill Extraction)
# ============================================================================

JD_ANALYSIS_PROMPT = """You are a hiring criteria analyzer and skill extractor.
Given the job description below, extract TWO things as a JSON object.

CRITICAL: Your response must be EXACTLY the JSON structure shown below with NO additional text, NO markdown fences, NO explanations.

Required JSON structure:
{{
  "criteria": [
    {{"name": "skill or requirement", "weight": 5-10, "explanation": "one sentence"}}
  ],
  "skill_keywords": {{
    "programming_languages": ["python", "kotlin", "java"],
    "frameworks": ["react", "spring", "django"],
    "databases": ["postgresql", "mongodb", "room"],
    "cloud_devops": ["aws", "docker", "kubernetes"],
    "mobile": ["android", "ios", "flutter"],
    "ml_ai": ["tensorflow", "pytorch"],
    "other_tools": ["git", "jira", "rest"]
  }}
}}

RULES FOR EXTRACTION:

1. CRITERIA (technical skills/competencies only):
   - Extract ONLY technical skills, tools, frameworks, and competencies
   - DO NOT include years of experience, education, or soft skills
   - Each criterion must have: name (string), weight (integer 5-10), explanation (one sentence)
   
   Weight scale (use exact integers only):
   10 = absolutely critical, marked "must have" or "required"
   9 = core technical skill with "expert"/"strong"/"must" language
   8 = major framework/tool expertise mentioned prominently
   7 = important supporting skill
   6 = valuable additional skill
   5 = nice-to-have skill

2. SKILL_KEYWORDS (comprehensive keyword list):
   - Include ALL technical terms mentioned or strongly implied in JD
   - Add common synonyms: "nodejs" AND "node.js", "ML" AND "machine learning"
   - Add related technologies: "Android" → ["kotlin", "java", "android studio", "jetpack"]
   - Include abbreviations: "ci/cd" AND "continuous integration"
   - ALL keywords must be LOWERCASE for consistent matching
   - Organize by category: programming_languages, frameworks, databases, cloud_devops, mobile, ml_ai, other_tools

CRITICAL: Output ONLY the JSON object. Start with {{ and end with }}. No text before or after.

Job Description:
{jd_text}

JSON:"""


# ============================================================================
# PROMPT #2 — Candidate Report Generation
# ============================================================================

REPORT_GENERATION_PROMPT = """You are a hiring assistant writing a concise candidate assessment.

Candidate: {name}
Score: {combined_score}/100
Recommendation: {recommendation}
Matched skills: {matched_criteria}
Missing skills: {missing_criteria}
Years of experience: {experience_years}

Write exactly 3–4 sentences covering:
  1. Overall fit assessment for the role
  2. Top strengths — cite specific matched skills by name
  3. Key skill gaps — cite specific missing skills by name
  4. Hiring recommendation with brief reasoning

Rules:
  - Be specific — reference the actual skills listed above
  - Do not repeat the numeric score in your text
  - Do not use bullet points or lists — write in prose only
  - Keep total response under 120 words"""
