"""
LLM prompt templates for production CV sorting system.

Contains prompts for:
1. Job Description Analysis (LLM Call #1) - extract criteria with weights
2. Candidate Report Generation (LLM Call #2) - narrative reports for top-N

All other processing is algorithmic (no LLM calls).
"""

# ============================================================================
# PROMPT #1 — Job Description Analysis (Enhanced with Skill Extraction)
# ============================================================================

JD_ANALYSIS_PROMPT = """You are a hiring criteria analyzer and skill extractor with deep domain knowledge across all technology ecosystems.

Your task: Extract criteria AND comprehensive skill keywords (including related domain technologies) from the job description.

CRITICAL: Your response must be EXACTLY valid JSON with NO additional text, NO markdown fences, NO explanations before or after.

JSON structure (you MUST expand skill_keywords with related technologies):
{{
  "criteria": [
    {{"name": "skill or requirement", "weight": 5-10, "explanation": "one sentence"}}
  ],
  "skill_keywords": {{
    "programming_languages": ["kotlin", "java"],
    "frameworks": ["jetpack", "compose", "dagger", "hilt"],
    "mobile": ["android", "android sdk", "android studio", "aaos", "aosp", "android tv", "wear os"],
    "databases": ["room", "sqlite"],
    "cloud_devops": ["docker", "kubernetes", "ci/cd"],
    "certifications": ["aws certified", "google cloud certified", "oracle certified", "cisco ccna"],
    "other_tools": ["git", "gradle", "mvvm", "mvi"]
  }}
}}

RULES FOR EXTRACTION:

1. CRITERIA (technical skills/competencies AND certifications):
   - Extract technical skills, tools, frameworks, competencies, AND certifications
   - DO NOT include years of experience, education, or soft skills
   - Each criterion must have: name (string), weight (integer 5-10), explanation (one sentence)
   
   **CERTIFICATION EXTRACTION RULES**:
   - Extract ANY mentioned certifications (AWS Certified, Google Cloud, Oracle, Cisco, PMP, etc.)
   - Extract IMPLIED certifications for the role based on job description and domain knowledge
   - For Android roles → ADD: "Google Associate Android Developer", "Google Professional Android Developer"
   - For iOS roles → ADD: "Apple Certified iOS Developer", "Apple Certified iOS Technician"
   - For AWS roles → ADD: "AWS Certified Solutions Architect", "AWS Certified Developer"
   - For Azure roles → ADD: "Azure Administrator", "Azure Developer Certification"
   - For Google Cloud roles → ADD: "Google Cloud Professional Cloud Architect"
   - For ML/AI roles → ADD: "TensorFlow Developer Certificate", "AWS Machine Learning Specialty"
   - Certifications should ALWAYS have weight 5 or 6 (never higher than 6)
   
   Weight scale (use exact integers only):
   10 = absolutely critical PRIMARY skill, marked "must have" or "required"
   9 = core technical skill with "expert"/"strong"/"must" language
   8 = major framework/tool expertise mentioned prominently
   7 = important supporting skill
   6 = valuable additional skill OR certification (preferred/desired)
   5 = nice-to-have skill OR certification (nice-to-have)

2. SKILL_KEYWORDS - MUST include related domain technologies:
   
   **MANDATORY EXPANSION RULES**:
   
   ✅ If JD mentions "Android" → YOU MUST ALSO ADD:
      mobile: ["android", "android sdk", "android studio", "gradle", 
               "aaos", "android automotive", "android automotive os",
               "aosp", "android open-source project",
               "android tv", "wear os", "android wear", "android watch",
               "car system ui", "car launcher", "automotive sdk", "vehicle hal",
               "hmi", "human machine interface", "user profile"]
   
   ✅ If JD mentions "iOS" → YOU MUST ALSO ADD:
      mobile: ["ios", "swift", "swiftui", "uikit", "xcode", "cocoapods",
               "watchos", "watch os", "tvos", "tv os", "visionos",
               "carplay", "homekit", "healthkit", "combine", "core data"]
   
   ✅ If JD mentions "AWS" → YOU MUST ALSO ADD:
      cloud_devops: ["aws", "ec2", "s3", "lambda", "cloudformation",
                     "ecs", "eks", "fargate", "vpc", "route53",
                     "cloudwatch", "cloudtrail", "iam", "cognito",
                     "api gateway", "dynamodb", "rds", "elasticache"]
   
   ✅ If JD mentions "React" → YOU MUST ALSO ADD:
      frameworks: ["react", "react native", "nextjs", "next.js",
                   "redux", "react hooks", "jsx", "tsx",
                   "webpack", "vite", "react router"]
   
   ✅ If JD mentions "Machine Learning"/"ML" → YOU MUST ALSO ADD:
      ml_ai: ["machine learning", "ml", "deep learning", "dl",
              "tensorflow", "pytorch", "keras", "scikit-learn",
              "pandas", "numpy", "jupyter", "neural networks",
              "transformers", "nlp", "computer vision",
              "model training", "model deployment", "mlops"]
   
   ✅ If JD mentions "Microservices" → YOU MUST ALSO ADD:
      other_tools: ["microservices", "rest api", "restful", "graphql",
                    "grpc", "api gateway", "service mesh",
                    "kafka", "rabbitmq", "redis", "message queue"]
   
   ✅ CERTIFICATIONS - YOU MUST ALWAYS ADD ROLE-RELEVANT CERTIFICATIONS:
   
   If JD mentions "Android" → ADD:
      certifications: ["google associate android developer", 
                       "google professional android developer",
                       "android certified application developer"]
   
   If JD mentions "iOS" → ADD:
      certifications: ["apple certified ios developer",
                       "apple certified ios technician"]
   
   If JD mentions "AWS" → ADD:
      certifications: ["aws certified solutions architect",
                       "aws certified developer",
                       "aws certified devops engineer",
                       "aws certified sysops administrator"]
   
   If JD mentions "Azure" → ADD:
      certifications: ["azure administrator",
                       "azure developer associate",
                       "azure solutions architect"]
   
   If JD mentions "Google Cloud"/"GCP" → ADD:
      certifications: ["google cloud professional cloud architect",
                       "google cloud professional developer",
                       "google cloud associate engineer"]
   
   If JD mentions "Machine Learning"/"ML"/"AI" → ADD:
      certifications: ["tensorflow developer certificate",
                       "aws machine learning specialty",
                       "google cloud professional ml engineer"]
   
   If JD mentions "Project Management"/"Agile"/"Scrum" → ADD:
      certifications: ["pmp", "csm", "psm", "safe agilist"]
   
   - Add synonyms: "nodejs" AND "node.js", "k8s" AND "kubernetes"
   - ALL keywords LOWERCASE for matching
   - Target 30-70 total keywords across all categories (including certifications)

CRITICAL: Output ONLY the JSON object. Start with {{ and end with }}. No text before or after.

Job Description:
{jd_text}

JSON:"""


# ============================================================================
# PROMPT #2 — Candidate Report Generation
# ============================================================================

REPORT_GENERATION_PROMPT = """You are a hiring assistant writing a concise candidate assessment.

Candidate: {name}
Score: {combined_score}/100
Recommendation: {recommendation}
Matched skills and certifications: {matched_criteria}
Missing skills and certifications: {missing_criteria}
Years of experience: {experience_years}

Write exactly 3–4 sentences covering:
  1. Overall fit assessment for the role
  2. Top strengths — cite specific matched skills/certifications by name
  3. Key skill gaps — cite specific missing skills/certifications by name
  4. Hiring recommendation with brief reasoning

Rules:
  - Be specific — reference the actual skills and certifications listed above
  - Do not repeat the numeric score in your text
  - Do not use bullet points or lists — write in prose only
  - Keep total response under 120 words"""
