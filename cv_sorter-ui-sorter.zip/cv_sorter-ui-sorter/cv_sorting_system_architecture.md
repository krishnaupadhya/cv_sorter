# CV Sorting System — Architecture & Implementation Guide
> Optimised for Llama 3 8B via Groq API | Minimal LLM Calls | Parallel Local Processing

---

## Table of Contents

- [CV Sorting System — Architecture \& Implementation Guide](#cv-sorting-system--architecture--implementation-guide)
  - [Table of Contents](#table-of-contents)
  - [1. System Overview](#1-system-overview)
    - [Design Principles](#design-principles)
    - [Constraints](#constraints)
  - [2. High-Level Architecture Flow](#2-high-level-architecture-flow)
  - [3. Multi-Agent Pipeline](#3-multi-agent-pipeline)
    - [Agent Responsibility Table](#agent-responsibility-table)
  - [4. Component Specifications](#4-component-specifications)
    - [4.1 Job Analyzer Agent (LLM Call #1)](#41-job-analyzer-agent-llm-call-1)
      - [Weight Assignment Rules](#weight-assignment-rules)
      - [LLM Call Implementation](#llm-call-implementation)
      - [Expected Output Schema](#expected-output-schema)
    - [4.2 Resume Parser Agent (No LLM)](#42-resume-parser-agent-no-llm)
      - [Parsing Technique Comparison](#parsing-technique-comparison)
      - [Resume Extraction Pipeline](#resume-extraction-pipeline)
    - [4.3 Parallel Processing](#43-parallel-processing)
    - [4.4 Embedding Engine](#44-embedding-engine)
    - [4.5 FAISS Matching](#45-faiss-matching)
    - [4.6 Weighted Scoring Engine](#46-weighted-scoring-engine)
    - [4.7 Ranking Engine](#47-ranking-engine)
    - [4.8 Report Generator Agent (LLM Call #2)](#48-report-generator-agent-llm-call-2)
  - [5. Scoring \& Ranking Flow](#5-scoring--ranking-flow)
  - [6. Local Storage Architecture](#6-local-storage-architecture)
    - [Output Files](#output-files)
  - [7. Technology Stack](#7-technology-stack)
    - [Installation](#installation)
  - [8. Full Orchestrator Pseudocode](#8-full-orchestrator-pseudocode)
  - [9. Performance Optimisation](#9-performance-optimisation)
    - [Estimated Wall-Clock Times (50 resumes, 6-core machine)](#estimated-wall-clock-times-50-resumes-6-core-machine)
    - [Key Optimisations](#key-optimisations)
  - [10. Data Models (JSON Schemas)](#10-data-models-json-schemas)
    - [Resume Structured JSON](#resume-structured-json)
    - [Criteria JSON](#criteria-json)
    - [Ranked Candidate JSON](#ranked-candidate-json)
  - [11. LLM Prompt Templates](#11-llm-prompt-templates)
    - [Prompt #1 — Job Description Analysis](#prompt-1--job-description-analysis)
    - [Prompt #2 — Candidate Report Generation](#prompt-2--candidate-report-generation)
  - [12. Project File Structure](#12-project-file-structure)

---

## 1. System Overview

### Design Principles

- **Minimal LLM calls** — only 2 API calls per full pipeline run (job analysis + final reports)
- **Parallel resume processing** — `ProcessPoolExecutor` across all CPU cores
- **Fully offline** except for Groq inference API calls
- **Algorithmic scoring** — deterministic, fast, reproducible, no LLM reasoning
- **Local storage only** — FAISS for vector search, file-based outputs

### Constraints

| Constraint | Decision |
|---|---|
| LLM: Llama 3 8B (small model) | Use structured JSON prompts, low temperature, short contexts |
| No cloud vector DBs | Use FAISS locally |
| No Redis / managed queues | Use Python asyncio |
| No SaaS resume parsers | Use PyMuPDF + regex patterns |
| Must run offline | All models downloaded locally |

---

## 2. High-Level Architecture Flow

```
┌─────────────────────────────────────────────────────────────────────┐
│                        CV SORTING SYSTEM                            │
└─────────────────────────────────────────────────────────────────────┘

  [JOB DESCRIPTION TEXT]               [RESUME FOLDER (PDF / DOCX)]
          │                                          │
          ▼                                          ▼
  ┌───────────────────┐               ┌──────────────────────────────┐
  │  ★ LLM CALL #1    │               │     ProcessPoolExecutor      │
  │   Job Analyzer    │               │     (N workers, parallel)    │
  │   Groq/Llama3 8B  │               └──────────────┬───────────────┘
  └────────┬──────────┘                              │
           │                                         ▼
           ▼                             ┌────────────────────────────┐
  ┌─────────────────┐                   │  Doc Parser                │
  │  Criteria JSON  │                   │  PyMuPDF / python-docx     │
  │  + weights      │                   └──────────────┬─────────────┘
  └────────┬────────┘                                  │
           │                                           ▼
           │                            ┌────────────────────────────┐
           │                            │  NLP Extractor             │
           │                            │  Regex + fallback logic    │
           │                            └──────────────┬─────────────┘
           │                                           │
           │                                           ▼
           │                            ┌────────────────────────────┐
           │                            │  Structured Resume JSON    │
           │                            └──────────────┬─────────────┘
           │                                           │
           └──────────────────┬────────────────────────┘
                              │
                              ▼
             ┌──────────────────────────────┐
             │   Embedding Engine           │
             │   all-MiniLM-L6-v2 (local)   │
             │   Batch encode: JD + CVs     │
             └──────────────┬───────────────┘
                            │
                            ▼
             ┌──────────────────────────────┐
             │   FAISS Index (local)        │
             │   Cosine similarity search   │
             └──────────────┬───────────────┘
                            │
                            ▼
             ┌──────────────────────────────┐
             │   Weighted Scoring Engine    │
             │   skill ∩ criteria × weight  │
             │   70% algo + 30% semantic    │
             └──────────────┬───────────────┘
                            │
                            ▼
             ┌──────────────────────────────┐
             │   Ranking Engine             │
             │   Sort by combined_score     │
             │   No LLM involved            │
             └──────────────┬───────────────┘
                            │
                            ▼
             ┌──────────────────────────────┐
             │  ★ LLM CALL #2 (top-N only)  │
             │   Report Generator           │
             │   Groq / Llama3 8B           │
             └──────────────┬───────────────┘
                            │
                            ▼
             ┌──────────────────────────────┐
             │   Candidate Reports          │
             │   JSON + Markdown output     │
             └──────────────────────────────┘
```

> **★ Only 2 LLM calls in the entire pipeline.** Everything in between is local compute.

---

## 3. Multi-Agent Pipeline

```
  ┌───────────────┐     ┌───────────────┐     ┌───────────────┐
  │  Job Analyzer │────▶│ Resume Parser │────▶│ Skill Extract │
  │  Agent        │     │ Agent         │     │ Agent         │
  │  [★ LLM #1]   │     │ [parallel]    │     │ [Regex]       │
  └───────┬───────┘     └───────────────┘     └───────┬───────┘
          │ criteria JSON                             │ structured JSON
          │                                           │
          ▼                                           ▼
  ┌──────────────────────────────────────────────────────────┐
  │        Output Files (JSON/TXT in output/results/)        │
  │   criteria.json │ ranking.json │ ranking.txt │ skills.json│
  └──────────────────────────────────────────────────────────┘
          │                                           │
          ▼                                           ▼
  ┌───────────────┐                         ┌───────────────┐
  │  Embedding    │                         │  Matching     │
  │  Engine       │────────────────────────▶│  Agent        │
  │  [MiniLM]     │                         │  [FAISS]      │
  └───────────────┘                         └───────┬───────┘
                                                    │
                                                    ▼
                                           ┌───────────────┐
                                           │  Ranking      │
                                           │  Agent        │
                                           │  [algo sort]  │
                                           └───────┬───────┘
                                                   │
                                                   ▼
                                          ┌────────────────┐
                                          │  Report Gen.   │
                                          │  Agent         │
                                          │  [★ LLM #2]    │
                                          └────────────────┘
```

### Agent Responsibility Table

| Agent | Input | Processing | Output | Uses LLM? |
|---|---|---|---|---|
| Job Analyzer | JD text | Groq Llama 3 8B prompt | criteria JSON with weights | **YES — call #1** |
| Resume Parser | PDF / DOCX files | PyMuPDF, python-docx | raw text per resume | No |
| Skill Extractor | Raw text | Regex + fallback logic | structured resume JSON | No |
| Matching Agent | Resume JSON + criteria | FAISS cosine similarity | semantic scores array | No |
| Ranking Agent | All scores | Weighted blend + sort | ranked candidate list | No |
| Report Generator | Top-N candidates | Groq Llama 3 8B prompt | narrative report text | **YES — call #2** |

---

## 4. Component Specifications

### 4.1 Job Analyzer Agent (LLM Call #1)

**Input:** Raw job description text
**Output:** Structured JSON array of criteria with weights

#### Weight Assignment Rules

| Weight | Importance Level |
|---|---|
| 10 | Mandatory core requirement / years of experience |
| 9 | Critical technical skill — "expert", "strong", "must" language |
| 8 | Major framework or tool expertise |
| 7 | Important supporting skill |
| 6 | Valuable additional skill |
| 5 | Nice-to-have |

Weight calculation considers:
- Frequency of skill mention in JD
- Position of skill (top bullets = higher weight)
- Keywords: `expert`, `strong`, `must`, `required`, `proficiency`
- Years of experience requirement
- Leadership or architectural responsibilities

#### LLM Call Implementation

```python
import groq
import json
import hashlib

client = groq.Client()  # reads GROQ_API_KEY from environment

def analyze_job_description(jd_text: str) -> list[dict]:
    prompt = JD_ANALYSIS_PROMPT.format(jd_text=jd_text)
    response = client.chat.completions.create(
        model="llama-3.1-8b-instant",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.1,      # low temp for deterministic JSON output
        max_tokens=1200,
        response_format={"type": "json_object"},
    )
    raw = response.choices[0].message.content
    # Strip markdown fences if model adds them
    clean = raw.strip().lstrip("```json").rstrip("```").strip()
    return json.loads(clean)["criteria"]
```

#### Expected Output Schema

```json
{
  "criteria": [
    {
      "name": "5+ years Android development experience",
      "weight": 10,
      "explanation": "Mandatory experience baseline explicitly stated in JD"
    },
    {
      "name": "Expert knowledge of Kotlin and Java",
      "weight": 9,
      "explanation": "Primary languages marked with expert-level requirement"
    },
    {
      "name": "Proficiency with Jetpack libraries",
      "weight": 8,
      "explanation": "Compose, Room, Hilt, WorkManager listed explicitly"
    }
  ]
}
```

---

### 4.2 Resume Parser Agent (No LLM)

Processes PDF and DOCX files using local libraries. Each file runs in its own worker process.

#### Parsing Technique Comparison

| Approach | Speed | Offline | Accuracy | Verdict |
|---|---|---|---|---|
| LLM extraction | Slow — serial API calls | Partial | High | **AVOID for bulk** |
| PyMuPDF + regex | Very fast — <50ms/file | Yes | Good | **PRIMARY for PDF** |
| python-docx + regex | Fast — <30ms/file | Yes | Good | **PRIMARY for DOCX** |
| Regex + fallback | Very fast — no deps | Yes | Good | **CURRENT: name extraction** |
| LayoutLM | Medium — GPU ideal | Yes | Very high | Too heavy for 8B system |
| Apache Tika | Medium | Yes | Moderate | Fallback only |

#### Resume Extraction Pipeline

```python
import fitz          # PyMuPDF
import docx          # python-docx
import re

# Extend this list with domain-specific skills
SKILL_KEYWORDS = [
    "python", "kotlin", "java", "javascript", "typescript",
    "react", "android", "ios", "docker", "kubernetes",
    "sql", "postgresql", "mongodb", "aws", "gcp", "azure",
    "tensorflow", "pytorch", "fastapi", "django", "spring",
    "git", "ci/cd", "jenkins", "github actions", "mvvm", "mvi",
    "jetpack", "compose", "room", "hilt", "coroutines", "rxjava",
]

def extract_text_pdf(path: str) -> str:
    doc = fitz.open(path)
    return " ".join(page.get_text() for page in doc)

def extract_text_docx(path: str) -> str:
    doc = docx.Document(path)
    return " ".join(p.text for p in doc.paragraphs)

def extract_contact(text: str) -> dict:
    email = re.findall(r"[\w.+-]+@[\w-]+\.[\w.]+", text)
    phone = re.findall(r"\+?[\d][\d\s\-(). ]{7,}", text)
    return {
        "email": email[0] if email else "",
        "phone": phone[0].strip() if phone else "",
    }

def extract_name(text: str, filename: str = "", email: str = "", phone: str = "") -> str:
    """Extract name with multi-step fallback: text → filename → email → phone → Unknown"""
    lines = [line.strip() for line in text.split('\n') if line.strip()]
    
    # Check first 5 lines for valid name (2-4 capitalized words)
    for line in lines[:5]:
        if re.search(r'linkedin[:\s]|@|http|\\d{3,}', line.lower()):
            continue
        words = line.split()
        if 2 <= len(words) <= 4:
            if sum(1 for w in words if w and w[0].isupper()) >= len(words) * 0.7:
                return ' '.join(words[:3])
    
    # Fallback to filename, email, phone, or "Unknown"
    if filename:
        name = re.sub(r'[_-]', ' ', filename.replace('.pdf', '').replace('.docx', ''))
        name = re.sub(r'\\b(resume|cv)\\b', '', name, flags=re.IGNORECASE).strip()
        if name: return name.title()
    if email: return email.split('@')[0].replace('.', ' ').title()
    if phone: return phone
    return "Unknown"

def extract_skills(text: str) -> list[str]:
    text_lower = text.lower()
    return [s for s in SKILL_KEYWORDS if s in text_lower]

def extract_experience_years(text: str) -> int:
    patterns = [
        r"(\d+)\+?\s*years?\s*(?:of\s*)?experience",
        r"experience[:\s]+(\d+)\+?\s*years?",
    ]
    for pat in patterns:
        match = re.search(pat, text, re.IGNORECASE)
        if match:
            return int(match.group(1))
    return 0

def parse_resume(filepath: str) -> dict:
    ext = filepath.lower().split(".")[-1]
    text = extract_text_pdf(filepath) if ext == "pdf" \
           else extract_text_docx(filepath)
    contact = extract_contact(text)
    skills  = extract_skills(text)
    filename = filepath.split("/")[-1]
    return {
        "filepath":         filepath,
        "name":             extract_name(text, filename, contact["email"], contact["phone"]),
        "email":            contact["email"],
        "phone":            contact["phone"],
        "skills":           skills,
        "experience_years": extract_experience_years(text),
        "raw_text":         text,
        "skill_text":       " ".join(skills),   # used for embedding
    }
```

---

### 4.3 Parallel Processing

```
  Resume Files (10–50)
  ┌──────┬──────┬──────┬──────┬──────┬──────┐
  │ cv1  │ cv2  │ cv3  │ cv4  │ cv5  │ ...  │
  └──┬───┴──┬───┴──┬───┴──┬───┴──┬───┴──┬───┘
     │      │      │      │      │      │
     ▼      ▼      ▼      ▼      ▼      ▼
  ┌────────────────────────────────────────────┐
  │          ProcessPoolExecutor               │
  │  Worker1  Worker2  Worker3  Worker4  ...   │
  │    │        │        │        │            │
  │    ▼        ▼        ▼        ▼            │
  │  parse()  parse()  parse()  parse()        │
  │  nlp()    nlp()    nlp()    nlp()          │
  └─────────────────────┬──────────────────────┘
                        │  as_completed()
                        ▼
                ┌──────────────┐
                │  results[]   │
                └──────────────┘
```

```python
from concurrent.futures import ProcessPoolExecutor, as_completed
import os

def process_all_resumes(folder: str, max_workers: int = None) -> list[dict]:
    """
    Process all PDF/DOCX files in parallel.
    max_workers defaults to os.cpu_count().
    Use ProcessPoolExecutor (not ThreadPoolExecutor) for true CPU parallelism.
    """
    files = [
        os.path.join(folder, f)
        for f in os.listdir(folder)
        if f.lower().endswith((".pdf", ".docx"))
    ]
    if not files:
        raise ValueError(f"No resume files found in {folder}")

    workers = max_workers or min(os.cpu_count(), len(files))
    results, errors = [], []

    with ProcessPoolExecutor(max_workers=workers) as pool:
        future_map = {pool.submit(parse_resume, f): f for f in files}
        for future in as_completed(future_map):
            filepath = future_map[future]
            try:
                results.append(future.result())
            except Exception as e:
                errors.append({"file": filepath, "error": str(e)})
                print(f"[WARN] Failed to parse {filepath}: {e}")

    print(f"Parsed {len(results)}/{len(files)} resumes, {len(errors)} errors")
    return results
```

---

### 4.4 Embedding Engine

Uses `sentence-transformers/all-MiniLM-L6-v2` locally. 80MB model, runs on CPU, ~2ms per document.

**Why all-MiniLM-L6-v2:**
- 80MB model size — trivial to ship
- 384-dimensional embeddings — fast FAISS search
- Excellent semantic similarity for skill-matching
- Runs entirely on CPU — no GPU required
- Apache 2.0 license

```python
from sentence_transformers import SentenceTransformer
import numpy as np

# Load once at startup — ~200ms cold start
embed_model = SentenceTransformer("all-MiniLM-L6-v2")

def embed_batch(texts: list[str]) -> np.ndarray:
    """
    Encode a list of texts in a single batch.
    Returns L2-normalised float32 embeddings (shape: N x 384).
    normalize_embeddings=True means dot product == cosine similarity.
    """
    return embed_model.encode(
        texts,
        batch_size=16,              # tune to available RAM
        normalize_embeddings=True,
        show_progress_bar=False,
    ).astype(np.float32)

def get_jd_embedding(criteria: list[dict]) -> np.ndarray:
    """Flatten criteria names into a single text for JD embedding."""
    text = " ".join(c["name"] for c in criteria)
    return embed_batch([text])
```

---

### 4.5 FAISS Matching

FAISS runs locally with zero server overhead. For 50 resumes, search completes in under 10ms.

```python
import faiss

def build_faiss_index(embeddings: np.ndarray) -> faiss.IndexFlatIP:
    """
    IndexFlatIP = Inner Product on L2-normalised vectors = cosine similarity.
    No training required. Exact search — sufficient for up to ~10,000 documents.
    """
    dim = embeddings.shape[1]   # 384 for MiniLM
    index = faiss.IndexFlatIP(dim)
    index.add(embeddings)
    return index

def semantic_similarity_scores(
    jd_embedding: np.ndarray,
    index: faiss.IndexFlatIP,
    n_results: int
) -> tuple[np.ndarray, np.ndarray]:
    """
    Returns (scores, indices) both shape (n_results,).
    Scores are in [0, 1] range — higher is better.
    """
    scores, indices = index.search(
        jd_embedding.reshape(1, -1), n_results
    )
    return scores[0], indices[0]
```

---

### 4.6 Weighted Scoring Engine

Primary scoring mechanism. Deterministic and fully explainable. No LLM required.

```python
def compute_weighted_score(resume: dict, criteria: list[dict]) -> dict:
    """
    Score a resume against job criteria using keyword intersection.
    Returns algo_score (0-100), matched and missing criteria lists.
    """
    max_possible = sum(c["weight"] for c in criteria)
    earned       = 0
    matched, missing = [], []

    skills_lower = {s.lower() for s in resume.get("skills", [])}
    raw_lower    = resume.get("raw_text", "").lower()

    for criterion in criteria:
        # Tokenise criterion name, check against skills + raw text
        keywords = criterion["name"].lower().split()
        hit = any(
            kw in skills_lower or kw in raw_lower
            for kw in keywords
        )
        if hit:
            earned += criterion["weight"]
            matched.append(criterion["name"])
        else:
            missing.append(criterion["name"])

    return {
        "algo_score":       round((earned / max_possible) * 100, 1),
        "matched_criteria": matched,
        "missing_criteria": missing,
    }
```

---

### 4.7 Ranking Engine

Combines algorithmic and semantic scores. Blend ratio is tunable.

```python
ALGO_WEIGHT     = 0.70   # raises score for explicit keyword matches
SEMANTIC_WEIGHT = 0.30   # raises score for contextual similarity

STRONG_FIT_THRESHOLD   = 75
MODERATE_FIT_THRESHOLD = 55

def classify_candidate(score: float) -> str:
    if score >= STRONG_FIT_THRESHOLD:   return "Strong Fit"
    if score >= MODERATE_FIT_THRESHOLD: return "Moderate Fit"
    return "Weak Fit"

def rank_candidates(
    resumes: list[dict],
    criteria: list[dict],
    semantic_scores: np.ndarray
) -> list[dict]:
    """
    Produce a ranked list with combined scores.
    semantic_scores must be index-parallel to resumes list.
    """
    ranked = []
    for i, resume in enumerate(resumes):
        algo     = compute_weighted_score(resume, criteria)
        sem      = float(semantic_scores[i]) * 100  # scale to 0-100
        combined = round(
            ALGO_WEIGHT * algo["algo_score"] + SEMANTIC_WEIGHT * sem, 1
        )
        ranked.append({
            **resume,
            **algo,
            "semantic_score": round(sem, 1),
            "combined_score": combined,
            "recommendation": classify_candidate(combined),
        })

    return sorted(ranked, key=lambda x: x["combined_score"], reverse=True)
```

---

### 4.8 Report Generator Agent (LLM Call #2)

Called only for the top-N candidates (default: top 10). All 10 calls are fired concurrently via `asyncio.gather`.

```python
import asyncio
import groq

async_client = groq.AsyncClient()

async def generate_report(candidate: dict) -> dict:
    prompt = REPORT_GENERATION_PROMPT.format(
        name=candidate["name"],
        combined_score=candidate["combined_score"],
        recommendation=candidate["recommendation"],
        matched_criteria=", ".join(candidate["matched_criteria"]),
        missing_criteria=", ".join(candidate["missing_criteria"]),
        experience_years=candidate["experience_years"],
    )
    resp = await async_client.chat.completions.create(
        model="llama-3.1-8b-instant",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.3,
        max_tokens=250,
    )
    return {**candidate, "report_text": resp.choices[0].message.content}

async def generate_all_reports(top_candidates: list[dict]) -> list[dict]:
    """Fire all report requests concurrently — not serially."""
    return await asyncio.gather(
        *[generate_report(c) for c in top_candidates]
    )
```

---

## 5. Scoring & Ranking Flow

```
  Criteria JSON (from LLM #1)         Resume JSON (from NLP parser)
  ┌──────────────────────────┐         ┌──────────────────────────┐
  │ name: Kotlin + Java      │         │ skills: [Kotlin, Java,   │
  │ weight: 9                │         │  Jetpack, Coroutines,    │
  │ name: Jetpack libs       │         │  Room, Hilt, MVVM]       │
  │ weight: 8                │         │ experience_years: 6      │
  │ name: 5+ yrs Android     │         │ raw_text: ...            │
  │ weight: 10               │         └──────────┬───────────────┘
  └────────────┬─────────────┘                    │
               │                                  │
               └──────────────┬───────────────────┘
                              ▼
                ┌─────────────────────────┐
                │   Keyword Intersection  │
                │   skills ∩ criteria     │
                └─────────────┬───────────┘
                              │
                              ▼
                ┌─────────────────────────────────────┐
                │  algo_score =                       │
                │  Σ(matched criterion weights)       │
                │  ──────────────────────── × 100     │
                │  Σ(all criterion weights)           │
                └─────────────┬───────────────────────┘
                              │
              ┌───────────────┴────────────────────┐
              │                                    │
              ▼                                    ▼
  ┌───────────────────────┐          ┌───────────────────────────┐
  │  algo_score           │          │  semantic_score           │
  │  (keyword match ×     │          │  (FAISS cosine similarity │
  │   criterion weight)   │          │   on skill embeddings)    │
  └──────────┬────────────┘          └────────────┬──────────────┘
             │      × 0.70                        │   × 0.30
             └──────────────────┬─────────────────┘
                                ▼
                   ┌────────────────────────┐
                   │   combined_score       │
                   │   (0 – 100)            │
                   └────────────┬───────────┘
                                │
               ┌────────────────┼────────────────┐
               ▼                ▼                ▼
          score ≥ 75       score ≥ 55        score < 55
        ┌───────────┐    ┌───────────┐    ┌───────────┐
        │ Strong Fit│    │ Moderate  │    │ Weak Fit  │
        └───────────┘    │ Fit       │    └───────────┘
                         └───────────┘
```

---

## 6. Local Storage Architecture

### Output Files

The system generates timestamped output directories in `output/results/ranking_YYYYMMDD_HHMMSS/`:

```
output/results/ranking_20260321_150502/
├── criteria.json       # Extracted job requirements with weights
├── skills.json         # Combined skill vocabulary (baseline + JD-specific)
├── ranking.json        # Complete structured ranking data
└── ranking.txt         # Human-readable ranked list
```

**File Contents**:

1. **criteria.json**: Weighted evaluation criteria from Step 2
   - Each criterion has: name, weight (5-10), explanation
   
2. **skills.json**: Skill vocabulary for matching
   - Baseline skills (200+ technology keywords)
   - Job-specific skills extracted from JD
   
3. **ranking.json**: Complete structured output
   - All candidates with scores, matched/missing criteria, reports
   - Suitable for programmatic consumption
   
4. **ranking.txt**: Human-readable summary
   - Top candidates with scores and recommendations
   - Quick overview for recruiters

---

## 7. Technology Stack

| Layer | Tool | Version | Purpose |
|---|---|---|---|
| Backend API | FastAPI | >=0.110 | Async REST endpoints, job queue |
| Parallel processing | `concurrent.futures` | stdlib | `ProcessPoolExecutor` |
| PDF parsing | PyMuPDF (fitz) | >=1.23 | Fastest local PDF text extract |
| DOCX parsing | python-docx | >=1.1 | DOCX text extraction |
| Text Extraction | Regex patterns | stdlib | Name/contact extraction with fallback |
| Embedding model | sentence-transformers | >=2.7 | all-MiniLM-L6-v2, local CPU |
| Vector search | FAISS-cpu | >=1.8 | Local cosine similarity index |
| LLM inference | groq | >=0.9 | Llama 3 8B via Groq API |
| Async HTTP | httpx | >=0.27 | Concurrent Groq calls |
| Config | python-dotenv | >=1.0 | API key management |

### Installation

```bash
# Python dependencies
pip install fastapi uvicorn groq sentence-transformers \
            faiss-cpu pymupdf python-docx \
            httpx python-dotenv


# Environment
echo "GROQ_API_KEY=your_key_here" > .env
```

---

## 8. Full Orchestrator Pseudocode

```python
import asyncio
import hashlib
import json
import os

def md5(text: str) -> str:
    return hashlib.md5(text.encode()).hexdigest()

async def run_pipeline(
    jd_text: str,
    resume_folder: str,
    top_n: int = 10
) -> list[dict]:
    """
    Full end-to-end pipeline.
    Makes exactly 2 LLM calls: job analysis + top-N report generation.
    """
    # ── STEP 1: Job Analysis ─────────────────────────────────────────
    criteria = analyze_job_description(jd_text)        # ★ LLM CALL #1
    print(f"[JOB ANALYSIS] Extracted {len(criteria)} weighted criteria")

    # ── STEP 2: Parallel Resume Parsing (NO LLM) ─────────────────────
    resumes = process_all_resumes(resume_folder)

    # ── STEP 3: Batch Embedding (single forward pass, NO LLM) ────────
    jd_embedding    = get_jd_embedding(criteria)
    resume_texts    = [r["skill_text"] for r in resumes]
    resume_embeddings = embed_batch(resume_texts)

    # ── STEP 4: FAISS Semantic Scores ────────────────────────────────
    index = build_faiss_index(resume_embeddings)
    sem_scores, _ = semantic_similarity_scores(
        jd_embedding, index, n_results=len(resumes)
    )

    # ── STEP 5: Algorithmic Weighted Ranking (NO LLM) ────────────────
    ranked = rank_candidates(resumes, criteria, sem_scores)

    # ── STEP 6: Report Generation for Top-N Only (★ LLM CALL #2) ────
    top_candidates = ranked[:top_n]
    reports = await generate_all_reports(top_candidates)  # async concurrent

    # ── STEP 7: Merge Reports into Final Output ───────────────────────
    report_map = {r["filepath"]: r["report_text"] for r in reports}
    for candidate in ranked:
        candidate["report_text"] = report_map.get(
            candidate["filepath"], "Not in top selection."
        )

    # ── STEP 8: Save Output Files ────────────────────────────────────
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = f"output/results/ranking_{timestamp}"
    os.makedirs(output_dir, exist_ok=True)
    
    # Save all outputs
    with open(f"{output_dir}/criteria.json", "w") as f:
        json.dump(criteria, f, indent=2)
    with open(f"{output_dir}/ranking.json", "w") as f:
        json.dump(ranked, f, indent=2)
    
    return ranked
```
    """)
```

---

## 9. Performance Optimisation

### Estimated Wall-Clock Times (50 resumes, 6-core machine)

| Stage | Time | Parallelism | Notes |
|---|---|---|---|
| LLM job analysis | ~2s | N/A — single call | Cached after first run → 0s |
| Parallel resume parse | ~8s | 6 workers | Main bottleneck — scales with cores |
| Batch embedding | ~3s | Single batch call | all-MiniLM on CPU |
| FAISS + scoring | <1s | Single thread | Negligible for 50 docs |
| Top-10 report gen (async) | ~5s | 10 concurrent API calls | Groq handles concurrency |
| **TOTAL** | **~19s** | | vs ~90s naive serial baseline |

### Key Optimisations

**1. Batch embeddings — never encode one-by-one**
```python
# WRONG: 50 serial calls, high Python overhead
embeddings = [embed_model.encode(text) for text in texts]

# CORRECT: 3–4 batched forward passes at batch_size=16
embeddings = embed_model.encode(texts, batch_size=16, normalize_embeddings=True)
```

**2. ProcessPoolExecutor for CPU-bound parsing**
```python
# ProcessPoolExecutor for CPU-bound parsing
with ThreadPoolExecutor() as pool: ...

# CORRECT: ProcessPoolExecutor — true parallelism
with ProcessPoolExecutor(max_workers=os.cpu_count()) as pool: ...
```

**3. Async concurrent report generation**
```python
# WRONG: serial — 10 sequential Groq calls ~20s
for candidate in top_10:
    report = generate_report(candidate)   # blocks

# CORRECT: concurrent — all 10 in-flight at once ~5s
reports = await asyncio.gather(*[generate_report(c) for c in top_10])
```

**4. Structured prompts reduce Llama 3 8B JSON failures**
```python
# Always set low temperature for structured output
temperature=0.1

# Always strip potential markdown fences before parsing
clean = raw.strip().lstrip("```json").rstrip("```").strip()

# Wrap in try/except with one automatic retry
try:
    return json.loads(clean)
except json.JSONDecodeError:
    # retry once with explicit instruction
    return retry_with_stricter_prompt(jd_text)
```

---

## 10. Data Models (JSON Schemas)

### Resume Structured JSON

```json
{
  "filepath":         "string — absolute path to source file",
  "name":             "string — candidate full name",
  "email":            "string",
  "phone":            "string",
  "skills":           ["array", "of", "skill", "strings"],
  "experience_years": 0,
  "raw_text":         "string — full extracted text",
  "skill_text":       "string — skills joined for embedding"
}
```

### Criteria JSON

```json
{
  "criteria": [
    {
      "name":        "string — skill or requirement name",
      "weight":      9,
      "explanation": "string — one sentence reason for weight"
    }
  ]
}
```

### Ranked Candidate JSON

```json
{
  "filepath":         "string",
  "name":             "string",
  "email":            "string",
  "skills":           ["string"],
  "experience_years": 5,
  "algo_score":       82.5,
  "semantic_score":   77.3,
  "combined_score":   80.9,
  "recommendation":   "Strong Fit",
  "matched_criteria": ["Expert knowledge of Kotlin and Java", "..."],
  "missing_criteria": ["Experience with CI/CD pipelines", "..."],
  "report_text":      "string — LLM generated narrative (top-N only)"
}
```

---

## 11. LLM Prompt Templates

### Prompt #1 — Job Description Analysis

```
You are a hiring criteria analyzer.
Given the job description below, extract evaluation criteria as a JSON array.
Each item must have:
  - "name": skill or requirement (string)
  - "weight": integer 5–10 based on importance
  - "explanation": one sentence reason

Weight scale:
  10 = mandatory / years-of-experience baseline
   9 = core technical skill with "expert", "strong", "must" language
   8 = major framework or tool expertise
   7 = important supporting skill
   6 = valuable additional skill
   5 = nice-to-have

Weight calculation factors:
  - Frequency of skill mention in JD
  - Position in JD (top bullet points = higher weight)
  - Keywords: expert, strong, must, required, proficiency
  - Years of experience requirement
  - Leadership or architectural responsibilities

Respond ONLY with valid JSON. No preamble. No markdown fences.

Job Description:
{jd_text}

JSON:
```

### Prompt #2 — Candidate Report Generation

```
You are a hiring assistant writing a concise candidate assessment.

Candidate: {name}
Score: {combined_score}/100
Recommendation: {recommendation}
Matched skills: {matched_criteria}
Missing skills: {missing_criteria}
Years of experience: {experience_years}

Write exactly 3–4 sentences covering:
  1. Overall fit assessment for the role
  2. Top strengths — cite specific matched skills by name
  3. Key skill gaps — cite specific missing skills by name
  4. Hiring recommendation with brief reasoning

Rules:
  - Be specific — reference the actual skills listed above
  - Do not repeat the numeric score in your text
  - Do not use bullet points or lists — write in prose only
  - Keep total response under 120 words
```

---

## 12. Project File Structure

```
cv_sorter/
├── main.py                  # FastAPI app, pipeline entry point
├── agents/
│   ├── job_analyzer.py      # LLM call #1 — criteria extraction
│   ├── resume_parser.py     # PyMuPDF + python-docx + regex
│   ├── skill_extractor.py   # Regex patterns, section parsing
│   ├── matching_agent.py    # FAISS index, semantic scores
│   ├── ranking_agent.py     # weighted scoring, combined rank
│   └── report_generator.py  # LLM call #2 — async reports
├── models/
│   ├── schemas.py           # Pydantic models for all data types
│   └── prompts.py           # LLM prompt templates as constants
├── storage/                 # Storage layer (placeholder for future features)
├── config.py                # Settings, thresholds, model names
├── requirements.txt
└── .env                     # GROQ_API_KEY=...
```

---

*This document is designed to be fed directly to an LLM for code generation. All flow diagrams use ASCII art for maximum compatibility. All pseudocode is production-ready Python.*
