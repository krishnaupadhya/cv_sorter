"""
Resume Parser Agent — Parallel Processing

Extracts structured data from PDF/DOCX resumes using:
- PyMuPDF for PDF parsing
- python-docx for DOCX parsing
- Robust name extraction with fallback logic (text → filename → email → phone → Unknown)
- Regex for contact info and skills
- ProcessPoolExecutor for parallel processing

NO LLM calls — fully local deterministic extraction.

Recent improvements (March 20, 2026):
- Enhanced name extraction with 5-step fallback strategy
- Filters out LinkedIn handles, phone numbers, and junk text
- Extracts clean names (first, middle, last max 30 chars)
- Falls back to filename, email, or phone if name not found
"""

import os
import re
from pathlib import Path
from typing import List, Dict, Optional
from concurrent.futures import ProcessPoolExecutor, as_completed

import fitz  # PyMuPDF
from docx import Document

# Skill keywords list — base set that can be extended with job-specific skills
SKILL_KEYWORDS = [
    # Programming languages
    "python", "kotlin", "java", "javascript", "typescript", "c++", "c#", "go",
    "rust", "swift", "ruby", "php", "scala", "r", "matlab",
    
    # Web frameworks
    "react", "angular", "vue", "django", "flask", "fastapi", "spring", "express",
    "nextjs", "gatsby", "svelte",
    
    # Mobile
    "android", "ios", "react native", "flutter", "xamarin", "ionic",
    
    # Mobile Android specific
    "jetpack", "compose", "room", "hilt", "coroutines", "rxjava", "mvvm", "mvi",
    "dagger", "retrofit", "okhttp", "glide", "picasso", "workmanager",
    
    # Databases
    "sql", "postgresql", "mysql", "mongodb", "redis", "elasticsearch", "cassandra",
    "dynamodb", "oracle", "sqlite",
    
    # Cloud & DevOps
    "aws", "gcp", "azure", "docker", "kubernetes", "jenkins", "gitlab", "github actions",
    "terraform", "ansible", "ci/cd", "devops",
    
    # ML/AI
    "tensorflow", "pytorch", "keras", "scikit-learn", "pandas", "numpy", "opencv",
    "machine learning", "deep learning", "nlp", "computer vision",
    
    # Other tools
    "git", "linux", "bash", "rest", "graphql", "api", "microservices", "agile",
    "scrum", "jira", "confluence",
]

# Active skills list — can be updated with job-specific skills
_ACTIVE_SKILLS = SKILL_KEYWORDS.copy()


def set_active_skills(skills: List[str]) -> None:
    """
    Set the active skill keywords to use for extraction.
    
    This should be called before parsing resumes to use job-specific skills.
    
    Args:
        skills: List of skill keywords (combined base + job-specific)
    """
    global _ACTIVE_SKILLS
    _ACTIVE_SKILLS = skills


def get_active_skills() -> List[str]:
    """Get the current active skill keywords."""
    return _ACTIVE_SKILLS


def extract_text_pdf(filepath: str) -> str:
    """Extract text from PDF using PyMuPDF."""
    doc = fitz.open(filepath)
    text_parts = []
    for page in doc:
        text_parts.append(page.get_text())
    doc.close()
    return " ".join(text_parts)


def extract_text_docx(filepath: str) -> str:
    """Extract text from DOCX using python-docx."""
    doc = Document(filepath)
    return " ".join(paragraph.text for paragraph in doc.paragraphs)


def extract_contact(text: str) -> Dict[str, str]:
    """Extract email and phone from text using regex."""
    # Email pattern
    email_pattern = r"[\w.+-]+@[\w-]+\.[\w.]+"
    emails = re.findall(email_pattern, text)
    
    # Phone pattern (supports various formats)
    phone_pattern = r"\+?[\d][\d\s\-(). ]{7,}"
    phones = re.findall(phone_pattern, text)
    
    return {
        "email": emails[0] if emails else "",
        "phone": phones[0].strip() if phones else "",
    }


def extract_name(text: str, filename: str = "", email: str = "", phone: str = "") -> str:
    """
    Extract name from resume text with robust fallback logic.
    
    Strategy:
    1. Try to extract name from resume text (first 5 lines)
    2. Fall back to extracting from filename (common format: "John_Doe_Resume.pdf")
    3. Fall back to email address
    4. Fall back to phone number
    5. Fall back to raw filename
    6. Fall back to "Unknown" (rarely happens)
    
    Name cleaning:
    - Filter out LinkedIn handles, URLs, phone numbers
    - Remove common resume prefixes (Resume, CV, Curriculum Vitae)
    - Extract only proper name format (2-4 words, capitalized)
    - Limit to 30 characters max
    
    Args:
        text: Resume text content
        filename: Original filename (for fallback)
        email: Extracted email (for fallback)
        phone: Extracted phone (for fallback)
        
    Returns:
        Clean name string (max 30 chars) or fallback value
    """
    MAX_NAME_LENGTH = 30
    
    # STEP 1: Try to extract from resume text
    lines = [line.strip() for line in text.split('\n') if line.strip()]
    
    # Check first 5 lines for a valid name
    for line in lines[:5]:
        # Skip lines that look like headers, contact info, or junk
        line_lower = line.lower()
        
        # Skip if contains obvious non-name patterns
        skip_patterns = [
            r'linkedin[:\s]',           # LinkedIn: ...
            r'@',                        # Email or social handle
            r'http[s]?://',             # URLs
            r'\d{3,}',                   # Phone numbers (3+ digits in sequence)
            r'[•|]',                     # Bullet points or separators
            r'^(resume|cv|curriculum vitae)',  # Resume headers
            r'(email|phone|mobile|address|location)[:\s]',  # Contact labels
        ]
        
        if any(re.search(pattern, line_lower) for pattern in skip_patterns):
            continue
        
        # Clean the line
        cleaned = line
        
        # Remove common prefixes
        cleaned = re.sub(r'^(Resume|CV|Curriculum Vitae)\s*[-:]\s*', '', cleaned, flags=re.IGNORECASE)
        
        # Remove trailing contact info patterns
        cleaned = re.sub(r'\s*[•|]\s*[\d\s\-\(\)]+$', '', cleaned)  # Phone at end
        cleaned = re.sub(r'\s*,\s*[\w\s]+,\s*[\w\s]+$', '', cleaned)  # Location at end
        
        # Check if it looks like a name (2-4 capitalized words)
        words = cleaned.split()
        if 2 <= len(words) <= 4:
            # Check if words are mostly capitalized (proper nouns)
            capitalized_count = sum(1 for w in words if w and w[0].isupper())
            if capitalized_count >= len(words) * 0.7:  # At least 70% capitalized
                # Check if words contain mostly letters (not numbers or symbols)
                alpha_ratio = sum(c.isalpha() or c.isspace() for c in cleaned) / len(cleaned) if cleaned else 0
                if alpha_ratio >= 0.8:  # At least 80% letters
                    name = ' '.join(words[:3])  # Take first 3 words max (first, middle, last)
                    return name[:MAX_NAME_LENGTH]
    
    # STEP 2: Try to extract from filename
    if filename:
        # Remove extension
        name_from_file = Path(filename).stem
        
        # Common filename patterns: "John_Doe_Resume.pdf", "JohnDoe.pdf", "John-Doe-CV.pdf"
        # Replace underscores and hyphens with spaces
        name_from_file = re.sub(r'[_-]', ' ', name_from_file)
        
        # Remove common resume keywords
        name_from_file = re.sub(
            r'\b(resume|cv|curriculum|vitae|updated|latest|new|final)\b',
            '',
            name_from_file,
            flags=re.IGNORECASE
        )
        
        # Clean up multiple spaces
        name_from_file = re.sub(r'\s+', ' ', name_from_file).strip()
        
        # Check if it looks like a name (2-4 words)
        words = name_from_file.split()
        if 2 <= len(words) <= 4:
            name = ' '.join(words[:3])  # First, middle, last
            # Title case
            name = name.title()
            return name[:MAX_NAME_LENGTH]
    
    # STEP 3: Fall back to email
    if email:
        # Extract name part from email (before @)
        email_name = email.split('@')[0]
        # Replace dots, underscores with spaces
        email_name = re.sub(r'[._-]', ' ', email_name)
        # Title case
        email_name = email_name.title()
        return email_name[:MAX_NAME_LENGTH]
    
    # STEP 4: Fall back to phone
    if phone:
        return phone[:MAX_NAME_LENGTH]
    
    # STEP 5: Fall back to filename (raw, without cleaning)
    if filename:
        # Use the raw filename (with extension) as last resort
        return filename[:MAX_NAME_LENGTH]
    
    # STEP 6: Fall back to Unknown (should rarely happen)
    return "Unknown"


def extract_skills(text: str) -> List[str]:
    """
    Extract skills by keyword matching across multiple resume sections.
    
    GUARDRAIL #6: Enhanced section parsing including:
    - TECHNICAL SKILLS, CORE COMPETENCIES, EXPERTISE
    - DATABASES, SOFTWARE, PROGRAMMING
    - PROFESSIONAL HISTORY, WORK EXPERIENCE
    - Non-titled skill lists and technical terms
    """
    text_lower = text.lower()
    found_skills = []
    
    # Extract sections with common skill headers
    skill_sections = [
        r"technical\s+skills?[:\s]+(.*?)(?=\n\s*\n|$)",
        r"core\s+competencies[:\s]+(.*?)(?=\n\s*\n|$)",
        r"expertise[:\s]+(.*?)(?=\n\s*\n|$)",
        r"programming[:\s]+(.*?)(?=\n\s*\n|$)",
        r"databases?[:\s]+(.*?)(?=\n\s*\n|$)",
        r"software[:\s]+(.*?)(?=\n\s*\n|$)",
        r"professional\s+history[:\s]+(.*?)(?=\n\s*\n|education|$)",
        r"work\s+experience[:\s]+(.*?)(?=\n\s*\n|education|$)",
    ]
    
    # Extract text from skill-focused sections
    section_text = []
    for pattern in skill_sections:
        matches = re.findall(pattern, text_lower, re.DOTALL | re.IGNORECASE)
        section_text.extend(matches)
    
    # Combine section text with full text for comprehensive matching
    combined_text = text_lower + " " + " ".join(section_text)
    
    # Use active skills (base + job-specific)
    for skill in _ACTIVE_SKILLS:
        # Use word boundaries to avoid partial matches
        pattern = r'\b' + re.escape(skill) + r'\b'
        if re.search(pattern, combined_text):
            found_skills.append(skill)
    
    return found_skills


def extract_experience_years(text: str) -> float:
    """
    Extract years of experience from text.
    
    GUARDRAIL #5: Enhanced patterns covering:
    - "4+ years of experience" → 4
    - "having 10+ years of expertise" → 10
    - "5+ years", "5 years" → 5
    - "Total Years of Experience* 5 Years" → 5
    - "with 4.5 years", "4.10 years" → 4.5
    - Form fields like "Experience: 5"
    """
    patterns = [
        # "Total Years of Experience* 5 Years" (form field format)
        r"total\s+years?\s+of\s+experience[*:\s]+(\d+\.?\d*)\s*years?",
        # "4+ years of experience"
        r"(\d+\.?\d*)\+?\s*years?\s+of\s+(experience|expertise|exp)\b",
        # "having 10+ years of expertise"
        r"having\s+(\d+\.?\d*)\+?\s*years?\s+of\s+(experience|expertise|exp)\b",
        # "with 5 years", "with 4.5 years"
        r"with\s+(\d+\.?\d*)\+?\s*years?(?:\s+of)?\s*(experience|expertise|exp)?\b",
        # "5+ years", "5 years" at beginning of sentence or after comma
        r"(?:^|[,;.])\s*(\d+\.?\d*)\+?\s*years?(?!\s+old)\b",
        # "Experience: 5", "Expertise: 10 years"
        r"(experience|expertise)[*:\s]+(\d+\.?\d*)\+?\s*years?\b",
        # "10+ years of experience/expertise" or "4.5 years of experience"
        r"(\d+\.?\d*)\+?\s*years?\s*(?:of\s*)?(experience|expertise|exp)\b",
        # "having 10+ years" or "having 4.5 years"
        r"having\s+(\d+\.?\d*)\+?\s*years?\b",
        # "10+ yrs of exp/experience/expertise"
        r"(\d+\.?\d*)\+?\s*yrs?\s*(?:of\s*)?(exp|experience|expertise)\b",
        # Handle formats like "10 years" followed by experience/expertise
        r"(\d+\.?\d*)\+?\s*years?\s*(?:of\s*)?(?:working\s*)?(?:professional\s*)?(experience|expertise)\b",
    ]
    
    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            # Get the first group that's a number (int or float)
            for group in match.groups():
                if group and re.match(r'^\d+\.?\d*$', group):
                    years = float(group)
                    # Sanity check (0-50 years is reasonable)
                    if 0 <= years <= 50:
                        return years
    
    return 0.0


def parse_single_resume(filepath: str) -> Dict:
    """
    Parse a single resume file with validation.
    
    This function is called by worker processes in parallel.
    Must be a top-level function (not nested) for ProcessPoolExecutor.
    
    Args:
        filepath: Path to resume file
        
    Returns:
        Dictionary with parsed resume data
        
    Raises:
        ValueError: If file is too large, invalid format, or corrupted
        Exception: If parsing fails
    """
    # GUARDRAIL #1: File size check (reject > 2MB)
    MAX_FILE_SIZE = 2 * 1024 * 1024  # 2MB
    file_size = os.path.getsize(filepath)
    
    if file_size > MAX_FILE_SIZE:
        raise ValueError(
            f"File too large: {file_size / (1024*1024):.2f}MB (max 2MB)"
        )
    
    ext = Path(filepath).suffix.lower()
    
    # GUARDRAIL #2: Format validation
    if ext not in ['.pdf', '.docx', '.doc']:
        raise ValueError(f"Unsupported file type: {ext}")
    
    # Extract text based on file type with error handling
    try:
        if ext == '.pdf':
            text = extract_text_pdf(filepath)
        elif ext in ['.docx', '.doc']:
            text = extract_text_docx(filepath)
        else:
            raise ValueError(f"Unsupported file type: {ext}")
    except Exception as e:
        raise ValueError(f"Invalid or corrupted {ext.upper()} file: {str(e)}")
    
    # Extract structured data
    contact = extract_contact(text)
    skills = extract_skills(text)
    
    # Extract name with fallback logic (text → filename → email → phone → Unknown)
    name = extract_name(
        text=text,
        filename=os.path.basename(filepath),
        email=contact["email"],
        phone=contact["phone"]
    )
    
    experience_years = extract_experience_years(text)
    
    # Create skill text for embedding (join all skills)
    skill_text = " ".join(skills)
    
    return {
        "filepath": filepath,
        "filename": os.path.basename(filepath),
        "name": name,
        "email": contact["email"],
        "phone": contact["phone"],
        "skills": skills,
        "experience_years": experience_years,
        "raw_text": text,
        "skill_text": skill_text,
    }


def process_all_resumes(folder: str, max_workers: Optional[int] = None) -> List[Dict]:
    """
    Process all PDF/DOCX resumes in parallel.
    
    Uses ProcessPoolExecutor (not ThreadPoolExecutor) for true parallelism
    since document parsing is CPU-bound.
    
    Args:
        folder: Directory containing resume files
        max_workers: Number of worker processes (default: CPU count)
        
    Returns:
        List of parsed resume dictionaries
        
    Example:
        >>> resumes = process_all_resumes("./RESUME/")
        >>> len(resumes)
        42
        >>> resumes[0]["name"]
        "John Doe"
    """
    # Find all PDF and DOCX files
    folder_path = Path(folder)
    if not folder_path.exists():
        raise FileNotFoundError(f"Folder not found: {folder}")
    
    files = [
        str(f) for f in folder_path.iterdir()
        if f.suffix.lower() in ['.pdf', '.docx', '.doc']
    ]
    
    if not files:
        raise ValueError(f"No resume files found in {folder}")
    
    # Determine worker count
    workers = max_workers or min(os.cpu_count() or 4, len(files))
    
    results = []
    errors = []
    
    # Process in parallel
    with ProcessPoolExecutor(max_workers=workers) as executor:
        # Submit all jobs
        future_to_file = {
            executor.submit(parse_single_resume, filepath): filepath
            for filepath in files
        }
        
        # Collect results as they complete
        for future in as_completed(future_to_file):
            filepath = future_to_file[future]
            try:
                result = future.result()
                results.append(result)
            except Exception as e:
                errors.append({"file": filepath, "error": str(e)})
                print(f"[WARN] Failed to parse {os.path.basename(filepath)}: {e}")
    
    print(f"Parsed {len(results)}/{len(files)} resumes ({len(errors)} errors)")
    
    return results
