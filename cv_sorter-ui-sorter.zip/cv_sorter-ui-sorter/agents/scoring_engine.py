"""
Weighted Scoring Engine — Deterministic algorithmic scoring

Scores candidates using keyword intersection against weighted criteria.
NO LLM calls — fully deterministic and explainable.

Scoring formula:
    algo_score = (Σ matched_criterion_weights / Σ all_criterion_weights) × 100
"""

from typing import List, Dict


def compute_weighted_score(resume: Dict, criteria: List[Dict]) -> Dict:
    """
    Score a resume against job criteria using keyword matching.
    
    Algorithm:
    1. Extract skills and certifications from resume (already done in parsing)
    2. For each criterion, check if keywords appear in skills, certifications, or raw text
    3. Sum weights of matched criteria
    4. Normalize to 0-100 scale
    
    Args:
        resume: Parsed resume dict with 'skills', 'certifications', and 'raw_text'
        criteria: List of criteria dicts with 'name' and 'weight'
        
    Returns:
        Dict with:
        - algo_score: float 0-100
        - matched_criteria: list of matched criterion names
        - missing_criteria: list of unmatched criterion names
        
    Example:
        >>> resume = {
        ...     "skills": ["python", "django", "postgresql"],
        ...     "certifications": ["aws certified"],
        ...     "raw_text": "5 years of backend development..."
        ... }
        >>> criteria = [
        ...     {"name": "Python and Django", "weight": 9},
        ...     {"name": "AWS Certified Solutions Architect", "weight": 6},
        ...     {"name": "5+ years experience", "weight": 10}
        ... ]
        >>> compute_weighted_score(resume, criteria)
        {
            'algo_score': 100.0,
            'matched_criteria': ['Python and Django', 'AWS Certified Solutions Architect', '5+ years experience'],
            'missing_criteria': []
        }
    """
    max_possible = sum(c["weight"] for c in criteria)
    earned = 0
    matched = []
    missing = []
    
    # Normalize for case-insensitive matching
    skills_lower = {s.lower() for s in resume.get("skills", [])}
    certifications_lower = {c.lower() for c in resume.get("certifications", [])}
    raw_lower = resume.get("raw_text", "").lower()
    
    for criterion in criteria:
        # Extract keywords from criterion name
        criterion_name = criterion["name"]
        keywords = _extract_keywords(criterion_name)
        
        # Check if any keyword matches in skills, certifications, or raw text
        hit = any(
            kw in skills_lower or kw in certifications_lower or kw in raw_lower
            for kw in keywords
        )
        
        if hit:
            earned += criterion["weight"]
            matched.append(criterion_name)
        else:
            missing.append(criterion_name)
    
    # Calculate score as percentage
    algo_score = round((earned / max_possible) * 100, 1) if max_possible > 0 else 0.0
    
    return {
        "algo_score": algo_score,
        "matched_criteria": matched,
        "missing_criteria": missing,
    }


def _extract_keywords(text: str) -> set[str]:
    """
    Extract searchable keywords from criterion text.
    
    This function processes job criteria descriptions into keywords for matching
    against resume text and skills. Performs text normalization and stopword removal
    to focus on meaningful technical terms.
    
    Process:
        1. Convert to lowercase for case-insensitive matching
        2. Split on whitespace and common delimiters (comma, slash)
        3. Remove common English stopwords (of, the, and, etc.)
        4. Return unique keywords for matching
    
    Args:
        text: Criterion name like "5+ years of Python experience"
             or "Expert in React and TypeScript"
    
    Returns:
        Set of lowercase keywords for matching
        Example: {"5+", "years", "python", "experience"}
    
    Example:
        >>> keywords = _extract_keywords("Expert knowledge of Kotlin and Jetpack Compose")
        >>> print(keywords)
        {'expert', 'knowledge', 'kotlin', 'jetpack', 'compose'}
        
        >>> keywords = _extract_keywords("5+ years of AWS cloud experience")
        >>> print(keywords)
        {'5+', 'years', 'aws', 'cloud', 'experience'}
    
    Note:
        Preserves special characters like '+' in "5+" since they carry meaning.
        Stopword list covers common articles, prepositions, and auxiliary verbs.
    """
    import re
    
    # Lowercase and split on non-alphanumeric (keeping + for "5+")
    text = text.lower()
    
    # Split on whitespace and common delimiters
    tokens = re.split(r'[,/\s]+', text)
    
    # Remove common stopwords
    stopwords = {
        "of", "the", "and", "or", "in", "with", "for", "to", "a", "an",
        "is", "are", "was", "were", "be", "been", "being", "have", "has",
        "had", "do", "does", "did", "will", "would", "should", "could"
    }
    
    keywords = {
        token.strip() for token in tokens
        if token.strip() and token.strip() not in stopwords
    }
    
    return keywords
