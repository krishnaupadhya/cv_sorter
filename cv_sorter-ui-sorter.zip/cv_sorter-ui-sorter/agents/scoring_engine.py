"""
Weighted Scoring Engine — Deterministic algorithmic scoring

Scores candidates using keyword intersection against weighted criteria.
NO LLM calls — fully deterministic and explainable.

Scoring formula:
    algo_score = (Σ matched_criterion_weights / Σ all_criterion_weights) × 100
"""

from typing import List, Dict


def compute_weighted_score(resume: Dict, criteria: List[Dict]) -> Dict:
    """
    Score a resume against job criteria using keyword matching.
    
    Algorithm:
    1. Extract skills from resume (already done in parsing)
    2. For each criterion, check if keywords appear in skills or raw text
    3. Sum weights of matched criteria
    4. Normalize to 0-100 scale
    
    Args:
        resume: Parsed resume dict with 'skills' and 'raw_text'
        criteria: List of criteria dicts with 'name' and 'weight'
        
    Returns:
        Dict with:
        - algo_score: float 0-100
        - matched_criteria: list of matched criterion names
        - missing_criteria: list of unmatched criterion names
        
    Example:
        >>> resume = {
        ...     "skills": ["python", "django", "postgresql"],
        ...     "raw_text": "5 years of backend development..."
        ... }
        >>> criteria = [
        ...     {"name": "Python and Django", "weight": 9},
        ...     {"name": "5+ years experience", "weight": 10}
        ... ]
        >>> compute_weighted_score(resume, criteria)
        {
            'algo_score': 100.0,
            'matched_criteria': ['Python and Django', '5+ years experience'],
            'missing_criteria': []
        }
    """
    max_possible = sum(c["weight"] for c in criteria)
    earned = 0
    matched = []
    missing = []
    
    # Normalize for case-insensitive matching
    skills_lower = {s.lower() for s in resume.get("skills", [])}
    raw_lower = resume.get("raw_text", "").lower()
    
    for criterion in criteria:
        # Extract keywords from criterion name
        criterion_name = criterion["name"]
        keywords = _extract_keywords(criterion_name)
        
        # Check if any keyword matches
        hit = any(
            kw in skills_lower or kw in raw_lower
            for kw in keywords
        )
        
        if hit:
            earned += criterion["weight"]
            matched.append(criterion_name)
        else:
            missing.append(criterion_name)
    
    # Calculate score as percentage
    algo_score = round((earned / max_possible) * 100, 1) if max_possible > 0 else 0.0
    
    return {
        "algo_score": algo_score,
        "matched_criteria": matched,
        "missing_criteria": missing,
    }


def _extract_keywords(text: str) -> set[str]:
    """
    Extract searchable keywords from criterion text.
    
    Lowercases and splits on common delimiters, removes stopwords.
    
    Args:
        text: Criterion name like "5+ years of Python experience"
        
    Returns:
        Set of keywords: {"5+", "years", "python", "experience"}
    """
    import re
    
    # Lowercase and split on non-alphanumeric (keeping + for "5+")
    text = text.lower()
    
    # Split on whitespace and common delimiters
    tokens = re.split(r'[,/\s]+', text)
    
    # Remove common stopwords
    stopwords = {
        "of", "the", "and", "or", "in", "with", "for", "to", "a", "an",
        "is", "are", "was", "were", "be", "been", "being", "have", "has",
        "had", "do", "does", "did", "will", "would", "should", "could"
    }
    
    keywords = {
        token.strip() for token in tokens
        if token.strip() and token.strip() not in stopwords
    }
    
    return keywords
