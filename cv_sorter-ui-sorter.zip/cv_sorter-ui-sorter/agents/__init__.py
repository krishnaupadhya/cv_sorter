"""Agents package — Multi-agent pipeline components."""
