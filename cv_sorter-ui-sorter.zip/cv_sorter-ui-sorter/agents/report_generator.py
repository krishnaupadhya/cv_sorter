"""
Report Generator Agent — LLM Call #2

Generates narrative reports for top-N candidates only.
This is the SECOND and FINAL LLM call in the pipeline.

Supports multiple providers: Groq (cloud, fast), Ollama (local), Google AI Studio.
Uses async API to generate all reports concurrently.
"""

import asyncio
from typing import List, Dict

from langchain_core.messages import HumanMessage

from config import get_llm_for_report_generation
from models.prompts import REPORT_GENERATION_PROMPT


class ReportGenerator:
    """
    Generates narrative assessment reports for top candidates.
    
    Makes concurrent async LLM calls for efficiency.
    Only called for top-N candidates (typically 10-20).
    
    Uses Llama 3.1 8B for fast, high-throughput summarization.
    """
    
    def __init__(self, provider: str = "groq", api_key: str = None):
        """
        Initialize Report Generator with specified LLM provider.
        
        Args:
            provider: One of "groq", "ollama", "google"
            api_key: API key for cloud providers (not needed for ollama)
        """
        self.provider = provider
        self.api_key = api_key
        # Use 8B model for fast prose generation (3x faster than 70B)
        self.llm = get_llm_for_report_generation(provider=provider, api_key=api_key)
    
    async def generate_report(self, candidate: Dict) -> Dict:
        """
        Generate narrative report for a single candidate.
        
        Args:
            candidate: Candidate dict with scores and criteria matches
            
        Returns:
            Same dict enriched with 'report_text' field
        """
        # Format matched and missing criteria as comma-separated strings
        matched_str = ", ".join(candidate.get("matched_criteria", [])) or "None"
        missing_str = ", ".join(candidate.get("missing_criteria", [])) or "None"
        
        prompt = REPORT_GENERATION_PROMPT.format(
            name=candidate.get("name", "Unknown"),
            combined_score=candidate.get("combined_score", 0),
            recommendation=candidate.get("recommendation", "Unknown"),
            matched_criteria=matched_str,
            missing_criteria=missing_str,
            experience_years=candidate.get("experience_years", 0),
        )
        
        try:
            # Use async invoke with LangChain
            response = await self.llm.ainvoke([HumanMessage(content=prompt)])
            
            report_text = response.content.strip()
            
            return {
                **candidate,
                "report_text": report_text
            }
            
        except Exception as e:
            # Fallback to simple template if LLM fails
            report_text = self._fallback_report(candidate)
            return {
                **candidate,
                "report_text": report_text
            }
    
    async def generate_all_reports(self, candidates: List[Dict]) -> List[Dict]:
        """
        Generate reports for all candidates concurrently.
        
        Fires all LLM requests in parallel using asyncio.gather.
        Much faster than sequential calls.
        
        Args:
            candidates: List of candidate dicts
            
        Returns:
            Same list enriched with report_text
            
        Example:
            >>> generator = ReportGenerator(api_key="...")
            >>> top_10 = ranked_candidates[:10]
            >>> with_reports = await generator.generate_all_reports(top_10)
            >>> print(with_reports[0]['report_text'])
            "This candidate demonstrates strong fit for the role..."
        """
        if not candidates:
            return []
        
        # Fire all requests concurrently
        tasks = [self.generate_report(c) for c in candidates]
        results = await asyncio.gather(*tasks)
        
        return results
    
    def _fallback_report(self, candidate: Dict) -> str:
        """Simple template-based report if LLM fails."""
        name = candidate.get("name", "Candidate")
        score = candidate.get("combined_score", 0)
        recommendation = candidate.get("recommendation", "Unknown")
        matched_count = len(candidate.get("matched_criteria", []))
        missing_count = len(candidate.get("missing_criteria", []))
        
        return (
            f"{name} scored {score}/100 ({recommendation}). "
            f"Matched {matched_count} of the key criteria, "
            f"with {missing_count} skill gaps identified. "
            f"Candidate has {candidate.get('experience_years', 0)} years of experience."
        )
