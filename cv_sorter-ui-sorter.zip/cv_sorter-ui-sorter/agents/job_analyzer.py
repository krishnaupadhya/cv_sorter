"""
Job Analyzer Agent — LLM Call #1

Extracts structured evaluation criteria from job descriptions.
This is the FIRST of only TWO LLM calls in the entire pipeline.

Supports multiple providers: Groq (cloud, fast), Ollama (local), Google AI Studio.
Results are cached to avoid repeat calls for same JD.

Recent improvements (March 20, 2026):
- Temperature set to 0.0 for maximum determinism (was 0.1)
- Enhanced prompt structure with explicit JSON schema
- Stricter guidelines for consistent criteria extraction
- More comprehensive skill keyword extraction rules
"""

import json
import re
from typing import List, Dict

from langchain_core.messages import HumanMessage

from config import get_llm_for_job_analysis
from models.prompts import JD_ANALYSIS_PROMPT


class JobAnalyzer:
    """
    Analyzes job descriptions and extracts weighted criteria.
    
    This agent makes an LLM call to extract:
    - Skills and requirements
    - Importance weights (5-10 scale)
    - Explanations for weights
    
    Uses Llama 3.1 70B for superior domain knowledge and skill expansion.
    """
    
    def __init__(self, provider: str = "groq", api_key: str = None):
        """
        Initialize Job Analyzer with specified LLM provider.
        
        Args:
            provider: One of "groq", "ollama", "google"
            api_key: API key for cloud providers (not needed for ollama)
        """
        self.provider = provider
        self.api_key = api_key
        # Use 70B model for complex domain reasoning and skill expansion
        self.llm = get_llm_for_job_analysis(provider=provider, api_key=api_key)
    
    def analyze(self, jd_text: str) -> tuple[List[Dict[str, any]], List[str], List[str]]:
        """
        Extract criteria, skill keywords, and certification keywords from job description using LLM.
        
        Args:
            jd_text: Raw job description text
            
        Returns:
            Tuple of (criteria, skill_keywords, certification_keywords):
            - criteria: List of dicts with 'name', 'weight', 'explanation'
            - skill_keywords: Flat list of all skills extracted from JD (excluding certifications)
            - certification_keywords: Flat list of all certifications extracted from JD
            
        Example output:
            (
                [
                    {
                        "name": "Expert knowledge of Kotlin",
                        "weight": 9,
                        "explanation": "Primary language marked expert-level"
                    },
                    {
                        "name": "AWS Certified Solutions Architect",
                        "weight": 6,
                        "explanation": "Preferred certification for cloud expertise"
                    }
                ],
                ["kotlin", "java", "android", "jetpack", "compose", ...],
                ["aws certified", "aws solutions architect", ...]
            )
        """
        prompt = JD_ANALYSIS_PROMPT.format(jd_text=jd_text)
        
        # Try with larger token limit first
        max_attempts = 2
        
        for attempt in range(max_attempts):
            try:
                # Increase tokens for longer JDs, temperature always 0 for determinism
                max_tokens = 3000 if attempt == 0 else 3500
                
                if attempt > 0:
                    print(f"[RETRY {attempt}] Attempting with {max_tokens} tokens...")
                
                # Always use temperature=0 for maximum determinism
                llm = self.llm
                
                # Invoke LangChain LLM
                response = llm.invoke([HumanMessage(content=prompt)])
                
                raw = response.content
                
                # Clean markdown fences if model adds them
                clean = self._clean_response(raw)
                
                # Parse JSON
                data = json.loads(clean)
                
                # Handle new format: {criteria: [...], skill_keywords: {...}}
                if isinstance(data, dict):
                    if "criteria" in data and "skill_keywords" in data:
                        criteria = data["criteria"]
                        skill_keywords_dict = data["skill_keywords"]
                        
                        # Flatten skill_keywords from categories into skills and certifications
                        skill_keywords, cert_keywords = self._flatten_skills(skill_keywords_dict)
                    elif "criteria" in data:
                        # Legacy format: only criteria
                        criteria = data["criteria"]
                        skill_keywords = []
                        cert_keywords = []
                    else:
                        raise ValueError(f"Unexpected JSON structure: {data.keys()}")
                elif isinstance(data, list):
                    # Legacy format: direct array
                    criteria = data
                    skill_keywords = []
                    cert_keywords = []
                else:
                    raise ValueError(f"Unexpected JSON structure: {type(data)}")
                
                # Validate criteria structure
                validated_criteria = []
                for item in criteria:
                    if self._is_valid_criterion(item):
                        validated_criteria.append(item)
                
                if not validated_criteria:
                    raise ValueError("No valid criteria extracted from JD")
                
                return validated_criteria, skill_keywords, cert_keywords
                
            except json.JSONDecodeError as e:
                error_msg = f"Failed to parse LLM response as JSON: {e}"
                
                # On last attempt, raise the error
                if attempt == max_attempts - 1:
                    raise ValueError(f"{error_msg}\nResponse: {raw[:1000]}...")
                
                # Otherwise, retry
                print(f"[WARN] {error_msg}, retrying...")
                continue
                
            except Exception as e:
                # On last attempt, raise the error
                if attempt == max_attempts - 1:
                    raise RuntimeError(f"Job analysis failed: {e}")
                
                print(f"[WARN] Attempt {attempt + 1} failed: {e}, retrying...")
                continue
        
        raise RuntimeError("Failed to analyze job description after all retries")
    
    def _flatten_skills(self, skill_keywords_dict: Dict) -> tuple[List[str], List[str]]:
        """
        Flatten categorized skills into skills and certifications lists.
        
        Args:
            skill_keywords_dict: Dict with categories like 
                {"programming_languages": [...], "frameworks": [...], "certifications": [...]}
        
        Returns:
            Tuple of (skills, certifications):
            - skills: Flat list of all unique skills (lowercased, excluding certifications)
            - certifications: Flat list of all unique certifications (lowercased)
        """
        all_skills = []
        all_certifications = []
        
        for category, items in skill_keywords_dict.items():
            if isinstance(items, list):
                # Lowercase all items for consistent matching
                lowercased_items = [s.lower() for s in items if isinstance(s, str)]
                
                # Separate certifications from skills
                if category == "certifications":
                    all_certifications.extend(lowercased_items)
                else:
                    all_skills.extend(lowercased_items)
        
        # Remove duplicates while preserving order
        def dedupe(lst):
            seen = set()
            unique = []
            for item in lst:
                if item not in seen:
                    seen.add(item)
                    unique.append(item)
            return unique
        
        return dedupe(all_skills), dedupe(all_certifications)
    
    def _clean_response(self, text: str) -> str:
        """Remove markdown fences and whitespace."""
        text = text.strip()
        # Remove ```json ... ``` fences
        text = re.sub(r'^```(?:json)?\s*', '', text)
        text = re.sub(r'\s*```$', '', text)
        return text.strip()
    
    def _is_valid_criterion(self, item: Dict) -> bool:
        """Check if criterion has required fields."""
        required = {"name", "weight", "explanation"}
        if not all(k in item for k in required):
            return False
        
        # Validate weight range
        weight = item.get("weight")
        if not isinstance(weight, (int, float)) or not (5 <= weight <= 10):
            return False
        
        return True
