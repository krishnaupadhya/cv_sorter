"""Storage layer for CV Sorter — placeholder for future features."""
