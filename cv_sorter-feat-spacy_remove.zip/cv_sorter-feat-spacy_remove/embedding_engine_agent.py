"""
Embedding Engine — Local semantic similarity using sentence-transformers + FAISS

Uses all-MiniLM-L6-v2 model (80MB, runs on CPU) for embeddings.
FAISS provides fast cosine similarity search (IndexFlatIP).

NO cloud dependencies — fully offline operation after model download.
"""

from typing import List
import numpy as np

from sentence_transformers import SentenceTransformer
import faiss


class EmbeddingEngine:
    """
    Local embedding and similarity search engine.
    
    Uses sentence-transformers for encoding and FAISS for fast search.
    All processing is local — no API calls.
    """
    
    def __init__(self, model_name: str = "all-MiniLM-L6-v2"):
        """
        Initialize embedding model.
        
        Args:
            model_name: HuggingFace model name (default: all-MiniLM-L6-v2)
                       - 80MB size
                       - 384 dimensions
                       - Runs on CPU (~2ms per doc)
        """
        print(f"Loading embedding model: {model_name}...")
        self.model = SentenceTransformer(model_name)
        self.dimension = 384  # MiniLM-L6-v2 embedding dimension
        print(f"✓ Model loaded (dimension: {self.dimension})")
    
    def encode_batch(self, texts: List[str], batch_size: int = 16) -> np.ndarray:
        """
        Encode multiple texts in a single batch.
        
        Much faster than encoding one-by-one. Embeddings are L2-normalized
        so dot product = cosine similarity.
        
        Args:
            texts: List of text strings to encode
            batch_size: Batch size for encoding (tune based on RAM)
            
        Returns:
            Numpy array of shape (len(texts), 384) with normalized embeddings
        """
        embeddings = self.model.encode(
            texts,
            batch_size=batch_size,
            normalize_embeddings=True,  # L2 norm → dot product = cosine sim
            show_progress_bar=False,
            convert_to_numpy=True
        )
        return embeddings.astype(np.float32)
    
    def encode_single(self, text: str) -> np.ndarray:
        """Encode a single text (convenience wrapper)."""
        return self.encode_batch([text])[0]
    
    def build_faiss_index(self, embeddings: np.ndarray) -> faiss.IndexFlatIP:
        """
        Build FAISS index for fast similarity search.
        
        Uses IndexFlatIP (Inner Product) which equals cosine similarity
        when embeddings are L2-normalized.
        
        Args:
            embeddings: Numpy array of shape (N, 384)
            
        Returns:
            FAISS index ready for search
        """
        if embeddings.ndim != 2 or embeddings.shape[1] != self.dimension:
            raise ValueError(
                f"Expected embeddings shape (N, {self.dimension}), "
                f"got {embeddings.shape}"
            )
        
        # IndexFlatIP: exact search using inner product
        # No training needed, perfect for small datasets (<10K)
        index = faiss.IndexFlatIP(self.dimension)
        index.add(embeddings)
        
        return index
    
    def search(
        self,
        index: faiss.IndexFlatIP,
        query_embedding: np.ndarray,
        k: int
    ) -> tuple[np.ndarray, np.ndarray]:
        """
        Search FAISS index for top-k similar documents.
        
        Args:
            index: FAISS index built with build_faiss_index()
            query_embedding: Query vector (shape: (384,) or (1, 384))
            k: Number of results to return
            
        Returns:
            Tuple of (scores, indices):
            - scores: similarity scores in [0, 1] (higher = more similar)
            - indices: document indices in original embedding array
        """
        # Ensure query is 2D
        if query_embedding.ndim == 1:
            query_embedding = query_embedding.reshape(1, -1)
        
        scores, indices = index.search(query_embedding, k)
        
        # Return as 1D arrays
        return scores[0], indices[0]
    
    def get_jd_embedding(self, criteria: List[dict]) -> np.ndarray:
        """
        Create embedding for job description from criteria list.
        
        Flattens all criterion names into a single text for embedding.
        
        Args:
            criteria: List of criterion dicts with 'name' field
            
        Returns:
            Embedding vector (shape: (384,))
        """
        jd_text = " ".join(c["name"] for c in criteria)
        return self.encode_single(jd_text)
