"""
Job description parser module.

Simple module for loading job descriptions from text files.
The actual semantic extraction of requirements is done by the LLM in the prompts module.
"""

from pathlib import Path


def load_job_description(file_path: str) -> str:
    """
    Load job description text from a file.
    
    Supports plain text files. The LLM will handle semantic extraction
    of requirements, skills, experience, etc.
    
    Args:
        file_path: Path to job description file
    
    Returns:
        Job description text
    
    Raises:
        FileNotFoundError: If file does not exist
        ValueError: If file is empty
    
    Example:
        >>> jd_text = load_job_description("job_descriptions/senior_android_dev.txt")
        >>> print(len(jd_text))
        1523
    """
    path = Path(file_path)
    
    if not path.exists():
        raise FileNotFoundError(f"Job description file not found: {file_path}")
    
    # Read file content
    try:
        with open(path, 'r', encoding='utf-8') as f:
            text = f.read().strip()
    except UnicodeDecodeError:
        # Try with different encoding if UTF-8 fails
        with open(path, 'r', encoding='latin-1') as f:
            text = f.read().strip()
    
    if not text:
        raise ValueError(f"Job description file is empty: {file_path}")
    
    return text
