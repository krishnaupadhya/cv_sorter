# Quick Setup Guide

## 1. Install Dependencies

```bash
# Create and activate virtual environment
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install packages
pip install -r requirements.txt
```

## 2. Get API Key (Groq - Recommended)

1. Go to https://console.groq.com
2. Sign up for free account
3. Navigate to "API Keys" section
4. Click "Create API Key"
5. Copy the key (starts with `gsk_`)

## 3. Prepare Your Files

```bash
# Resumes should already be in RESUME/ directory
ls RESUME/

# Job description is already in job-description.txt
cat job-description.txt
```

## 4. Run the CV Sorter

```bash
# Using Groq (fast, requires API key)
python main.py --resumes ./RESUME/ --jd job-description.txt --api-key gsk_YOUR_KEY_HERE

# Or use the example script
./run_example.sh gsk_YOUR_KEY_HERE
```

## 5. View Results

```bash
# Terminal output shows ranked table
# Files saved in output/results/

ls -lh output/results/
```

## Alternative: Using Ollama (Local)

```bash
# Install Ollama
brew install ollama

# Pull Llama 3.1 model (4.9GB)
ollama pull llama3.1

# Start Ollama service
ollama serve

# Run CV Sorter with Ollama
python main.py --resumes ./RESUME/ --jd job-description.txt --provider ollama
```

## Troubleshooting

### Import Errors

```bash
# Reinstall dependencies
pip install --upgrade -r requirements.txt
```

### No Resumes Found

```bash
# Check if files exist
ls RESUME/*.pdf RESUME/*.docx

# Verify file extensions are lowercase
```

### API Rate Limit

```bash
# Groq free tier: 250K tokens/minute
# If you hit the limit, wait a minute or use Ollama
```

## Project Structure Verification

```bash
# Should see this structure:
cv_sorter/
├── main.py ✅
├── config.py ✅
├── requirements.txt ✅
├── parsers/ ✅
│   ├── __init__.py
│   ├── resume_parser.py
│   └── jd_parser.py
├── matching/ ✅
│   ├── __init__.py
│   ├── models.py
│   ├── prompts.py
│   └── scorer.py
├── output/ ✅
│   ├── __init__.py
│   ├── formatter.py
│   └── results/
├── RESUME/ ✅
├── job-description.txt ✅
└── README.md ✅
```

## Next Steps

1. **Test with sample resumes**: Place 2-3 test resumes in `RESUME/`
2. **Customize job description**: Edit `job-description.txt` for your role
3. **Run scoring**: Execute `main.py` with your API key
4. **Review results**: Check terminal output and `output/results/`
5. **Iterate**: Refine job description and re-run as needed
