"""
Ranking Engine — Combines algorithmic and semantic scores

Blends keyword matching scores with semantic similarity scores.
NO LLM calls — purely mathematical ranking.

Default blend ratio:
- 70% algorithmic (keyword matching with weights)
- 30% semantic (embedding cosine similarity)

Recommendation thresholds:
- Strong Fit: 75+
- Moderate Fit: 55-74
- Weak Fit: <55
"""

from typing import List, Dict
import numpy as np

from scoring_engine_agent import compute_weighted_score


# Configurable blend weights
ALGO_WEIGHT = 0.70      # Favor explicit skill matches
SEMANTIC_WEIGHT = 0.30  # Add context/similarity bonus

# Recommendation thresholds
STRONG_FIT_THRESHOLD = 75
MODERATE_FIT_THRESHOLD = 55


def classify_candidate(score: float) -> str:
    """
    Classify candidate fit based on combined score.
    
    Args:
        score: Combined score (0-100)
        
    Returns:
        Classification string: "Strong Fit", "Moderate Fit", or "Weak Fit"
    """
    if score >= STRONG_FIT_THRESHOLD:
        return "Strong Fit"
    elif score >= MODERATE_FIT_THRESHOLD:
        return "Moderate Fit"
    else:
        return "Weak Fit"


def rank_candidates(
    resumes: List[Dict],
    criteria: List[Dict],
    semantic_scores: np.ndarray
) -> List[Dict]:
    """
    Rank candidates by combining algorithmic and semantic scores.
    
    For each resume:
    1. Compute algorithmic score (keyword matching × weights)
    2. Get semantic score from FAISS
    3. Blend: combined = 70% algo + 30% semantic
    4. Classify as Strong/Moderate/Weak Fit
    
    Args:
        resumes: List of parsed resume dicts
        criteria: List of weighted criteria dicts
        semantic_scores: Numpy array of FAISS similarity scores (0-1 range)
                        Must be parallel to resumes list (same length/order)
        
    Returns:
        List of resumes sorted by combined_score (descending)
        Each resume dict enriched with:
        - algo_score
        - semantic_score
        - combined_score
        - recommendation
        - matched_criteria
        - missing_criteria
        
    Example:
        >>> ranked = rank_candidates(resumes, criteria, semantic_scores)
        >>> top3 = ranked[:3]
        >>> for r in top3:
        ...     print(f"{r['name']}: {r['combined_score']}")
        Jane Doe: 87.5
        John Smith: 82.1
        Alice Johnson: 78.3
    """
    if len(resumes) != len(semantic_scores):
        raise ValueError(
            f"Resumes count ({len(resumes)}) must match "
            f"semantic scores count ({len(semantic_scores)})"
        )
    
    ranked = []
    
    for i, resume in enumerate(resumes):
        # Compute algorithmic score
        algo_result = compute_weighted_score(resume, criteria)
        
        # Get semantic score (convert from 0-1 to 0-100 scale)
        semantic_score = float(semantic_scores[i]) * 100
        
        # Blend scores
        combined_score = round(
            ALGO_WEIGHT * algo_result["algo_score"] +
            SEMANTIC_WEIGHT * semantic_score,
            1
        )
        
        # Classify recommendation
        recommendation = classify_candidate(combined_score)
        
        # Enrich resume with scores
        enriched = {
            **resume,
            "algo_score": round(algo_result["algo_score"], 1),
            "semantic_score": round(semantic_score, 1),
            "combined_score": combined_score,
            "recommendation": recommendation,
            "matched_criteria": algo_result["matched_criteria"],
            "missing_criteria": algo_result["missing_criteria"],
        }
        
        ranked.append(enriched)
    
    # Sort by combined score (descending)
    ranked.sort(key=lambda x: x["combined_score"], reverse=True)
    
    return ranked
