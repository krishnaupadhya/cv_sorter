# CV Sorter - Automated Resume Ranking using LLMs

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)

A Python CLI application that uses Large Language Models (LLMs) to automatically parse, score, and rank candidate resumes against job descriptions. Built with **LangChain**, **Groq API**, and **Llama 3.1 8B**.

## 🎯 Features

- **Multi-format Resume Parsing**: Supports PDF and DOCX files with table structure preservation
- **Semantic Understanding**: LLM-based extraction (not just regex) for accurate skill matching
- **Detailed Scoring**: Per-skill breakdown with evidence, experience & education scores
- **Multi-Provider Support**: Groq (fast cloud), Ollama (local), or Google AI Studio
- **Beautiful Terminal Output**: Rich formatted tables with color-coded scores
- **Structured Exports**: JSON and human-readable text reports
- **Token Efficient**: Optimized prompts minimize API costs

## 🚀 Quick Start

### Prerequisites

- Python 3.10 or higher
- Groq API key (free tier) from [console.groq.com](https://console.groq.com)
- OR Ollama installed locally: `brew install ollama && ollama pull llama3.1`

### Installation

```bash
# Clone the repository
cd cv_sorter

# Create virtual environment
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### Usage

```bash
# Using Groq (fast cloud inference - recommended)
python main.py --resumes ./RESUME/ --jd job-description.txt --api-key gsk_...

# Using Ollama (local, private, no API key)
python main.py --resumes ./RESUME/ --jd job-description.txt --provider ollama

# Show only top 5 candidates
python main.py --resumes ./RESUME/ --jd job-description.txt --api-key gsk_... --top 5

# Show detailed breakdown for a candidate
python main.py --resumes ./RESUME/ --jd job-description.txt --api-key gsk_... --detail "John Doe"
```

## 📁 Project Structure

```
cv_sorter/
├── main.py                      # CLI entry point
├── config.py                    # Multi-provider LLM configuration
├── requirements.txt             # Python dependencies
├── parsers/
│   ├── resume_parser.py         # PDF/DOCX text extraction
│   └── jd_parser.py             # Job description loading
├── matching/
│   ├── models.py                # Pydantic data models
│   ├── prompts.py               # LangChain prompt templates
│   └── scorer.py                # LLM-based scoring pipeline
├── output/
│   ├── formatter.py             # Display and export formatting
│   └── results/                 # Generated ranking files
├── RESUME/                      # Place candidate resumes here (PDF/DOCX)
├── job-description.txt          # Job description file
└── README.md
```

## 🧠 Architecture

### Pipeline Overview

```
1. Parse Resumes (PDF/DOCX)
   ↓
2. Extract Text (pdfplumber, python-docx)
   ↓
3. LLM Extraction (text → structured data)
   ↓
4. Parse Job Description
   ↓
5. LLM Requirements Extraction
   ↓
6. Score Each Candidate
   ↓
7. Rank by Overall Score
   ↓
8. Display & Export Results
```

### Scoring Rubric

| Component | Weight | Scale | Description |
|-----------|--------|-------|-------------|
| **Skills** | 50% | 0-10 per skill | Per-skill matching with evidence |
| **Experience** | 30% | 0-100 | Years of experience + relevance |
| **Education** | 20% | 0-100 | Degree level + field match |

**Overall Score** = (avg_skill_score × 10 × 0.5) + (experience_score × 0.3) + (education_score × 0.2)

## 🎓 Why These Choices?

### Model: Llama 3.1 8B

| Feature | Llama 3.1 8B | Alternatives |
|---------|--------------|--------------|
| Context window | **128K** | Gemma 2: 8K, Mistral 7B: 32K |
| Function calling | ✅ Yes | Gemma 2: ❌ No |
| Structured output | Excellent | Good |
| Community | 111M pulls | Gemma: 17M, Mistral: 26M |

**Decision**: 128K context fits multiple resumes + JD in one prompt. Function calling enables reliable JSON output.

### Provider: Groq API (Primary) + Ollama (Fallback)

| Criteria | Groq | Ollama |
|----------|------|--------|
| Speed | **840 tok/sec** | ~15-30 tok/sec (CPU) |
| Cost | Free tier | Free (unlimited) |
| Privacy | Cloud | **100% local** |
| Setup | Just API key | Install + 4.9GB download |

**Decision**: Groq for demo speed, Ollama for privacy/offline use.

### Framework: LangChain

- **Prompt templates**: Easy iteration on prompt engineering
- **PydanticOutputParser**: Reliable structured output with auto-retry
- **Chains**: Clean pipeline abstraction
- **Provider abstraction**: Easy switching between models

## 📊 Example Output

```
╔══════╦════════════════╦═══════╦══════════════════════╦═════════════╗
║ Rank ║ Candidate      ║ Score ║ Top Strengths        ║ Key Gaps    ║
╠══════╬════════════════╬═══════╬══════════════════════╬═════════════╣
║ #1   ║ Jane Smith     ║ 87.5  ║ Android, Kotlin, 6yr ║ No AWS exp  ║
║ #2   ║ John Doe       ║ 72.3  ║ Java, CI/CD, Docker  ║ No Jetpack  ║
║ #3   ║ Alice Johnson  ║ 61.0  ║ CS degree, Firebase  ║ <2yr exp    ║
╚══════╩════════════════╩═══════╩══════════════════════╩═════════════╝
```

## 🔒 Security Note

**API keys are NEVER stored in code or .env files.** They are passed via CLI arguments at runtime to prevent accidental leakage in version control.

## 🛠️ Development

### Running Tests

```bash
# TODO: Add tests in tests/ directory
pytest tests/
```

### Adding a New Provider

Edit `config.py`:

```python
elif provider == "new_provider":
    from langchain_new_provider import ChatNewProvider
    return ChatNewProvider(
        model="model-name",
        api_key=api_key,
        temperature=temperature
    )
```

## 📈 Token Efficiency

- **Resume parsing**: No LLM calls (local PDF/DOCX extraction)
- **JD analysis**: ~500 tokens (fresh LLM call each run)
- **Report generation**: ~2000 tokens/candidate
- **Total for 10 candidates**: ~21K tokens (~$0.01 on Groq free tier)

## 🐛 Troubleshooting

### "PDF appears to be scanned"

- The PDF contains images, not text. OCR is required but not supported.
- Convert to text-based PDF or retype the resume.

### "ModuleNotFoundError: No module named 'langchain_groq'"

```bash
pip install langchain-groq
```

### Ollama connection error

```bash
# Start Ollama service
ollama serve

# Pull the model
ollama pull llama3.1
```

## 📝 To-Do / Future Enhancements

- [ ] Interactive CLI mode for requirement refinement
- [ ] RAG mode with LlamaIndex for query-based retrieval
- [ ] Streamlit web UI for non-technical users
- [ ] Resume anonymization (remove names/photos)
- [ ] Multi-model comparison (Llama vs Gemma vs Mistral)

## 🙏 Credits

- **LangChain**: LLM orchestration framework
- **Groq**: Ultra-fast LLM inference
- **Meta**: Llama 3.1 8B model
- **Rich**: Beautiful terminal output

## 📄 License

MIT License - see LICENSE file for details

---

**Author**: Senior AI Engineer  
**Date**: March 7, 2026  
**Project**: Capstone - CV Sorting using LLMs
