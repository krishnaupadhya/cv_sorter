"""
Layout analyzer for resume text preprocessing.

Detects document sections (education, experience, skills, etc.) using 
keyword patterns and structural cues. Provides section-aware text that 
helps the LLM extract information more accurately.

This module preprocesses extracted text before LLM consumption:
1. Detect and label resume sections
2. Score text extraction quality
3. Clean and normalize section content
"""

import re
from typing import Optional


# Section header patterns (case-insensitive)
# Maps canonical section name → list of common header variations
SECTION_PATTERNS = {
    "contact": [
        r"contact\s*(?:info|information|details)?",
        r"personal\s*(?:info|information|details)?",
    ],
    "summary": [
        r"(?:professional\s*)?summary",
        r"(?:career\s*)?objective",
        r"profile",
        r"about\s*me",
        r"overview",
    ],
    "experience": [
        r"(?:work|professional|employment)\s*(?:experience|history)",
        r"experience",
        r"career\s*history",
        r"work\s*history",
    ],
    "education": [
        r"education(?:al\s*(?:background|qualifications?))?",
        r"academic\s*(?:background|qualifications?)",
        r"degrees?",
    ],
    "skills": [
        r"(?:technical\s*)?skills",
        r"core\s*competencies",
        r"competencies",
        r"technologies",
        r"tools?\s*(?:&|and)\s*technologies",
        r"tech(?:nical)?\s*stack",
        r"areas?\s*of\s*expertise",
    ],
    "projects": [
        r"(?:key\s*|notable\s*)?projects?",
        r"portfolio",
    ],
    "certifications": [
        r"certifications?\s*(?:&|and)?\s*(?:licenses?)?",
        r"licenses?\s*(?:&|and)?\s*certifications?",
        r"professional\s*certifications?",
    ],
    "awards": [
        r"awards?\s*(?:&|and)?\s*(?:achievements?|honors?)?",
        r"achievements?\s*(?:&|and)?\s*awards?",
        r"honors?\s*(?:&|and)?\s*awards?",
    ],
    "publications": [
        r"publications?",
        r"research\s*(?:papers?|publications?)",
    ],
    "languages": [
        r"languages?",
    ],
    "references": [
        r"references?",
    ],
}


def detect_sections(text: str) -> dict[str, str]:
    """
    Detect and extract resume sections from text.
    
    Uses keyword-based header detection to split text into labeled sections.
    Handles both Markdown headers (## Section) and plain text headers.
    
    Args:
        text: Extracted resume text (Markdown or plain)
        
    Returns:
        Dict mapping section names to their content.
        Always includes 'full_text' key with the complete text.
        Example: {"experience": "...", "skills": "...", "full_text": "..."}
    """
    sections = {"full_text": text}
    
    if not text:
        return sections
    
    lines = text.split('\n')
    current_section = None
    current_content = []
    section_starts = []
    
    for i, line in enumerate(lines):
        stripped = line.strip()
        if not stripped:
            if current_section:
                current_content.append("")
            continue
        
        # Check if this line is a section header
        detected = _match_section_header(stripped)
        if detected:
            # Save previous section
            if current_section:
                content = "\n".join(current_content).strip()
                if content:
                    sections[current_section] = content
                    section_starts.append((current_section, i - len(current_content)))
            
            current_section = detected
            current_content = []
        else:
            if current_section:
                current_content.append(line)
    
    # Save last section
    if current_section and current_content:
        content = "\n".join(current_content).strip()
        if content:
            sections[current_section] = content
    
    return sections


def _match_section_header(line: str) -> Optional[str]:
    """
    Check if a line is a section header.
    
    Matches against known section patterns. Handles:
    - Markdown headers: ## Experience, ### Skills
    - Bold markers: **Experience**, __Skills__
    - ALL CAPS: EXPERIENCE, EDUCATION
    - Colon-terminated: Experience:, Skills:
    - Short standalone lines with section keywords
    
    Args:
        line: A single line of text
        
    Returns:
        Canonical section name if matched, None otherwise
    """
    # Strip Markdown header markers
    clean = re.sub(r'^#+\s*', '', line)
    # Strip bold markers
    clean = re.sub(r'\*\*|__', '', clean)
    # Strip trailing colon/dash
    clean = re.sub(r'[:—–\-]+\s*$', '', clean)
    clean = clean.strip()
    
    # Too long to be a header
    if len(clean) > 60:
        return None
    
    # Too short to be meaningful
    if len(clean) < 3:
        return None
    
    for section_name, patterns in SECTION_PATTERNS.items():
        for pattern in patterns:
            if re.match(rf'^{pattern}\s*$', clean, re.IGNORECASE):
                return section_name
    
    return None


def enrich_text_with_sections(text: str) -> str:
    """
    Enrich text with explicit section markers for better LLM extraction.
    
    If sections are detected, adds clear delimiters that help the LLM
    understand document structure. If no sections found, returns text as-is.
    
    Args:
        text: Raw extracted text
        
    Returns:
        Text with section markers added (or unchanged if no sections detected)
    """
    sections = detect_sections(text)
    
    # If we only found full_text (no sections detected), return as-is
    if len(sections) <= 1:
        return text
    
    # Build enriched text with clear section labels
    enriched_parts = []
    
    # Add sections in a logical order
    section_order = [
        "contact", "summary", "experience", "education", 
        "skills", "projects", "certifications", "awards",
        "publications", "languages", "references"
    ]
    
    for section_name in section_order:
        if section_name in sections:
            enriched_parts.append(f"=== {section_name.upper()} ===")
            enriched_parts.append(sections[section_name])
            enriched_parts.append("")
    
    # Add any sections not in our predefined order
    for section_name, content in sections.items():
        if section_name != "full_text" and section_name not in section_order:
            enriched_parts.append(f"=== {section_name.upper()} ===")
            enriched_parts.append(content)
            enriched_parts.append("")
    
    return "\n".join(enriched_parts).strip()


def assess_extraction_quality(text: str) -> dict:
    """
    Assess the quality of extracted text to decide on extraction strategy.
    
    Returns quality metrics that help downstream code decide whether
    to use LLM extraction or fall back to regex.
    
    Args:
        text: Extracted resume text
        
    Returns:
        Dict with quality metrics:
        - word_count: Total words
        - has_email: Email address found
        - has_phone: Phone number found
        - sections_found: Number of resume sections detected
        - quality: "high", "medium", or "low"
    """
    if not text:
        return {"word_count": 0, "sections_found": 0, "quality": "none"}
    
    word_count = len(text.split())
    has_email = bool(re.search(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', text))
    has_phone = bool(re.search(r'[\+]?\d[\d\s\-\(\)]{7,}', text))
    
    sections = detect_sections(text)
    sections_found = len(sections) - 1  # Exclude 'full_text'
    
    if word_count > 100 and has_email and sections_found >= 2:
        quality = "high"
    elif word_count > 50 and (has_email or sections_found >= 1):
        quality = "medium"
    else:
        quality = "low"
    
    return {
        "word_count": word_count,
        "has_email": has_email,
        "has_phone": has_phone,
        "sections_found": sections_found,
        "quality": quality,
    }
