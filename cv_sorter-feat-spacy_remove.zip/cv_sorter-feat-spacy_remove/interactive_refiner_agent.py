"""
Interactive Refiner — Interactive Query Refinement

Allows users to refine ranking after initial results by:
1. Add new job requirement (new criterion with weight)
2. Adjust existing requirement weight (modify importance)
3. Filter by specific skills (boost matching candidates)

Each refinement generates a new timestamped result while preserving original.
"""

import asyncio
from typing import List, Dict, Tuple
from pathlib import Path
from rich.console import Console
from rich.prompt import Prompt, Confirm, IntPrompt
from rich.table import Table
from rich.panel import Panel
import numpy as np

from job_analyzer_agent import JobAnalyzer
from embedding_engine_agent import EmbeddingEngine
from ranking_engine_agent import rank_candidates, classify_candidate
from scoring_engine_agent import compute_weighted_score


console = Console()


class InteractiveRefiner:
    """
    Handles interactive refinement of ranking results.
    
    Supports:
    - Add new job requirement (new criterion with weight)
    - Adjust existing requirement weight (modify importance)
    - Filter by skills (boost matching candidates)
    """
    
    def __init__(
        self, 
        provider: str = "groq", 
        api_key: str = None,
        original_jd_text: str = None,
        embedding_engine: EmbeddingEngine = None
    ):
        """
        Initialize Interactive Refiner.
        
        Args:
            provider: LLM provider for job analysis
            api_key: API key for cloud providers
            original_jd_text: Original job description text (not currently used)
            embedding_engine: Embedding engine instance for re-generating embeddings
        """
        self.provider = provider
        self.api_key = api_key
        self.original_jd_text = original_jd_text
        self.embedding_engine = embedding_engine or EmbeddingEngine()
        self.job_analyzer = JobAnalyzer(provider=provider, api_key=api_key)
    
    def show_menu(self) -> str:
        """
        Display interactive menu and get user choice.
        
        Returns:
            User's choice: '1', '2', '3', or 'q'
        """
        console.print("\n" + "═" * 60)
        console.print("[bold cyan]        Interactive Query Refinement[/bold cyan]")
        console.print("═" * 60 + "\n")
        
        console.print("[bold]What would you like to do?[/bold]\n")
        
        console.print("  [bold cyan]1.[/bold cyan] [bold]Add New Job Requirement[/bold]")
        console.print("     → Add a completely new criterion (e.g., 'Must have AWS certification')")
        console.print("     → Assign importance weight (5-10 scale)")
        console.print("     → System re-ranks all candidates\n")
        
        console.print("  [bold cyan]2.[/bold cyan] [bold]Adjust Existing Requirement Weight[/bold]")
        console.print("     → Change importance of existing criteria")
        console.print("     → Example: Increase 'Python experience' from weight 8 to 10")
        console.print("     → Instantly re-calculates scores\n")
        
        console.print("  [bold cyan]3.[/bold cyan] [bold]Filter by Skills[/bold]")
        console.print("     → Focus on specific technical skills")
        console.print("     → Example: 'Python, Docker, Kubernetes'")
        console.print("     → Boosts matching candidates (+5 points per skill)\n")
        
        console.print("  [bold cyan]q.[/bold cyan] [bold]Quit[/bold] - Keep current results and exit\n")
        
        choice = Prompt.ask(
            "[bold yellow]Enter your choice[/bold yellow]",
            choices=["1", "2", "3", "q"],
            default="q"
        )
        
        return choice
    
    async def add_new_requirement(
        self,
        current_criteria: List[Dict],
        resumes: List[Dict],
        semantic_scores: np.ndarray
    ) -> Tuple[List[Dict], str, List[Dict]]:
        """
        Add a new job requirement criterion.
        
        Prompts user for:
        1. New requirement description
        2. Importance weight (5-10 scale)
        
        Then re-ranks all candidates against updated criteria.
        
        Args:
            current_criteria: Current list of criteria (will be updated)
            resumes: List of resume dicts
            semantic_scores: Current semantic scores (will be recalculated)
            
        Returns:
            Tuple of (updated_ranked_candidates, refinement_description, new_criteria)
        """
        console.print("\n" + "─" * 60)
        console.print("[bold cyan]Add New Job Requirement[/bold cyan]")
        console.print("─" * 60 + "\n")
        
        console.print("[yellow]📝 Instructions:[/yellow]")
        console.print("  • Enter a clear, specific requirement")
        console.print("  • Examples:")
        console.print("    - 'Experience with AWS cloud services'")
        console.print("    - 'Must have led a team of 5+ developers'")
        console.print("    - 'Proficiency in microservices architecture'")
        console.print("  • Press Enter without text to cancel\n")
        
        requirement_text = Prompt.ask("[bold]Enter new requirement[/bold]")
        
        if not requirement_text.strip():
            console.print("[yellow]⚠ No requirement entered. Canceling...[/yellow]")
            return rank_candidates(resumes, current_criteria, semantic_scores), "No change", current_criteria
        
        # Get weight from user
        console.print("\n[yellow]⚖️  Importance Weight (5-10 scale):[/yellow]")
        console.print("  • 5-6: Nice to have")
        console.print("  • 7-8: Important")
        console.print("  • 9-10: Critical requirement\n")
        
        try:
            weight = IntPrompt.ask(
                "[bold]Enter weight[/bold]",
                default=7
            )
            
            # Validate weight range
            if weight < 5 or weight > 10:
                console.print("[yellow]⚠ Weight must be between 5-10. Using default weight of 7.[/yellow]")
                weight = 7
        except:
            console.print("[yellow]⚠ Invalid input. Using default weight of 7.[/yellow]")
            weight = 7
        
        # Create new criterion
        new_criterion = {
            "name": requirement_text.strip(),
            "weight": weight
        }
        
        # Add to criteria list
        updated_criteria = current_criteria.copy()
        updated_criteria.append(new_criterion)
        
        console.print(f"\n[green]✓ Added requirement: '{requirement_text.strip()}'[/green]")
        console.print(f"[green]✓ Weight: {weight}/10[/green]")
        console.print(f"[dim]Total criteria: {len(updated_criteria)}[/dim]\n")
        
        # Regenerate embeddings with new criterion
        console.print("[cyan]🔄 Regenerating semantic embeddings...[/cyan]")
        try:
            new_semantic_scores = self._compute_semantic_scores(updated_criteria, resumes)
            console.print(f"[green]✓ Computed new semantic scores[/green]\n")
        except Exception as e:
            console.print(f"[red]✗ Failed to compute embeddings: {e}[/red]")
            return rank_candidates(resumes, current_criteria, semantic_scores), "No change", current_criteria
        
        # Re-rank with updated criteria
        console.print("[cyan]📊 Re-ranking candidates...[/cyan]")
        ranked = rank_candidates(resumes, updated_criteria, new_semantic_scores)
        console.print(f"[green]✓ Re-ranked {len(ranked)} candidates[/green]\n")
        
        refinement_desc = f"Added requirement: '{requirement_text.strip()}' (weight: {weight})"
        
        return ranked, refinement_desc, updated_criteria
    
    async def adjust_existing_requirement(
        self,
        current_criteria: List[Dict],
        resumes: List[Dict],
        semantic_scores: np.ndarray
    ) -> Tuple[List[Dict], str, List[Dict]]:
        """
        Adjust the weight of an existing requirement.
        
        Shows all current requirements in a table, allows user to:
        1. Select a requirement by number
        2. Enter new weight (5-10 scale)
        
        Then instantly re-calculates scores and updates rankings.
        
        Args:
            current_criteria: Current list of criteria (will be updated)
            resumes: List of resume dicts
            semantic_scores: Current semantic scores (unchanged - weights only)
            
        Returns:
            Tuple of (updated_ranked_candidates, refinement_description, updated_criteria)
        """
        console.print("\n" + "─" * 60)
        console.print("[bold cyan]Adjust Existing Requirement Weight[/bold cyan]")
        console.print("─" * 60 + "\n")
        
        if not current_criteria:
            console.print("[red]✗ No criteria available to adjust.[/red]")
            return rank_candidates(resumes, current_criteria, semantic_scores), "No change", current_criteria
        
        # Display current criteria in a table
        table = Table(
            title="Current Job Requirements",
            show_header=True,
            header_style="bold cyan"
        )
        
        table.add_column("#", style="dim", width=6, justify="center")
        table.add_column("Requirement", style="bold", width=60)
        table.add_column("Weight", justify="center", width=10)
        
        for i, criterion in enumerate(current_criteria, 1):
            table.add_row(
                str(i),
                criterion["name"],
                f"{criterion['weight']}/10"
            )
        
        console.print(table)
        console.print()
        
        # Get user selection
        console.print("[yellow]📝 Instructions:[/yellow]")
        console.print("  • Enter the # of the requirement to adjust")
        console.print("  • Enter 0 to cancel\n")
        
        try:
            selection = IntPrompt.ask(
                "[bold]Select requirement #[/bold]",
                default=0
            )
            
            if selection == 0:
                console.print("[yellow]⚠ Canceled.[/yellow]")
                return rank_candidates(resumes, current_criteria, semantic_scores), "No change", current_criteria
            
            if selection < 1 or selection > len(current_criteria):
                console.print(f"[red]✗ Invalid selection. Must be 1-{len(current_criteria)}.[/red]")
                return rank_candidates(resumes, current_criteria, semantic_scores), "No change", current_criteria
            
        except:
            console.print("[red]✗ Invalid input.[/red]")
            return rank_candidates(resumes, current_criteria, semantic_scores), "No change", current_criteria
        
        # Get selected criterion
        selected_criterion = current_criteria[selection - 1]
        current_weight = selected_criterion["weight"]
        
        console.print(f"\n[cyan]Selected: {selected_criterion['name']}[/cyan]")
        console.print(f"[dim]Current weight: {current_weight}/10[/dim]\n")
        
        # Get new weight
        console.print("[yellow]⚖️  New Importance Weight (5-10 scale):[/yellow]")
        console.print("  • 5-6: Nice to have")
        console.print("  • 7-8: Important")
        console.print("  • 9-10: Critical requirement\n")
        
        try:
            new_weight = IntPrompt.ask(
                "[bold]Enter new weight[/bold]",
                default=current_weight
            )
            
            # Validate weight range
            if new_weight < 5 or new_weight > 10:
                console.print("[yellow]⚠ Weight must be between 5-10. Keeping current weight.[/yellow]")
                return rank_candidates(resumes, current_criteria, semantic_scores), "No change", current_criteria
            
            if new_weight == current_weight:
                console.print("[yellow]⚠ Weight unchanged.[/yellow]")
                return rank_candidates(resumes, current_criteria, semantic_scores), "No change", current_criteria
                
        except:
            console.print("[red]✗ Invalid input.[/red]")
            return rank_candidates(resumes, current_criteria, semantic_scores), "No change", current_criteria
        
        # Update criterion weight
        updated_criteria = current_criteria.copy()
        updated_criteria[selection - 1] = {
            "name": selected_criterion["name"],
            "weight": new_weight
        }
        
        console.print(f"\n[green]✓ Updated weight: {current_weight} → {new_weight}[/green]")
        console.print(f"[dim]Requirement: {selected_criterion['name']}[/dim]\n")
        
        # Re-rank with updated weights (no need to recompute embeddings)
        console.print("[cyan]📊 Re-calculating scores and rankings...[/cyan]")
        ranked = rank_candidates(resumes, updated_criteria, semantic_scores)
        console.print(f"[green]✓ Re-ranked {len(ranked)} candidates[/green]\n")
        
        refinement_desc = f"Adjusted '{selected_criterion['name']}' weight: {current_weight} → {new_weight}"
        
        return ranked, refinement_desc, updated_criteria
    
    def filter_by_skills(
        self,
        resumes: List[Dict],
        current_criteria: List[Dict],
        semantic_scores: np.ndarray
    ) -> Tuple[List[Dict], str, List[Dict]]:
        """
        Filter and boost candidates by specific skills.
        
        Candidates with matching skills get +5 points per skill.
        Re-sorts by skill match count and combined score.
        
        Args:
            resumes: List of resume dicts
            current_criteria: Current criteria (unchanged)
            semantic_scores: Semantic similarity scores (unchanged)
            
        Returns:
            Tuple of (filtered_and_reranked_candidates, refinement_description, criteria)
        """
        console.print("\n" + "─" * 60)
        console.print("[bold cyan]Filter by Skills[/bold cyan]")
        console.print("─" * 60 + "\n")
        
        # Collect all unique skills from resumes
        all_skills = set()
        for resume in resumes:
            all_skills.update(resume.get("skills", []))
        
        all_skills = sorted(all_skills)
        
        if not all_skills:
            console.print("[red]✗ No skills found in resumes.[/red]")
            return rank_candidates(resumes, current_criteria, semantic_scores), "No change", current_criteria
        
        console.print(f"[yellow]💡 Available skills ({len(all_skills)} total):[/yellow]")
        
        # Display skills in a compact format (5 per line)
        skills_display = []
        for i in range(0, min(25, len(all_skills)), 5):
            line_skills = all_skills[i:i+5]
            skills_display.append("  • " + ", ".join(line_skills))
        
        for line in skills_display:
            console.print(f"[dim]{line}[/dim]")
        
        if len(all_skills) > 25:
            console.print(f"[dim]  ... and {len(all_skills) - 25} more[/dim]")
        
        console.print("\n[yellow]📝 Instructions:[/yellow]")
        console.print("  • Enter skills separated by commas")
        console.print("  • Example: 'Python, Docker, Kubernetes, AWS, React'")
        console.print("  • Case-insensitive matching")
        console.print("  • Each matching skill adds +5 points to candidate score")
        console.print("  • Press Enter without text to cancel\n")
        
        skill_input = Prompt.ask("[bold]Enter skills to filter[/bold]")
        
        if not skill_input.strip():
            console.print("[yellow]⚠ No skills entered. Canceling...[/yellow]")
            return rank_candidates(resumes, current_criteria, semantic_scores), "No change", current_criteria
        
        # Parse and normalize filter skills
        filter_skills = [s.strip().lower() for s in skill_input.split(",") if s.strip()]
        
        if not filter_skills:
            console.print("[yellow]⚠ No valid skills entered. Canceling...[/yellow]")
            return rank_candidates(resumes, current_criteria, semantic_scores), "No change", current_criteria
        
        console.print(f"\n[green]✓ Filtering by: {', '.join(filter_skills)}[/green]\n")
        
        # First, do normal ranking
        ranked = rank_candidates(resumes, current_criteria, semantic_scores)
        
        # Add skill match count and boost score
        console.print("[cyan]📊 Calculating skill matches...[/cyan]")
        
        for candidate in ranked:
            candidate_skills = set(s.lower() for s in candidate.get("skills", []))
            match_count = sum(1 for skill in filter_skills if skill in candidate_skills)
            candidate["skill_match_count"] = match_count
            
            # Boost combined score based on skill matches
            # Each matching skill adds 5 points
            skill_boost = match_count * 5
            candidate["original_combined_score"] = candidate["combined_score"]
            candidate["skill_boost"] = skill_boost
            candidate["combined_score"] = min(100, candidate["combined_score"] + skill_boost)
            candidate["recommendation"] = classify_candidate(candidate["combined_score"])
        
        # Re-sort by skill match count (primary) and combined score (secondary)
        ranked.sort(key=lambda x: (x["skill_match_count"], x["combined_score"]), reverse=True)
        
        # Show filter results summary
        matches = sum(1 for c in ranked if c["skill_match_count"] > 0)
        total_matches = sum(c["skill_match_count"] for c in ranked)
        
        console.print(f"[green]✓ Found {matches}/{len(ranked)} candidates with matching skills[/green]")
        console.print(f"[green]✓ Total skill matches: {total_matches}[/green]")
        
        if matches > 0:
            top_candidate = ranked[0]
            console.print(f"[dim]Top match: {top_candidate['name']} ({top_candidate['skill_match_count']} skills, score: {top_candidate['combined_score']:.1f})[/dim]\n")
        else:
            console.print("[yellow]⚠ No candidates match the specified skills.[/yellow]\n")
        
        refinement_desc = f"Filtered by skills: {', '.join(filter_skills)}"
        
        return ranked, refinement_desc, current_criteria
    
    def show_refined_results_preview(self, ranked: List[Dict], top_n: int = 10):
        """
        Display preview of refined results.
        
        Args:
            ranked: Ranked candidates list
            top_n: Number of top candidates to show
        """
        table = Table(
            title=f"Refined Rankings (Top {min(top_n, len(ranked))})",
            show_header=True,
            header_style="bold cyan"
        )
        
        table.add_column("Rank", style="dim", width=8, justify="center")
        table.add_column("Name", style="bold", width=40)
        table.add_column("Score", justify="right", width=12)
        table.add_column("Fit", style="bold", width=18, justify="center")
        table.add_column("Skills Match", justify="center", width=14)
        
        display_count = min(top_n, len(ranked))
        
        for i, candidate in enumerate(ranked[:display_count], 1):
            # Color recommendation
            rec = candidate["recommendation"]
            if rec == "Strong Fit":
                rec_style = "green"
            elif rec == "Moderate Fit":
                rec_style = "yellow"
            else:
                rec_style = "red"
            
            skill_match = str(candidate.get("skill_match_count", "-"))
            if candidate.get("skill_match_count", 0) > 0:
                skill_match = f"[green]{skill_match}[/green]"
            
            table.add_row(
                f"#{i}",
                candidate["name"][:38],
                f"{candidate['combined_score']:.1f}",
                f"[{rec_style}]{rec}[/{rec_style}]",
                skill_match
            )
        
        console.print(table)
        console.print()
    
    def _load_jd_file(self, jd_path: str) -> str:
        """
        Load job description from file.
        
        Supports: .txt, .pdf, .docx
        
        Args:
            jd_path: Path to job description file
            
        Returns:
            Extracted text content
            
        Raises:
            FileNotFoundError: If file doesn't exist
            ValueError: If file format is unsupported or content is invalid
        """
        from document_loader_parser import DocumentLoader
        
        path = Path(jd_path)
        if not path.exists():
            raise FileNotFoundError(f"Job description file not found: {jd_path}")
        
        extension = path.suffix.lower()
        
        # Handle TXT files directly
        if extension == '.txt':
            return path.read_text(encoding='utf-8')
        
        # Handle PDF/DOCX with DocumentLoader
        elif extension in ['.pdf', '.docx', '.doc']:
            loader = DocumentLoader()
            text = loader.load(str(path))
            
            if not text or len(text.strip()) < 50:
                raise ValueError(
                    f"Job description file appears to be empty or too short (< 50 chars): {jd_path}"
                )
            
            return text
        
        else:
            raise ValueError(
                f"Unsupported file format: {extension}. "
                f"Supported formats: .txt, .pdf, .docx"
            )
    
    def _compute_semantic_scores(self, criteria: List[Dict], resumes: List[Dict]) -> np.ndarray:
        """
        Compute semantic similarity scores between criteria and resumes.
        
        Args:
            criteria: List of job criteria dicts
            resumes: List of resume dicts
            
        Returns:
            Numpy array of shape (num_resumes,) with average similarity scores
        """
        # Encode criteria
        criteria_texts = [c["name"] for c in criteria]
        criteria_embeddings = self.embedding_engine.encode_batch(criteria_texts)
        
        # Encode resumes (skill text)
        resume_texts = [r.get("skill_text", "") for r in resumes]
        resume_embeddings = self.embedding_engine.encode_batch(resume_texts)
        
        # Compute cosine similarity (dot product since embeddings are normalized)
        # Shape: (num_resumes, num_criteria)
        similarity_matrix = np.dot(resume_embeddings, criteria_embeddings.T)
        
        # Average across criteria to get one score per resume
        # Shape: (num_resumes,)
        avg_scores = np.mean(similarity_matrix, axis=1)
        
        return avg_scores
